// "Absolute Cinema": the supplied poster fills the picture and YOUR face replaces the face in it.
// The face outline comes from the face model (or, if that is not available, a head ellipse from the pose model),
// is turned black and white, brightness matched to the poster and feathered at the edge.

import { makeCanvas, ctx2d, clamp } from './util.js';

const OVAL = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109];
const INSET = 0.018;           // the poster image has rounded corners: crop them away

export class PosterRenderer {
  constructor() { this.W = 0; this.H = 0; this.smooth = null; this.gain = 1; this.lastFaceAt = -1e9; }

  setup(W, H, assets) {
    this.W = W; this.H = H; this.assets = assets; this.smooth = null;
    this.base = null;
    if (!assets || !assets.ready('poster')) return;
    const img = assets.poster, g = assets.posterGeo;
    const sx = img.width * INSET, sy = img.height * INSET, sw = img.width - 2 * sx, sh = img.height - 2 * sy;
    const ph = H, pw = ph * sw / sh, px = (W - pw) / 2;
    const base = makeCanvas(W, H), b = ctx2d(base);
    // sides: the same picture, very blurred and darkened
    b.filter = 'blur(28px) brightness(0.45)';
    b.drawImage(img, sx, sy, sw, sh, -W * 0.15, -H * 0.15, W * 1.3, H * 1.3);
    b.filter = 'none';
    b.drawImage(img, sx, sy, sw, sh, px, 0, pw, ph);
    // soft edge between the poster and the blurred sides
    const grad = (x0, x1) => { const gr = b.createLinearGradient(x0, 0, x1, 0); gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); return gr; };
    b.fillStyle = grad(px, px + 26); b.fillRect(px, 0, 26, H);
    b.fillStyle = grad(px + pw, px + pw - 26); b.fillRect(px + pw - 26, 0, 26, H);
    this.base = base;
    // where the poster face sits on the output frame
    const fx = (g.center[0] * img.width - sx) / sw, fy = (g.center[1] * img.height - sy) / sh;
    this.slot = { cx: px + fx * pw, cy: fy * ph, w: g.width * img.width / sw * pw, h: g.height * img.height / sh * ph, tilt: g.tiltDeg };
    // mean luma of the poster face, to match the user's face to it
    const lc = makeCanvas(16, 16), l = ctx2d(lc, { willReadFrequently: true });
    l.drawImage(base, this.slot.cx - this.slot.w / 2, this.slot.cy - this.slot.h / 2, this.slot.w, this.slot.h, 0, 0, 16, 16);
    this.targetLuma = this._luma(l);
    this.tmp = makeCanvas(256, 300); this.tx = ctx2d(this.tmp);
    this.mask = makeCanvas(256, 300); this.mx = ctx2d(this.mask);
    this.stat = makeCanvas(12, 12); this.sx = ctx2d(this.stat, { willReadFrequently: true });
  }

  _luma(ctx) {
    const d = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height).data;
    let s = 0; for (let i = 0; i < d.length; i += 4) s += d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
    return s / (d.length / 4);
  }

  // Turn this frame's face information into an outline polygon in source-frame pixels: {pts, tilt}
  _outline(faces, pose, w, h, t) {
    if (faces && faces[0]) {
      const lm = faces[0];
      const pts = OVAL.map((i) => [lm[i].x * w, lm[i].y * h]);
      const le = [(lm[33].x + lm[133].x) / 2 * w, (lm[33].y + lm[133].y) / 2 * h], re = [(lm[263].x + lm[362].x) / 2 * w, (lm[263].y + lm[362].y) / 2 * h];
      this.lastFaceAt = t;
      return { pts, tilt: Math.atan2(re[1] - le[1], re[0] - le[0]) * 180 / Math.PI };
    }
    if (pose && t - this.lastFaceAt > 400) {      // fallback: head ellipse from eyes / ears / nose
      const v = (i) => (pose[i] && (pose[i].visibility ?? 1) > 0.4);
      if (v(2) && v(5) && v(0)) {
        const ex = (pose[2].x + pose[5].x) / 2 * w, ey = (pose[2].y + pose[5].y) / 2 * h;
        const ed = Math.hypot((pose[2].x - pose[5].x) * w, (pose[2].y - pose[5].y) * h);
        const rx = ed * 1.35, ry = ed * 1.75, cy = ey + ed * 0.55;
        const pts = []; for (let k = 0; k < 24; k++) { const a = (k / 24) * 2 * Math.PI; pts.push([ex + Math.cos(a) * rx, cy + Math.sin(a) * ry]); }
        return { pts, tilt: Math.atan2((pose[2].y - pose[5].y) * h, (pose[2].x - pose[5].x) * w) * 180 / Math.PI };   // pose 2 is the eye on the image's right
      }
    }
    return null;
  }

  draw(o, level, bmp, faces, pose, t) {
    if (level <= 0.001 || !this.base) return;
    const { W, H } = this;
    o.save();
    o.globalAlpha = clamp(level);
    o.drawImage(this.base, 0, 0, W, H);
    const ol = this._outline(faces, pose, bmp.width, bmp.height, t);
    if (ol) {
      // smooth the outline so the swapped face does not jitter
      if (!this.smooth || this.smooth.pts.length !== ol.pts.length) this.smooth = { pts: ol.pts.map((p) => p.slice()), tilt: ol.tilt };
      else { const a = 0.55; this.smooth.pts.forEach((p, i) => { p[0] += (ol.pts[i][0] - p[0]) * a; p[1] += (ol.pts[i][1] - p[1]) * a; }); this.smooth.tilt += (ol.tilt - this.smooth.tilt) * a; }
      this._drawFace(o, bmp, this.smooth);
    }
    o.restore();
  }

  _drawFace(o, bmp, ol) {
    const pts = ol.pts;
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const [x, y] of pts) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    const fw = x1 - x0, fh = y1 - y0;
    if (!(fw > 8 && fh > 8)) return;
    const pad = 0.12, bx = x0 - fw * pad, by = y0 - fh * pad, bw = fw * (1 + 2 * pad), bh = fh * (1 + 2 * pad);
    const tw = this.tmp.width, th = this.tmp.height;
    const kx = tw / bw, ky = th / bh;
    // 1. crop of the camera picture around the face
    const t = this.tx; t.setTransform(1, 0, 0, 1, 0, 0); t.globalCompositeOperation = 'source-over'; t.clearRect(0, 0, tw, th);
    // brightness match from a tiny copy of the face area
    this.sx.drawImage(bmp, x0 + fw * 0.2, y0 + fh * 0.25, fw * 0.6, fh * 0.55, 0, 0, 12, 12);
    const cur = this._luma(this.sx) || 1;
    const want = clamp(this.targetLuma / cur, 0.55, 1.7);
    this.gain += (want - this.gain) * 0.25;
    t.filter = `grayscale(1) brightness(${this.gain.toFixed(3)}) contrast(1.12)`;
    t.drawImage(bmp, bx, by, bw, bh, 0, 0, tw, th);
    t.filter = 'none';
    // 2. soft face-shaped mask
    const m = this.mx; m.setTransform(1, 0, 0, 1, 0, 0); m.clearRect(0, 0, tw, th);
    m.filter = 'blur(5px)'; m.fillStyle = '#fff'; m.beginPath();
    pts.forEach(([x, y], i) => { const px = (x - bx) * kx, py = (y - by) * ky; if (i) m.lineTo(px, py); else m.moveTo(px, py); });
    m.closePath(); m.fill(); m.filter = 'none';
    t.globalCompositeOperation = 'destination-in'; t.drawImage(this.mask, 0, 0); t.globalCompositeOperation = 'source-over';
    // 3. place it on the poster face, upright like the poster face, scaled to fill the slot slightly larger
    const s = this.slot, scale = Math.max(s.w / fw, s.h / fh) * 1.2;       // a little larger: covers the poster face's forehead and hairline
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    o.save();
    o.translate(s.cx, s.cy - s.h * 0.07);
    o.rotate(((s.tilt - ol.tilt * 0.55) * Math.PI) / 180);
    o.scale(scale, scale);
    o.drawImage(this.tmp, 0, 0, tw, th, (bx - cx), (by - cy), bw, bh);
    o.restore();
  }
}
