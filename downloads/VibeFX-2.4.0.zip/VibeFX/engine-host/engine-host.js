// Runs inside a hidden extension iframe (its own origin and CSP, so the call site's content
// security policy cannot block WebAssembly). Receives frames from the page, returns processed
// frames. Nothing here talks to the network: the extension CSP only allows 'self'.

import { VibeEngine } from '../engine/engine.js';

const NS = '__vibefx';
const parentWin = window.parent;
let parentOrigin = '*';
try { if (location.ancestorOrigins && location.ancestorOrigins[0]) parentOrigin = location.ancestorOrigins[0]; } catch (_) {}

const send = (msg, transfer) => { try { parentWin.postMessage({ [NS]: 1, ...msg }, parentOrigin, transfer || []); } catch (_) {} };

let engine = null;
let statusTimer = null;

function start(settings) {
  if (engine) return;
  const baseUrl = new URL('../', import.meta.url).href;
  engine = new VibeEngine({
    baseUrl, settings,
    log: (lvl, ...a) => { if (lvl === 'error' || lvl === 'warn') send({ t: 'log', lvl, text: a.map(String).join(' ').slice(0, 500) }); },
    onEvent: (e) => send({ t: 'event', e }),
  });
  send({ t: 'engine-ready' });                 // renderers usable now; models report separately
  engine.init().then(() => send({ t: 'models-done', models: engine.modelStatus() }));
  statusTimer = setInterval(() => send({ t: 'status', s: engine.getStatus() }), 1000);
}

window.addEventListener('message', async (ev) => {
  if (ev.source !== parentWin) return;
  const m = ev.data;
  if (!m || m[NS] !== 1) return;
  try {
    switch (m.t) {
      case 'init': start(m.settings); break;
      case 'settings': if (engine) engine.setSettings(m.patch); break;
      case 'media': if (engine) engine.setMedia(m.media).catch((e) => send({ t: 'log', lvl: 'warn', text: 'media: ' + String(e && e.message || e) })); break;
      case 'command': if (engine) { const r = engine.command(m.name, m.opts || {}, m.source || 'ui'); send({ t: 'command-result', name: m.name, r, rid: m.rid }); } break;
      case 'frame': {
        const bmp = m.bmp;
        if (!engine) { send({ t: 'frame-result', id: m.id, error: 'engine-not-started' }); try { bmp.close(); } catch (_) {} break; }
        const r = engine.processFrame(bmp, m.tEpoch);
        if (r.meta.error) { send({ t: 'frame-result', id: m.id, error: r.meta.error }); try { r.frame.close(); } catch (_) {} break; }
        if (r.meta.idle) {                          // nothing was drawn: the page keeps its own frame
          send({ t: 'frame-result', id: m.id, idle: true, active: false, ms: r.meta.ms });
          try { r.frame.close(); } catch (_) {}
        } else send({ t: 'frame-result', id: m.id, bmp: r.frame, active: true, ms: r.meta.ms }, [r.frame]);
        break;
      }
    }
  } catch (e) {
    send({ t: 'log', lvl: 'error', text: 'host: ' + String(e && e.message || e) });
    if (m.t === 'frame') send({ t: 'frame-result', id: m.id, error: String(e && e.message || e) });
  }
});

send({ t: 'hello' });
window.addEventListener('pagehide', () => { if (statusTimer) clearInterval(statusTimer); try { engine && engine.destroy(); } catch (_) {} });
