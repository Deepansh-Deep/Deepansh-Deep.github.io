// Turns per-frame hand and pose results into gesture events. Everything is time based (milliseconds
// passed in), never frame counted, so it behaves the same at 10 and at 60 analysed frames per second.
//
// This file only recognises poses. Which effect a pose starts is a setting (settings.gestureMap, factory
// defaults in core/settings.js: DEFAULT_GESTURE_MAP), so users can reassign them in the popup.
//
// Inputs: hands is an array when the hand model ran on this frame, null when it did not (state is held,
// NOT treated as "no hand"); pose is landmarks, null (ran, nobody) or undefined (did not run).
// Events: {type, t, confidence, kind: 'start' | 'hold'}. 'start' fires once per gesture after it has been
// held for its hold time; 'hold' repeats while the gesture stays up so effects can stay on while you pose.

import { analyzeHand, staticPoses, isFourFingersOpen } from './hand-pose.js';
import { DEFAULT_GESTURE_MAP } from '../core/settings.js';

export const GESTURE_FX = DEFAULT_GESTURE_MAP;   // factory mapping; the user's own choices live in settings.gestureMap
export const GESTURE_LABEL = {
  wave: 'Bye wave', indexUp: 'Index finger', handsUp: 'Both hands up', openPalm: 'Open palm (5 fingers)', facePalm: 'Hand on face',
  pinkyUp: 'Little finger', handsJoined: 'Hands joined', thumbUp: 'Thumb up', victory: 'Index + middle finger',
  threeFingers: '3 fingers', fourFingers: '4 fingers', okSign: 'OK sign', rockOn: 'Rock on', shaka: 'Shaka (thumb + little finger)',
};

// how long a pose must be held before it counts (ms) at sensitivity "normal"
const HOLD = { indexUp: 240, victory: 240, pinkyUp: 260, thumbUp: 280, openPalm: 450, handsUp: 280, handsJoined: 300, facePalm: 260, wave: 0, threeFingers: 260, fourFingers: 650, okSign: 300, rockOn: 280, shaka: 300 };
const PRIORITY = ['facePalm', 'handsJoined', 'wave', 'handsUp', 'okSign', 'rockOn', 'shaka', 'threeFingers', 'victory', 'thumbUp', 'pinkyUp', 'indexUp', 'fourFingers', 'openPalm'];
const SENS = { careful: 1.5, normal: 1, fast: 0.65 };

export const TIMING = {
  gapMs: 170,           // a pose may drop out for this long (detector flicker) without restarting its hold timer
  rearmMs: 380,         // a gesture must be gone this long before it can start again
  cooldownMs: 650,      // after any gesture starts, no other gesture may start for this long
  handStaleMs: 320,     // hand data older than this is not used
  poseStaleMs: 700,
  waveWindowMs: 1000, waveMinSwing: 0.8, waveMinReversals: 2, waveSwingStep: 0.32,
  steadyTravel: 0.55,   // open palm counts as "held" only if the hand moved less than this (in palm sizes) over 300 ms
  joinedHands: 1.9,     // palm-centre distance, in palm sizes
  joinedWrists: 0.5,    // pose: wrist distance, in shoulder widths
};

class Track {
  constructor() { this.first = null; this.last = null; this.armed = true; this.active = false; this.conf = 0; this.disarmedAt = null; }
}

export class GestureEngine {
  constructor(opts = {}) {
    this.enabled = opts.enabled !== false;
    this.setSensitivity(opts.sensitivity || 'normal');
    this.timing = { ...TIMING, ...(opts.timing || {}) };
    this.tracks = Object.fromEntries(Object.keys(GESTURE_FX).map((g) => [g, new Track()]));
    this.cooldownUntil = 0;
    this.handCands = new Map(); this.handAt = -1e9;     // gesture -> confidence, from the last hand result
    this.poseCands = new Map(); this.poseAt = -1e9;
    this.hist = [];                                      // per-hand motion histories for wave / steadiness
    this.handIv = 0; this.poseIv = 0; this.gapNow = TIMING.gapMs;
    this.face = null;                                    // {x, y, size} anchor from the pose model
    this.lastHands = []; this.lastFired = null; this.fired = 0;
    this.stats = { frames: 0, handFrames: 0, poseFrames: 0 };
  }

  setSensitivity(s) { this.sensName = SENS[s] ? s : 'normal'; this.mult = SENS[this.sensName]; }
  configure(o) {
    if (o.sensitivity) this.setSensitivity(o.sensitivity);
    if (o.enabled !== undefined) { this.enabled = !!o.enabled; if (!this.enabled) this.reset(); }
  }
  reset() {
    for (const k of Object.keys(this.tracks)) this.tracks[k] = new Track();
    this.handCands.clear(); this.poseCands.clear(); this.hist = []; this.cooldownUntil = 0;
  }

  update(t, { hands = null, pose, w, h }) {
    if (!this.enabled) return [];
    this.stats.frames++;
    const T = this.timing;
    if (hands !== null) { this.stats.handFrames++; this._rate('handIv', t - this.handAt); this._hands(t, hands, w, h); }
    if (pose !== undefined) { this.stats.poseFrames++; this._rate('poseIv', t - this.poseAt); this._pose(t, pose, w, h); }
    // On a slow machine the models answer rarely. Flicker tolerance and staleness follow the measured interval,
    // otherwise a hold could never build up between two measurements.
    const slow = Math.min(1600, 2.2 * Math.max(this.handIv, this.poseIv));
    this.gapNow = Math.max(T.gapMs, slow);
    // stale data counts as "not seen"
    const handsFresh = t - this.handAt <= Math.max(T.handStaleMs, Math.min(1600, 2.2 * this.handIv)), poseFresh = t - this.poseAt <= Math.max(T.poseStaleMs, Math.min(2000, 2.2 * this.poseIv));
    // each entry carries the time of the measurement it came from: reusing an old result never extends a hold
    const present = new Map();
    const put = (g, c, at) => { const o = present.get(g); if (!o || at > o.at) present.set(g, { c, at }); };
    if (handsFresh) for (const [g, c] of this.handCands) put(g, c, this.handAt);
    if (poseFresh) for (const [g, c] of this.poseCands) put(g, c, this.poseAt);
    return this._advance(t, present);
  }

  _rate(key, dt) { if (dt > 0 && dt < 2500) this[key] = this[key] ? this[key] * 0.8 + dt * 0.2 : dt; }

  // ------------------------------------------------------------ hand model results
  _hands(t, hands, w, h) {
    const T = this.timing;
    this.handAt = t;
    const cands = new Map();
    const A = hands.map((hd) => analyzeHand(hd.landmarks, w, h)).filter(Boolean);
    this.lastHands = A.map((a) => ({ fingers: { ...a.fingers }, poses: staticPoses(a) }));
    this._lastPalms = A.map((a) => a.palm);
    const motion = this._motion(t, A);
    A.forEach((a, i) => {
      const poses = staticPoses(a);
      for (const p of poses) {
        if (p === 'openPalm' && !(motion[i] && motion[i].travel < T.steadyTravel)) continue;   // moving open hand is a wave, not "5 fingers"
        cands.set(p, Math.max(cands.get(p) || 0, 0.9));
      }
      if (motion[i] && motion[i].waving && isFourFingersOpen(a) && a.pointsUp > -0.25) cands.set('wave', 0.9);
    });
    // two hands pressed or clasped together
    if (A.length >= 2) {
      const [a, b] = A, sc = (a.scale + b.scale) / 2;
      if (Math.hypot(a.palm.x - b.palm.x, a.palm.y - b.palm.y) / sc < T.joinedHands) cands.set('handsJoined', 0.85);
    }
    // a hand over the face (needs the face anchor from the pose model)
    if (this.face) for (const a of A) if (this._overFace(a)) cands.set('facePalm', 0.85);
    this.handCands = cands;
  }

  // Per hand motion: how far it moved over the last 300 ms and whether it is swinging side to side.
  _motion(t, A) {
    const T = this.timing, out = [];
    const used = new Set();
    A.forEach((a) => {
      let best = -1, bd = 1e9;
      this.hist.forEach((hh, i) => {
        if (used.has(i)) return;
        const d = Math.hypot(hh.pts[hh.pts.length - 1].px - a.palm.x, hh.pts[hh.pts.length - 1].py - a.palm.y) / a.scale;
        if (d < bd && d < 2.6) { bd = d; best = i; }
      });
      let hh;
      if (best >= 0) { hh = this.hist[best]; used.add(best); }
      else { hh = { pts: [] }; this.hist.push(hh); used.add(this.hist.length - 1); }
      hh.pts.push({ t, px: a.palm.x, py: a.palm.y, tx: a.tipMid.x, s: a.scale });
      hh.seen = t;
      while (hh.pts.length && t - hh.pts[0].t > T.waveWindowMs) hh.pts.shift();
      out.push(this._analyseHist(t, hh));
    });
    this.hist = this.hist.filter((hh) => t - hh.seen < 600);
    return out;
  }

  _analyseHist(t, hh) {
    const T = this.timing, pts = hh.pts;
    const s = pts.reduce((m, p) => m + p.s, 0) / pts.length;
    const recent = pts.filter((p) => t - p.t <= 300);
    let travel = 0;
    for (let i = 1; i < recent.length; i++) travel += Math.hypot(recent[i].px - recent[i - 1].px, recent[i].py - recent[i - 1].py);
    travel /= s;
    // side to side swing of the fingertip: count direction reversals larger than a step
    let dir = 0, ext = pts[0] ? pts[0].tx : 0, rev = 0, minx = 1e9, maxx = -1e9;
    for (const p of pts) {
      minx = Math.min(minx, p.tx); maxx = Math.max(maxx, p.tx);
      const dx = p.tx - ext;
      if (dir >= 0 && dx < -T.waveSwingStep * s) { if (dir === 1) rev++; dir = -1; ext = p.tx; }
      else if (dir <= 0 && dx > T.waveSwingStep * s) { if (dir === -1) rev++; dir = 1; ext = p.tx; }
      else if ((dir === 1 && p.tx > ext) || (dir === -1 && p.tx < ext)) ext = p.tx;
    }
    const swing = (maxx - minx) / s;
    return { travel, waving: rev >= T.waveMinReversals && swing >= T.waveMinSwing && pts.length >= 5 };
  }

  // ------------------------------------------------------------ pose model results
  _pose(t, pose, w, h) {
    const T = this.timing;
    this.poseAt = t;
    const cands = new Map();
    if (pose) {
      const v = (i) => (pose[i] && pose[i].visibility !== undefined ? pose[i].visibility : 1);
      const sw = Math.abs(pose[11].x - pose[12].x) * w;
      if (v(11) > 0.4 && v(12) > 0.4 && sw > 12) {
        const lift = (i, s) => (pose[s].y - pose[i].y) * h / sw;
        if (v(15) > 0.3 && v(16) > 0.3) {
          if (lift(15, 11) > 0.25 && lift(16, 12) > 0.25) cands.set('handsUp', 0.85);
          const wd = Math.hypot(pose[15].x - pose[16].x, (pose[15].y - pose[16].y) * h / w) * w / sw;
          const front = lift(15, 11) < 0.15 && lift(16, 12) < 0.15 && lift(15, 11) > -1.7 && lift(16, 12) > -1.7;
          if (wd < T.joinedWrists && front) cands.set('handsJoined', 0.8);
        }
      }
      this._updateFace(pose, w, h);
    }
    this.poseCands = cands;
  }

  // Face anchor from eyes / nose / ears. It stops updating while a hand is near it, because a hand over
  // the face confuses the pose model; the last good anchor is kept for a facepalm check.
  _updateFace(pose, w, h) {
    const v = (i) => (pose[i] && pose[i].visibility !== undefined ? pose[i].visibility : 1);
    if (v(2) < 0.4 || v(5) < 0.4 || v(0) < 0.4) return;
    const e1 = { x: pose[2].x * w, y: pose[2].y * h }, e2 = { x: pose[5].x * w, y: pose[5].y * h };
    const eye = { x: (e1.x + e2.x) / 2, y: (e1.y + e2.y) / 2 };
    const ed = Math.hypot(e1.x - e2.x, e1.y - e2.y);
    let size = ed * 2.3;
    if (v(7) > 0.4 && v(8) > 0.4) size = Math.max(size, Math.hypot((pose[7].x - pose[8].x) * w, (pose[7].y - pose[8].y) * h));
    if (!(size > 10)) return;
    const near = this.lastHands.length && this._handsNear(eye, size);
    if (near && this.face) return;
    this.face = this.face ? { x: this.face.x * 0.6 + eye.x * 0.4, y: this.face.y * 0.6 + eye.y * 0.4, size: this.face.size * 0.6 + size * 0.4 } : { x: eye.x, y: eye.y, size };
  }
  _handsNear(eye, size) {
    return (this._lastPalms || []).some((p) => Math.hypot(p.x - eye.x, p.y - eye.y) < size * 1.3);
  }
  _overFace(a) {
    const f = this.face; if (!f) return false;
    const dx = Math.abs(a.palm.x - f.x) / f.size, dy = (a.palm.y - f.y) / f.size;
    const ratio = a.scale / f.size;
    return dx < 0.8 && dy > -1.05 && dy < 0.4 && ratio > 0.3 && ratio < 1.7;
  }

  // ------------------------------------------------------------ hold timers, cooldown, exclusivity
  _advance(t, present) {
    const T = this.timing, events = [];
    const startable = [];
    for (const g of Object.keys(this.tracks)) {
      const tr = this.tracks[g];
      if (present.has(g)) {
        const { c, at } = present.get(g);
        if (tr.first === null || at - tr.last > this.gapNow) tr.first = at;
        tr.last = Math.max(tr.last ?? at, at); tr.conf = c;
        if (tr.active) events.push({ type: g, t, confidence: tr.conf, kind: 'hold' });
        else if (tr.armed && tr.last - tr.first >= HOLD[g] * this.mult) {
          // a hand left open at the end of a wave must not turn into "5 fingers"
          if (g === 'openPalm' && (present.has('wave') || (this.tracks.wave.last !== null && t - this.tracks.wave.last < 900))) { tr.first = tr.last; continue; }
          startable.push(g);
        }
      } else {
        if (tr.last !== null && t - tr.last > this.gapNow) { tr.first = null; tr.active = false; }
        if (!tr.armed) {
          const ref = tr.last !== null && (tr.disarmedAt === null || tr.last > tr.disarmedAt) ? tr.last : tr.disarmedAt;
          if (ref !== null && t - ref >= T.rearmMs && !present.has(g)) tr.armed = true;
        }
      }
    }
    if (startable.length) {
      if (t < this.cooldownUntil) {
        for (const g of startable) this.tracks[g].first = this.tracks[g].last;       // must hold again after the cooldown
      } else {
        const g = PRIORITY.find((p) => startable.includes(p));
        const tr = this.tracks[g];
        tr.armed = false; tr.active = true; this.cooldownUntil = t + T.cooldownMs;
        events.push({ type: g, t, confidence: tr.conf, kind: 'start' });
        this.lastFired = { gesture: g, t }; this.fired++;
        // the others must be released and held again, and an open hand left after a wave must not become "5 fingers"
        for (const o of Object.keys(this.tracks)) if (o !== g) { const x = this.tracks[o]; x.first = null; if (present.has(o)) { x.armed = false; x.disarmedAt = t; } }
      }
    }
    return events;
  }

  poll(t) { return this.enabled ? this.update(t, { hands: null, pose: undefined, w: 1, h: 1 }) : []; }

  status() {
    const present = [];
    for (const [g, tr] of Object.entries(this.tracks)) if (tr.first !== null) present.push({ g, ms: Math.round((tr.last ?? 0) - tr.first), armed: tr.armed, active: tr.active });
    return { enabled: this.enabled, sensitivity: this.sensName, hands: this.lastHands, present, lastFired: this.lastFired, fired: this.fired, face: !!this.face, stats: { ...this.stats } };
  }
}
