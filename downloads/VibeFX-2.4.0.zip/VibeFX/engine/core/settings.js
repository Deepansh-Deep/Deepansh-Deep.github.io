// Single source of truth for settings: defaults, validation and migration. Used by the extension
// popup, the engine and the tests, so they cannot drift apart.

// The hand and body poses the camera can recognise, and the effects a pose may start.
export const GESTURE_NAMES = ['wave', 'indexUp', 'openPalm', 'handsUp', 'facePalm', 'pinkyUp', 'handsJoined', 'thumbUp', 'victory', 'threeFingers', 'fourFingers', 'okSign', 'rockOn', 'shaka'];
export const EFFECT_NAMES = ['vanish', 'cinema', 'sad', 'punisher', 'money', 'deal', 'banner', 'confetti', 'hearts', 'flames', 'freeze'];
// The user's own memes are effects too. Their ids look like c_k3f9 and are listed in settings.customs.
export const CUSTOM_ID = /^c_[a-z0-9]{2,10}$/;
export const MAX_CUSTOMS = 40;
// Keyboard shortcuts are Alt (Option on Mac) + one key, stored as KeyboardEvent.code. Keys the browser keeps for itself are refused.
export const KEY_CODE = /^(Key[A-Z]|Digit[0-9]|Numpad[0-9]|F([2-9]|1[0-2])|Minus|Equal|Comma|Period|Slash|Semicolon|Quote|Backquote|BracketLeft|BracketRight|Backslash|ArrowUp|ArrowDown)$/;
export const RESERVED_KEYS = ['KeyD', 'KeyE', 'KeyF', 'F4'];       // Alt+D address bar, Alt+E / Alt+F browser menu, Alt+F4 close window
export const validKey = (c) => typeof c === 'string' && KEY_CODE.test(c) && !RESERVED_KEYS.includes(c);
export const KEY_ACTIONS = [...EFFECT_NAMES, 'pauseGestures'];
// Default gesture pack: one pose per effect. 'none' = the pose does nothing until the user assigns it.
export const DEFAULT_GESTURE_MAP = Object.freeze({
  wave: 'vanish', handsUp: 'cinema', facePalm: 'sad', handsJoined: 'punisher', victory: 'money',
  threeFingers: 'deal', fourFingers: 'banner', okSign: 'confetti', shaka: 'hearts', rockOn: 'flames',
  openPalm: 'freeze',                       // 5 fingers: stop everything (picture and, by default, the mic)
  indexUp: 'none', pinkyUp: 'none', thumbUp: 'none',
});

export const DEFAULTS = Object.freeze({
  version: 4,
  enabled: true,                 // master switch: when false the camera passes through untouched
  gestures: {
    enabled: true,
    sensitivity: 'normal',       // careful | normal | fast (how long a pose must be held)
  },
  gestureMap: { ...DEFAULT_GESTURE_MAP },   // pose -> effect (or 'none'), editable in the popup
  autoHideSec: 6,                // effects other than vanish switch off by themselves this long after the gesture ends; 0 = stay until toggled
  vanish: {
    durationSec: 1.5, returnSec: 1.2,
    endText: 'Goodbye',            // shown on the black screen after the dust settles ('' = nothing)
  },
  banner: { name: 'Your Name', role: 'Your title' },       // lower-third name banner
  muteOnFreeze: true,            // freeze also silences the microphone track (the call site's own mic button will not show it)
  touchUp: false,                // auto brightness and contrast (keeps the engine busy on every frame)
  background: { mode: 'none' },  // none | blur | image (the picture is uploaded in the popup)
  keys: {                        // Alt + key shortcuts, '' = none. Handled in the page, so they work in any call tab.
    vanish: 'KeyV', cinema: '', sad: '', punisher: '', money: '', deal: '', banner: '', confetti: '', hearts: '', flames: '',
    freeze: 'KeyZ', pauseGestures: 'KeyG',
  },
  customs: [],                   // the user's own memes: [{id, name, mode: 'full'|'behind', key}], pictures live in vibefx.media under the same id
  quality: 'auto',               // auto | high | balanced | low
  hints: true,                   // small on-page notice when a gesture is recognised (never part of your video)
  debug: false,                  // draws diagnostics ON the outgoing video, so keep it off in calls
});

const ENUMS = {
  'gestures.sensitivity': ['careful', 'normal', 'fast'],
  'background.mode': ['none', 'blur', 'image'],
  quality: ['auto', 'high', 'balanced', 'low'],
};
const RANGES = { autoHideSec: [0, 60], 'vanish.durationSec': [0.6, 5], 'vanish.returnSec': [0.6, 5] };

function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }

// Deep-merge `patch` into a copy of `base`, keeping only known keys and valid values.
export function sanitize(patch, base = DEFAULTS, path = '') {
  const out = {};
  for (const k of Object.keys(base)) {
    const full = path ? `${path}.${k}` : k;
    const def = base[k];
    const has = isObj(patch) && Object.prototype.hasOwnProperty.call(patch, k);
    const v = has ? patch[k] : undefined;
    if (full === 'gestureMap' || full === 'keys') { out[k] = def; continue; }       // checked below, they depend on the custom list
    if (isObj(def)) { out[k] = sanitize(has ? v : {}, def, full); continue; }
    if (full === 'customs') { out[k] = []; continue; }
    if (v === undefined) { out[k] = def; continue; }
    if (typeof def === 'boolean') out[k] = typeof v === 'boolean' ? v : def;
    else if (typeof def === 'number') {
      const r = RANGES[full];
      out[k] = typeof v === 'number' && Number.isFinite(v) ? (r ? Math.min(r[1], Math.max(r[0], v)) : v) : def;
    } else if (typeof def === 'string') {
      if (ENUMS[full]) out[k] = ENUMS[full].includes(v) ? v : def;
      else out[k] = typeof v === 'string' ? v.slice(0, 80) : def;
    } else out[k] = def;
  }
  if (path === '') {
    // custom memes
    const used = new Set();
    const list = isObj(patch) && Array.isArray(patch.customs) ? patch.customs : [];
    for (const c of list) {
      if (out.customs.length >= MAX_CUSTOMS) break;
      if (!isObj(c) || typeof c.id !== 'string' || !CUSTOM_ID.test(c.id) || used.has(c.id)) continue;
      used.add(c.id);
      out.customs.push({ id: c.id, name: typeof c.name === 'string' ? c.name.slice(0, 40) : 'Meme', mode: c.mode === 'behind' ? 'behind' : 'full', key: validKey(c.key) ? c.key : '' });
    }
    // gesture -> effect: built-in effect, one of the user's memes, or none
    const pm = isObj(patch) && isObj(patch.gestureMap) ? patch.gestureMap : {};
    out.gestureMap = {};
    for (const g of GESTURE_NAMES) {
      const v = pm[g];
      out.gestureMap[g] = v === undefined ? DEFAULT_GESTURE_MAP[g] : (v === 'none' || EFFECT_NAMES.includes(v) || used.has(v)) ? v : DEFAULT_GESTURE_MAP[g];
    }
    // shortcut keys: each key belongs to one action; the first one listed keeps it
    const pk = isObj(patch) && isObj(patch.keys) ? patch.keys : {};
    out.keys = {}; const taken = new Set();
    const claim = (want) => { if (validKey(want) && !taken.has(want)) { taken.add(want); return want; } return ''; };
    for (const a of KEY_ACTIONS) out.keys[a] = claim(pk[a] === undefined ? DEFAULTS.keys[a] : pk[a]);
    for (const c of out.customs) c.key = claim(c.key);
  }
  return out;
}

export function mergeSettings(current, patch) {
  const merged = JSON.parse(JSON.stringify(current));
  (function walk(dst, src) {
    for (const k of Object.keys(src || {})) {
      if (isObj(src[k]) && isObj(dst[k])) walk(dst[k], src[k]); else dst[k] = src[k];
    }
  })(merged, patch);
  return sanitize(merged);
}

export function defaults() { return sanitize({}); }
