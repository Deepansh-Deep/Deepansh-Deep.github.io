// Person mask handling: temporal smoothing, soft edge curve, grown (dilated) mask for cut-outs,
// body metrics (centroid, bounding box, boundary points) used by the effects.

import { makeCanvas, ctx2d, smoothstep } from './util.js';

export class MaskProcessor {
  constructor() {
    this.w = 0; this.h = 0;
    this.valid = false;       // a mask was produced recently
    this.fraction = 0;        // share of the frame that is person (0..1)
    this.centroid = null;     // normalised {x,y}
    this.bbox = null;         // normalised {x0,y0,x1,y1}
    this.boundary = [];       // normalised boundary points (for lightning anchors)
    this.lastUpdate = -1e9;
    this.version = 0;
  }

  _alloc(w, h) {
    this.w = w; this.h = h;
    this.sm = new Float32Array(w * h);
    this.alpha = new Uint8ClampedArray(w * h);
    this.canvas = makeCanvas(w, h);         // alpha = person (soft edge)
    this.cctx = ctx2d(this.canvas);
    this.img = this.cctx.createImageData(w, h);
    for (let i = 0; i < this.img.data.length; i += 4) { this.img.data[i] = this.img.data[i + 1] = this.img.data[i + 2] = 255; }
    this.grown = makeCanvas(w, h);          // alpha = dilated, feathered person (for removing the person)
    this.gctx = ctx2d(this.grown);
    this.low = makeCanvas(w, h); this.lctx = ctx2d(this.low); this.lowImg = this.lctx.createImageData(w, h);
    this.tmp = makeCanvas(w, h);
    this.tctx = ctx2d(this.tmp);
  }

  // m: {width,height,data:Float32Array} from the pose model. t: ms.
  update(m, t) {
    if (!m || !m.data) return;
    if (m.width !== this.w || m.height !== this.h) this._alloc(m.width, m.height);
    const { sm, alpha, img, lowImg } = this;
    const d = m.data, n = d.length;
    let cnt = 0, sx = 0, sy = 0, x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
    const w = this.w, h = this.h;
    const first = !this.valid;
    for (let i = 0; i < n; i++) {
      const v = d[i];
      const diff = Math.abs(v - sm[i]);
      // adaptive smoothing: stable regions are smoothed, fast changes follow immediately
      sm[i] = first ? v : v + (sm[i] - v) * (diff > 0.4 ? 0.15 : 0.5);
      const a = smoothstep(0.28, 0.72, sm[i]);
      alpha[i] = a * 255;
      img.data[i * 4 + 3] = alpha[i];
      lowImg.data[i * 4 + 3] = smoothstep(0.04, 0.24, sm[i]) * 255;
      if (a > 0.5) {
        cnt++;
        const x = i % w, y = (i / w) | 0;
        sx += x; sy += y;
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      }
    }
    this.cctx.putImageData(img, 0, 0);
    this.lctx.putImageData(lowImg, 0, 0);
    this.fraction = cnt / n;
    this.valid = true; this.lastUpdate = t; this.version++;
    if (cnt > 20) {
      this.centroid = { x: sx / cnt / w, y: sy / cnt / h };
      this.bbox = { x0: x0 / w, y0: y0 / h, x1: (x1 + 1) / w, y1: (y1 + 1) / h };
    } else { this.centroid = null; this.bbox = null; }
    this._rebuildGrown();
    this._boundary = null;
  }

  // Dilate + feather: draw the soft mask several times with a blur, so alpha saturates a few
  // pixels outside the silhouette. This is what removes hair/edge pixels when vanishing.
  _rebuildGrown() {
    const g = this.gctx, w = this.w, h = this.h;
    g.clearRect(0, 0, w, h);
    g.filter = `blur(${Math.max(1.5, w / 120)}px)`;
    for (let k = 0; k < 5; k++) g.drawImage(this.canvas, 0, 0);
    // weak-confidence parts of the body (arms, sleeves, objects held close) are included too, so the
    // person is removed fully even where the segmentation model is unsure
    g.filter = `blur(${Math.max(3, w / 60)}px)`;
    for (let k = 0; k < 3; k++) g.drawImage(this.low, 0, 0);
    g.filter = 'none';
  }

  has(t, maxAgeMs = 600) { return this.valid && t - this.lastUpdate < maxAgeMs && this.fraction > 0.012 && this.fraction < 0.92; }

  clear() { this.valid = false; this.fraction = 0; this.centroid = null; this.bbox = null; this.boundary = []; this._boundary = null; }

  // Boundary cells as normalised points; recomputed lazily, strided for speed.
  getBoundary(maxPoints = 260) {
    if (this._boundary) return this._boundary;
    const pts = [], { w, h, alpha } = this;
    if (!this.valid) return (this._boundary = pts);
    const stride = 2;
    for (let y = 2; y < h - 2; y += stride) {
      for (let x = 2; x < w - 2; x += stride) {
        const i = y * w + x;
        if (alpha[i] > 128 && (alpha[i - 3] < 100 || alpha[i + 3] < 100 || alpha[i - 3 * w] < 100 || alpha[i + 3 * w] < 100)) pts.push({ x: x / w, y: y / h });
      }
    }
    // thin out evenly
    if (pts.length > maxPoints) { const k = pts.length / maxPoints; const o = []; for (let i = 0; i < maxPoints; i++) o.push(pts[(i * k) | 0]); this._boundary = o; } else this._boundary = pts;
    return this._boundary;
  }

}
