// MAIN-world script (bundled to content/inject.js by tools/build.mjs).
//
// Wraps navigator.mediaDevices.getUserMedia. For every video track the page asks for, the real camera
// track is replaced by a generated track whose frames come from the VibeFX engine. The page (Meet,
// Zoom web, Teams web ...) therefore sends the processed video, not the raw camera.
//
// Rules this file follows:
//   * raw frames are only forwarded when the status says so (starting / degraded / master switch off);
//     the status is reported to the popup and the toolbar badge, never hidden
//   * the microphone is never touched: gestures are recognised from the camera picture only
//   * stopping the generated track stops the real camera (the camera light goes off)

import { FramePipeline } from '../engine/core/pipeline.js';

(function () {
  const NS = '__vibefx';
  const ENGINE_ID = '__vibefx_engine__';
  if (window.__vibefxMain) return;
  window.__vibefxMain = true;

  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') return;
  const hasInsertable = typeof MediaStreamTrackProcessor === 'function' && typeof MediaStreamTrackGenerator === 'function';

  const epochNow = () => performance.timeOrigin + performance.now();
  const post = (msg) => { try { window.postMessage({ [NS]: 1, from: 'main', ...msg }, window.location.origin); } catch (_) {} };

  // ------------------------------------------------------------------ engine link
  const link = {
    origin: null, win: null, helloSeen: false, ready: false, blocked: false,
    pending: new Map(), nextId: 1, requested: false, settings: {},
    isReady() { return this.ready && !this.blocked; },
    failed() { return this.blocked; },
    engineWin() {
      if (this.win && this.win.closed === false) return this.win;
      const f = document.getElementById(ENGINE_ID);
      this.win = f && f.contentWindow || null;
      return this.win;
    },
    request() {
      if (this.requested) return; this.requested = true;
      post({ type: 'need-engine' });
    },
    toEngine(msg, transfer) {
      const w = this.engineWin();
      if (!w || !this.origin) return false;
      try { w.postMessage({ [NS]: 1, ...msg }, this.origin, transfer || []); return true; } catch (_) { return false; }
    },
    process(input) {
      return new Promise((resolve) => {
        const id = this.nextId++;
        const timer = setTimeout(() => { if (this.pending.delete(id)) resolve({ error: 'no-answer' }); }, 6000);
        this.pending.set(id, { resolve, timer });
        const ok = this.toEngine({ t: 'frame', id, bmp: input.bmp, tEpoch: epochNow() }, [input.bmp]);
        if (!ok) { clearTimeout(timer); this.pending.delete(id); try { input.bmp.close(); } catch (_) {} resolve({ error: 'engine-unreachable' }); }
      });
    },
  };
  const IDLE = { idle: true, close() {} };

  window.addEventListener('message', (ev) => {
    const m = ev.data;
    if (!m || m[NS] !== 1) return;
    if (ev.source === window && m.from === 'bridge') {
      switch (m.type) {
        case 'engine-origin': link.origin = m.origin; break;
        case 'engine-hello': link.helloSeen = true; link.blocked = false; break;
        case 'engine-ready': link.ready = true; link.blocked = false; break;
        case 'engine-failed': link.blocked = true; link.ready = false; micSync(); break;
        case 'settings': link.settings = m.settings || {}; applySettings(); micSync(); break;
        case 'freeze': mic.frozen = !!m.on; micSync(); break;
      }
      return;
    }
    // frames come straight from the engine iframe; only accept them from that exact window
    const w = link.engineWin();
    if (w && ev.source === w && m.t === 'frame-result') {
      const p = link.pending.get(m.id);
      if (!p) { if (m.bmp) try { m.bmp.close(); } catch (_) {} return; }   // late answer after a timeout: drop it
      link.pending.delete(m.id); clearTimeout(p.timer);
      if (m.error) p.resolve({ error: m.error });
      else if (m.idle) p.resolve({ frame: IDLE, meta: { idle: true, active: !!m.active } });
      else p.resolve({ frame: m.bmp, meta: { idle: false, active: true, ms: m.ms } });
    }
  }, true);

  // ------------------------------------------------------------------ settings
  const settingsView = () => ({ enabled: link.settings.enabled !== false });
  const streams = new Set();      // active record per stream: {pipeline, src, gen}
  function applySettings() { /* the engine gets the same settings from the bridge; the pipeline reads `enabled` live */ }

  // ------------------------------------------------------------------ microphone (only while frozen)
  // While the picture is frozen the microphone is silenced too (setting "Mute my mic while frozen").
  // Audio data is never read: only the track's `enabled` flag is switched. The page keeps seeing the value it
  // set itself, so its own mute button logic stays consistent. If the user turns the mic on in the site while
  // frozen, that choice wins until the next freeze. Clones of the track (some sites send a clone) are covered too.
  const mic = { tracks: new Set(), frozen: false, on: false };
  const enabledDesc = Object.getOwnPropertyDescriptor(MediaStreamTrack.prototype, 'enabled');
  const micWanted = () => mic.frozen && link.settings.muteOnFreeze !== false && link.settings.enabled !== false && !link.blocked;
  function micApply(rec) { try { enabledDesc.set.call(rec.track, rec.page && !rec.mute); } catch (_) {} }
  function micRegister(t, pageValue) {
    if (!t || t.kind !== 'audio' || !enabledDesc || typeof enabledDesc.set !== 'function') return;
    for (const r of mic.tracks) if (r.track === t) return;
    const rec = { track: t, page: pageValue === undefined ? enabledDesc.get.call(t) : !!pageValue, mute: micWanted() };
    try {
      Object.defineProperty(t, 'enabled', {
        configurable: true,
        get() { return rec.page; },
        set(v) { const was = rec.page; rec.page = !!v; if (rec.mute && rec.page && !was) rec.mute = false; micApply(rec); reportNow(); },
      });
    } catch (_) { return; }
    mic.tracks.add(rec);
    t.addEventListener('ended', () => { mic.tracks.delete(rec); reportNow(); });
    micApply(rec);
  }
  function micSync() {
    try {
      const want = micWanted(), edge = want && !mic.on; mic.on = want;
      for (const rec of mic.tracks) {
        if (rec.track.readyState === 'ended') { mic.tracks.delete(rec); continue; }
        if (edge) rec.mute = true; else if (!want) rec.mute = false;
        micApply(rec);
      }
    } catch (_) { for (const rec of mic.tracks) { rec.mute = false; micApply(rec); } }
    reportNow();
  }
  const micMuted = () => [...mic.tracks].some((r) => r.mute && r.page);
  try {
    const origClone = MediaStreamTrack.prototype.clone;
    MediaStreamTrack.prototype.clone = function clone() {
      const c = origClone.call(this);
      try { const parent = [...mic.tracks].find((r) => r.track === this); if (parent && c.kind === 'audio') micRegister(c, parent.page); } catch (_) {}
      return c;
    };
    MediaStreamTrack.prototype.clone.toString = () => 'function clone() { [native code] }';
  } catch (_) {}

  // ------------------------------------------------------------------ video wrapping
  function wrapVideoTrack(srcTrack) {
    const gen = new MediaStreamTrackGenerator({ kind: 'video' });
    const proc = new MediaStreamTrackProcessor({ track: srcTrack, maxBufferSize: 1 });
    const rec = { src: srcTrack, gen, pipeline: null, state: { state: 'starting', reason: 'engine-loading', stats: {} } };
    streams.add(rec);

    rec.pipeline = new FramePipeline({
      reader: proc.readable.getReader(),
      writer: gen.writable.getWriter(),
      engine: link,
      enabled: () => settingsView().enabled,
      stallMs: 2500,
      convertIn: async (frame) => {
        const w = frame.displayWidth, h = frame.displayHeight;
        const opts = w > 1280 ? { resizeWidth: 1280, resizeHeight: Math.round(h * 1280 / w), resizeQuality: 'low' } : undefined;
        return { bmp: await createImageBitmap(frame, opts) };
      },
      convertOut: async (res, orig) => {
        if (res.idle) return orig;                         // nothing drawn this frame: forward the camera frame itself
        const out = new VideoFrame(res, { timestamp: orig.timestamp, duration: orig.duration == null ? undefined : orig.duration });
        try { res.close(); } catch (_) {}
        return out;
      },
      onState: (st) => { rec.state = st; },
    });

    const finish = () => {
      if (!streams.has(rec)) return;
      streams.delete(rec);
      try { rec.pipeline.stop(); } catch (_) {}
      try { srcTrack.stop(); } catch (_) {}
      reportNow();
    };
    // stopping the track the page holds must stop the real camera
    const origStop = gen.stop.bind(gen);
    gen.stop = () => { try { origStop(); } catch (_) {} finish(); };
    srcTrack.addEventListener('ended', () => { try { origStop(); } catch (_) {} finish(); try { gen.dispatchEvent(new Event('ended')); } catch (_) {} });

    // make the generated track look like the camera to the page
    const def = (k, v) => { try { Object.defineProperty(gen, k, { get: v, configurable: true }); } catch (_) {} };
    def('label', () => srcTrack.label);
    gen.getSettings = () => { try { return { ...srcTrack.getSettings() }; } catch (_) { return {}; } };
    gen.getCapabilities = () => { try { return srcTrack.getCapabilities(); } catch (_) { return {}; } };
    gen.getConstraints = () => { try { return srcTrack.getConstraints(); } catch (_) { return {}; } };
    gen.applyConstraints = (c) => srcTrack.applyConstraints(c);

    rec.pipeline.start();
    return gen;
  }

  // ------------------------------------------------------------------ status to the extension
  function snapshot() {
    const recs = [...streams];
    const worst = recs.find((r) => r.state.state === 'degraded') || recs.find((r) => r.state.state === 'starting') || recs[0];
    return {
      type: 'main-status', streams: recs.length, insertable: hasInsertable,
      pipeline: worst ? { state: worst.state.state, reason: worst.state.reason, stats: worst.pipeline ? { ...worst.pipeline.stats } : {} } : { state: 'none', reason: 'no-camera-stream', stats: {} },
      mode: worst && worst.pipeline ? worst.pipeline.mode : 'passive',
      engine: { ready: link.ready, blocked: link.blocked }, micMuted: micMuted(),
    };
  }
  function reportNow() { post(snapshot()); }
  setInterval(() => { if (streams.size || link.requested) reportNow(); }, 1000);

  // ------------------------------------------------------------------ getUserMedia wrapper
  const origGUM = md.getUserMedia.bind(md);
  async function wrapped(constraints) {
    const stream = await origGUM(constraints);
    try { for (const t of stream.getAudioTracks()) micRegister(t); } catch (_) {}
    try {
      if (!constraints || !constraints.video) return stream;
      const vts = stream.getVideoTracks();
      if (!vts.length) return stream;
      if (!hasInsertable) { post({ type: 'unsupported', why: 'insertable-streams' }); reportNow(); return stream; }
      link.request();
      const out = new MediaStream();
      for (const t of stream.getTracks()) {
        if (t.kind === 'video') out.addTrack(wrapVideoTrack(t));
        else out.addTrack(t);
      }
      reportNow();
      return out;
    } catch (e) {
      // wrapping failed: the page gets the real camera, and the status says so
      post({ type: 'wrap-failed', detail: String(e && e.message || e) });
      return stream;
    }
  }
  const proxied = function getUserMedia(c) { return wrapped(c); };
  Object.defineProperty(proxied, 'name', { value: 'getUserMedia' });
  proxied.toString = () => 'function getUserMedia() { [native code] }';
  try { md.getUserMedia = proxied; } catch (_) {}
  post({ type: 'main-installed', insertable: hasInsertable });
})();
