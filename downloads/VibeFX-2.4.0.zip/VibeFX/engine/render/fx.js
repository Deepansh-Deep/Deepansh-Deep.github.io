// Procedural effects, no pictures needed: confetti, hearts, flames, "deal with it" sunglasses, name banner.
// Every particle position is a pure function of time since the effect started, so dropped frames or a slow
// machine never break the animation.

import { clamp, rng, makeCanvas, ctx2d } from './util.js';

const TAU = Math.PI * 2;
const easeOutBounce = (x) => {
  x = clamp(x); const n1 = 7.5625, d1 = 2.75;
  if (x < 1 / d1) return n1 * x * x;
  if (x < 2 / d1) { x -= 1.5 / d1; return n1 * x * x + 0.75; }
  if (x < 2.5 / d1) { x -= 2.25 / d1; return n1 * x * x + 0.9375; }
  x -= 2.625 / d1; return n1 * x * x + 0.984375;
};
const easeOutCubic = (t) => 1 - Math.pow(1 - clamp(t), 3);

// Pixel-art sunglasses: '#' black, 'w' white shine
function glassesBitmap() {
  const w = 28, h = 7, rows = [];
  const lens = [[0, 11], [0, 11], [0, 11], [1, 10], [2, 9], [3, 8], [4, 7]];
  for (let y = 0; y < h; y++) {
    const r = new Array(w).fill(' ');
    for (let x = lens[y][0]; x <= lens[y][1]; x++) { r[x] = '#'; r[w - 1 - x] = '#'; }
    if (y === 0) r.fill('#');
    if (y === 1) for (let x = 12; x <= 15; x++) r[x] = '#';
    rows.push(r);
  }
  for (const [x, y] of [[2, 1], [3, 1], [4, 1], [2, 2], [17, 1], [18, 1], [19, 1], [17, 2]]) rows[y][x] = 'w';
  const c = makeCanvas(w, h), g = ctx2d(c), img = g.createImageData(w, h);
  rows.forEach((r, y) => r.forEach((ch, x) => {
    const i = (y * w + x) * 4;
    if (ch === '#') { img.data[i] = 8; img.data[i + 1] = 8; img.data[i + 2] = 10; img.data[i + 3] = 255; }
    else if (ch === 'w') { img.data[i] = 245; img.data[i + 1] = 245; img.data[i + 2] = 250; img.data[i + 3] = 255; }
  }));
  g.putImageData(img, 0, 0);
  return c;
}

function sprite(r, g, b) {
  const c = makeCanvas(64, 64), x = ctx2d(c);
  const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, `rgba(${r},${g},${b},1)`); gr.addColorStop(0.4, `rgba(${r},${g},${b},0.55)`); gr.addColorStop(1, `rgba(${r},${g},${b},0)`);
  x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
  return c;
}

export class FxRenderer {
  constructor() { this.W = 0; this.H = 0; this.eye = null; }

  setup(W, H) {
    this.W = W; this.H = H;
    const R = rng(11);
    const palette = ['#ff3b6b', '#ffd23f', '#3bceac', '#4d9de0', '#b565f5', '#ff8c42', '#ffffff'];
    this.confetti = Array.from({ length: 160 }, () => ({
      x: R(), d: R.range(0, 1.1), v: R.range(0.32, 0.75), sway: R.range(6, 30), sp: R.range(1.2, 3.2),
      rot: R.range(0, TAU), spin: R.range(-7, 7), w: R.range(0.011, 0.022), h: R.range(0.006, 0.011), c: palette[(R() * palette.length) | 0],
    }));
    const hp = ['#ff2e63', '#ff5c8a', '#ff8fab', '#ff3b3b', '#ffb3c6'];
    this.hearts = Array.from({ length: 28 }, () => ({
      x: R.range(0.04, 0.96), d: R.range(0, 3.2), v: R.range(0.17, 0.32), sway: R.range(0.01, 0.04), sp: R.range(1, 2.6), s: R.range(0.035, 0.1), c: hp[(R() * hp.length) | 0],
    }));
    this.flames = Array.from({ length: 150 }, () => ({ x: R(), ph: R(), life: R.range(0.8, 1.5), r0: R.range(0.04, 0.085), hgt: R.range(0.2, 0.42), wob: R.range(0, TAU) }));
    this.spr = { y: sprite(255, 236, 160), o: sprite(255, 140, 30), r: sprite(210, 40, 10) };
    this.glasses = glassesBitmap();
  }

  // ---------------------------------------------------------------- confetti
  drawConfetti(o, level, since, now) {
    if (level <= 0.001) return;
    const { W, H } = this, t = Math.max(0, (now - since) / 1000);
    o.save(); o.globalAlpha = clamp(level);
    for (const p of this.confetti) {
      const cyc = 1.15 / p.v, tt = t - p.d;
      if (tt < 0) continue;
      const u = tt % cyc;
      const x = p.x * W + Math.sin(u * p.sp * 2) * p.sway, y = (-0.06 + u * p.v) * H;
      const a = p.rot + p.spin * u;
      o.save(); o.translate(x, y); o.rotate(a); o.scale(1, Math.cos(u * p.sp * 4));
      o.fillStyle = p.c; o.fillRect(-p.w * W / 2, -p.h * W / 2, p.w * W, p.h * W);
      o.restore();
    }
    o.restore();
  }

  // ---------------------------------------------------------------- hearts
  _heart(o, s) {
    o.beginPath();
    o.moveTo(0, s * 0.38);
    o.bezierCurveTo(s * 0.95, -s * 0.15, s * 0.55, -s * 0.95, 0, -s * 0.38);
    o.bezierCurveTo(-s * 0.55, -s * 0.95, -s * 0.95, -s * 0.15, 0, s * 0.38);
    o.closePath();
  }
  drawHearts(o, level, since, now) {
    if (level <= 0.001) return;
    const { W, H } = this, t = Math.max(0, (now - since) / 1000);
    o.save();
    for (const p of this.hearts) {
      const cyc = 1.25 / p.v, tt = t - p.d;
      if (tt < 0) continue;
      const u = tt % cyc, yN = 1.08 - u * p.v;
      const x = p.x * W + Math.sin(u * p.sp) * p.sway * W, y = yN * H;
      const pulse = 1 + 0.08 * Math.sin(u * 7);
      const a = clamp(u / 0.35) * clamp(yN / 0.25) * clamp(level);
      if (a <= 0.01) continue;
      const s = p.s * H * pulse;
      o.save(); o.globalAlpha = a; o.translate(x, y); o.rotate(Math.sin(u * p.sp * 1.3) * 0.25);
      o.fillStyle = p.c; this._heart(o, s); o.fill();
      o.globalAlpha = a * 0.55; o.fillStyle = '#fff'; o.beginPath(); o.ellipse(-s * 0.38, -s * 0.42, s * 0.14, s * 0.08, -0.7, 0, TAU); o.fill();
      o.restore();
    }
    o.restore();
  }

  // ---------------------------------------------------------------- flames along the bottom
  drawFlames(o, level, since, now) {
    if (level <= 0.001) return;
    const { W, H } = this, t = Math.max(0, (now - since) / 1000), L = clamp(level);
    o.save();
    const gr = o.createLinearGradient(0, H, 0, H * 0.62);
    gr.addColorStop(0, `rgba(150,30,0,${0.55 * L})`); gr.addColorStop(1, 'rgba(150,30,0,0)');
    o.fillStyle = gr; o.fillRect(0, H * 0.62, W, H * 0.38);
    o.globalCompositeOperation = 'lighter';
    for (const p of this.flames) {
      const u = (t / p.life + p.ph) % 1;
      const rise = u * p.hgt * H * (0.6 + 0.4 * Math.sin(p.wob + p.x * 9) ** 2);
      const x = p.x * W + Math.sin(u * 7 + p.wob) * W * 0.012 * (0.4 + u);
      const y = H * 1.0 - rise;
      const r = Math.pow(1 - u, 0.85) * p.r0 * H * (0.6 + 0.8 * L);
      if (r < 1) continue;
      const sp = u < 0.22 ? this.spr.y : u < 0.55 ? this.spr.o : this.spr.r;
      o.globalAlpha = clamp((1 - u) * 1.1) * L;
      o.drawImage(sp, x - r * 1.6, y - r * 1.6, r * 3.2, r * 3.2);
    }
    o.restore();
  }

  // ---------------------------------------------------------------- "deal with it" glasses
  // eye: {cx, cy, dist, tilt} in pixels (centre between the eyes, distance between the eyes, radians)
  setEye(e) {
    if (!e) return;
    if (!this.eye) this.eye = { ...e };
    else { const a = 0.55; for (const k of ['cx', 'cy', 'dist', 'tilt']) this.eye[k] += (e[k] - this.eye[k]) * a; }
  }
  drawGlasses(o, level, since, now) {
    if (level <= 0.001 || !this.eye) return;
    const e = this.eye, t = Math.max(0, (now - since) / 1000);
    const wpx = e.dist * 2.6, k = wpx / 28, hpx = 7 * k;
    const drop = easeOutBounce(t / 0.65);
    const yOff = -(1 - drop) * (e.cy + hpx * 3);
    o.save();
    o.globalAlpha = clamp(level * 4);
    o.translate(e.cx, e.cy + yOff + hpx * 0.05); o.rotate(e.tilt);
    o.imageSmoothingEnabled = false;
    o.shadowColor = 'rgba(0,0,0,0.45)'; o.shadowBlur = k * 2; o.shadowOffsetY = k * 0.8;
    o.drawImage(this.glasses, -wpx / 2, -hpx * 0.5, wpx, hpx);
    o.restore();
  }

  // ---------------------------------------------------------------- lower-third name banner
  drawBanner(o, level, now, name, role) {
    if (level <= 0.001 || (!name && !role)) return;
    const { W, H } = this, p = easeOutCubic(level);
    const ns = H * 0.052, rs = H * 0.032, pad = H * 0.022, gap = H * 0.008;
    o.save();
    o.font = `800 ${ns}px system-ui, "Segoe UI", Arial, sans-serif`;
    const nw = name ? o.measureText(name).width : 0;
    o.font = `500 ${rs}px system-ui, "Segoe UI", Arial, sans-serif`;
    const rw = role ? o.measureText(role).width : 0;
    const w = Math.max(nw, rw) + pad * 2 + W * 0.012, h = pad * 2 + (name ? ns : 0) + (role ? rs + gap : 0);
    const x = W * 0.035 - (1 - p) * (w + W * 0.05), y = H * 0.93 - h;
    o.globalAlpha = clamp(level * 1.5);
    o.shadowColor = 'rgba(0,0,0,0.4)'; o.shadowBlur = H * 0.02; o.shadowOffsetY = H * 0.006;
    o.fillStyle = 'rgba(12,14,22,0.86)'; o.beginPath(); o.roundRect(x, y, w, h, H * 0.014); o.fill();
    o.shadowColor = 'transparent';
    const ag = o.createLinearGradient(0, y, 0, y + h); ag.addColorStop(0, '#7c5cff'); ag.addColorStop(1, '#22d3ee');
    o.fillStyle = ag; o.beginPath(); o.roundRect(x, y, W * 0.008, h, [H * 0.014, 0, 0, H * 0.014]); o.fill();
    o.textBaseline = 'top'; o.textAlign = 'left';
    const tx = x + W * 0.012 + pad * 0.6; let ty = y + pad;
    if (name) { o.font = `800 ${ns}px system-ui, "Segoe UI", Arial, sans-serif`; o.fillStyle = '#fff'; o.fillText(name, tx, ty); ty += ns + gap; }
    if (role) { o.font = `500 ${rs}px system-ui, "Segoe UI", Arial, sans-serif`; o.fillStyle = '#c9cfe6'; o.fillText(role, tx, ty); }
    o.restore();
  }
}
