import { defaults, mergeSettings, sanitize, GESTURE_NAMES, EFFECT_NAMES, DEFAULT_GESTURE_MAP, CUSTOM_ID, MAX_CUSTOMS, validKey, KEY_ACTIONS } from '../engine/core/settings.js';
import { GESTURE_LABEL } from '../engine/gesture/gesture-engine.js';

const EFFECT_LABEL = {
  vanish: 'Particle vanish', cinema: 'Absolute Cinema', sad: 'Sad meme', punisher: 'No no no', money: 'Money rain', deal: 'Deal with it',
  banner: 'Name banner', confetti: 'Confetti', hearts: 'Hearts', flames: 'Flames', freeze: 'Freeze me', pauseGestures: 'Pause / resume gestures',
};
const effectLabel = (id) => EFFECT_LABEL[id] || ((settings.customs || []).find((c) => c.id === id) || {}).name || id;
const keyLabel = (code) => !code ? '' : 'Alt+' + (code.replace(/^Key|^Digit|^Numpad/, '').replace('ArrowUp', '\u2191').replace('ArrowDown', '\u2193').replace('Minus', '-').replace('Equal', '=').replace('Comma', ',').replace('Period', '.').replace('Slash', '/').replace('Semicolon', ';').replace('Quote', "'").replace('Backquote', '`').replace('BracketLeft', '[').replace('BracketRight', ']').replace('Backslash', '\\'));

const KEY = 'vibefx.settings';
const MKEY = 'vibefx.media';
const MAX_GIF = 8 * 1024 * 1024;      // bytes; GIFs cannot be re-encoded here, so they are limited instead
const MAX_SIDE = 1280;                // pictures are scaled down to this before they are stored
let media = {};
const $ = (id) => document.getElementById(id);

let settings = defaults();
let tabId = null;
let last = null;           // last status from the page
let toastTimer = null;

// ------------------------------------------------------------ storage
async function loadSettings() {
  try { const r = await chrome.storage.local.get(KEY); settings = sanitize(r[KEY] || {}); } catch (_) { settings = defaults(); }
}
async function save(patch) {
  settings = mergeSettings(settings, patch);
  try { await chrome.storage.local.set({ [KEY]: settings }); } catch (e) { toast('Could not save settings: ' + e.message); }
  renderSettings();
}

async function loadMedia() {
  try { const r = await chrome.storage.local.get(MKEY); media = r[MKEY] || {}; } catch (_) { media = {}; }
}
async function saveMedia() {
  try { await chrome.storage.local.set({ [MKEY]: media }); return true; }
  catch (e) { toast('Could not save the file: ' + (e && e.message || e)); return false; }
}
const readB64 = (blob) => new Promise((res, rej) => {
  const fr = new FileReader();
  fr.onload = () => res(String(fr.result).split(',')[1] || '');
  fr.onerror = () => rej(fr.error || new Error('read failed'));
  fr.readAsDataURL(blob);
});
// Turns an uploaded file into {name, mime, b64}: checks it opens, scales big pictures down. Throws a readable message.
async function prepareUpload(file) {
  const mime = file.type;
  if (!/^image\/(png|jpeg|webp|gif)$/.test(mime)) throw new Error('Use a PNG, JPG, WebP or GIF file.');
  const name = file.name.slice(0, 60);
  let bmp;
  try { bmp = await createImageBitmap(file); } catch (_) { throw new Error('That file could not be opened as a picture.'); }
  try {
    if (mime === 'image/gif') {
      if (file.size > MAX_GIF) throw new Error(`That GIF is ${(file.size / 1048576).toFixed(1)} MB. The limit is 8 MB. Use a shorter or smaller GIF.`);
      return { name, mime, b64: await readB64(file) };
    }
    const k = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
    if (k === 1 && file.size <= 1.5e6) return { name, mime, b64: await readB64(file) };
    const w = Math.max(1, Math.round(bmp.width * k)), h = Math.max(1, Math.round(bmp.height * k));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    c.getContext('2d').drawImage(bmp, 0, 0, w, h);
    const outMime = mime === 'image/png' ? 'image/png' : mime === 'image/webp' ? 'image/webp' : 'image/jpeg';
    const blob = await new Promise((r) => c.toBlob(r, outMime, 0.9));
    if (!blob) throw new Error('Could not shrink that picture.');
    return { name, mime: outMime, b64: await readB64(blob) };
  } finally { try { bmp.close(); } catch (_) {} }
}
function slotMsg(slot, text, ok = false) {
  const el = document.querySelector(`.mmsg[data-for="${slot}"]`); if (!el) return;
  el.textContent = text || ''; el.hidden = !text; el.className = 'mmsg small' + (ok ? ' ok' : '');
}
function renderMedia() {
  document.querySelectorAll('.media[data-slot]').forEach((row) => {
    const slot = row.dataset.slot, m = media[slot];
    const nm = row.querySelector('.mname');
    nm.textContent = m ? `${m.name || 'file'} (${m.mime.replace('image/', '').toUpperCase()}, ${Math.round(m.b64.length * 0.75 / 1024)} KB)` : (slot.startsWith('ovr_') ? 'built-in' : 'none');
    row.querySelector('.rm').disabled = !m;
    const eng = last && last.engine && last.engine.media && last.engine.media[slot];
    if (m && eng && eng.startsWith('failed')) slotMsg(slot, 'The page could not decode this file (' + eng.replace('failed: ', '') + '). Try another file.');
  });
  renderHints();
}

// ------------------------------------------------------------ page messaging
function ask(msg) {
  return new Promise((resolve) => {
    if (tabId == null) return resolve(null);
    try { chrome.tabs.sendMessage(tabId, msg, (res) => { void chrome.runtime.lastError; resolve(res || null); }); }
    catch (_) { resolve(null); }
  });
}

// ------------------------------------------------------------ rendering
function toast(text, ok = false) {
  const el = $('toast'); el.textContent = text; el.className = 'toast' + (ok ? ' ok' : ''); el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, 6000);
}

const REFUSALS = {
  'no-person': 'No person is visible, so there is nothing to vanish. Step into frame first.',
  'busy': 'That effect is mid-animation. Wait for it to finish.',
  'pose-model-loading': 'The body model is still loading. Try again in a few seconds.',
  'pose-model-failed': 'The body model failed to load, so Particle vanish is unavailable. See Diagnostics.',
  'no-media': 'Upload a picture or GIF for this meme first.',
  'media-failed': 'That picture could not be decoded. Try another file.',
  'camera-not-active': 'This page has not opened your camera yet.',
  'no-frame': 'No camera frame available yet.',
  'unknown-effect': 'Unknown effect.',
};

function statusModel() {
  if (!last) return { level: 'off', title: 'Not active on this tab', detail: 'VibeFX only runs on supported call sites (Meet, Zoom web, Teams web, Discord, Whereby, Webex, Jitsi). If you are on one, reload the page once after installing.' };
  if (settings.enabled === false) return { level: 'off', title: 'Switched off', detail: 'Your camera goes through untouched.' };
  const m = last.main;
  if (last.loadFailed) return { level: 'bad', title: 'Engine blocked on this site', detail: 'The site refused to load the VibeFX engine. Effects are NOT being applied and your raw camera is used.' };
  if (m && m.insertable === false) return { level: 'bad', title: 'This browser cannot apply effects', detail: 'Needs a Chromium browser with insertable media streams (Chrome or Edge 116+).' };
  if (!m || !m.streams) return { level: 'warn', title: 'Waiting for the camera', detail: 'This page has not opened your camera yet. Start or preview your video in the call.' };
  const p = m.pipeline;
  if (p.state === 'degraded') {
    const why = { 'engine-stalled': 'the engine stopped answering', 'engine-errors': 'frames keep failing', 'engine-failed': 'the engine failed to start' }[p.reason] || p.reason;
    return { level: 'bad', title: 'Degraded: sending raw camera', detail: `Effects are not applied because ${why}. VibeFX keeps retrying.` };
  }
  if (p.state === 'starting') return { level: 'warn', title: 'Engine starting', detail: 'Raw camera is being sent until the engine is ready.' };
  const models = last.engine && last.engine.models;
  const loading = models && Object.values(models).some((x) => x.state === 'pending' || x.state === 'loading');
  const failed = models && Object.entries(models).filter(([, v]) => v.state === 'failed').map(([k]) => k);
  if (failed && failed.length) return { level: 'warn', title: 'Running with limited features', detail: `Model failed: ${failed.join(', ')}. Effects that need it are unavailable.` };
  if (loading) return { level: 'warn', title: 'Loading models', detail: 'Effects without tracking work now. Gestures and vanish need the models to finish loading.' };
  return { level: 'ok', title: 'Ready: show a gesture', detail: p.mode === 'active' ? 'An effect is running.' : 'Your camera goes straight through; gestures are watched locally.' };
}

function renderStatus() {
  const s = statusModel();
  $('status').dataset.level = s.level;
  $('statusTitle').textContent = s.title;
  $('statusDetail').textContent = s.detail;
  const live = !!(last && last.main && last.main.streams && last.engine && last.main.pipeline.state === 'running');
  const eff = last && last.engine && last.engine.effects;
  document.querySelectorAll('.fx[data-fx]').forEach((b) => {
    const k = b.dataset.fx;
    b.disabled = !live || (CUSTOM_ID.test(k) && !media[k]);
    const on = eff ? (k === 'vanish' ? eff.vanish && eff.vanish.phase !== 'visible' : eff[k] && eff[k].active) : false;
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
  $('resetFx').disabled = !live;
  $('capBg').disabled = !live;
  renderDiag();
}

function row(dt, dd, cls = '') { return `<dt>${dt}</dt><dd class="${cls}">${dd}</dd>`; }
function renderDiag() {
  const d = $('diag'); const e = last && last.engine; const m = last && last.main;
  if (!last) { d.innerHTML = row('Page', 'no VibeFX on this tab', 'warn'); return; }
  const lines = [];
  const p = m && m.pipeline;
  lines.push(row('Pipeline', p ? `${p.state}${p.reason ? ' (' + p.reason + ')' : ''}` : 'no stream', p && p.state === 'running' ? 'ok' : p && p.state === 'degraded' ? 'bad' : 'warn'));
  if (e) {
    lines.push(row('Engine FPS', e.fps ?? '-'));
    lines.push(row('Frame time', e.ms ? `${e.ms.total} ms (ml ${e.ms.ml}, draw ${e.ms.render})` : '-'));
    lines.push(row('Quality level', e.scheduler ? `L${e.scheduler.level}` : '-'));
    for (const [k, v] of Object.entries(e.models || {})) lines.push(row(`${k} model`, v.state === 'ready' ? `ready (${v.delegate})` : v.state + (v.error ? ': ' + v.error : ''), v.state === 'ready' ? 'ok' : v.state === 'failed' ? 'bad' : 'warn'));
    lines.push(row('Person detected', e.person && e.person.present ? 'yes' : 'no'));
    if (e.background) lines.push(row('Background', e.background.captured ? 'captured' : `learned ${(e.background.coverage * 100).toFixed(0)}%`));
    if (e.gesture && e.gesture.hands && e.gesture.hands.length) lines.push(row('Hands seen', String(e.gesture.hands.length)));
    if (e.gesture && e.gesture.present && e.gesture.present.length) lines.push(row('Holding', e.gesture.present.map((x) => x.g).join(', ')));
  } else lines.push(row('Engine', last.iframeCreated ? 'loading...' : 'not started'));
  if (m) lines.push(row('Microphone', m.micMuted ? 'muted by freeze' : 'untouched', m.micMuted ? 'warn' : ''));
  if (m && m.pipeline.stats) { const s = m.pipeline.stats; lines.push(row('Frames', `${s.processed || 0} processed, ${s.passthrough || 0} raw, ${s.errors || 0} errors, ${s.stalls || 0} stalls`)); }
  d.innerHTML = lines.join('');
  const errs = [];
  if (last.events) for (const ev of last.events) if (ev.type === 'error' || ev.type === 'warning' || ev.type === 'frame-error') errs.push(`${ev.code || ev.type}: ${ev.detail || ''}`);
  if (last.logs) errs.push(...last.logs);
  const box = $('errors'); box.hidden = errs.length === 0; box.textContent = errs.slice(-4).join('\n');
  const g = last.lastGesture;
  $('lastGesture').textContent = g ? `${g.label} -> ${g.effect} (confidence ${g.confidence}) ${Math.round((Date.now() - g.at) / 1000)} s ago` : 'none yet';
}

function gestureOf(fx) { return GESTURE_NAMES.filter((g) => settings.gestureMap[g] === fx).map((g) => GESTURE_LABEL[g]); }
const keyOf = (id) => id in settings.keys ? settings.keys[id] : ((settings.customs.find((c) => c.id === id) || {}).key || '');
const allTargets = () => [...EFFECT_NAMES, ...settings.customs.map((c) => c.id)];

function renderGestures() {
  const box = $('gmap');
  const sig = settings.customs.map((c) => c.id + ':' + c.name).join('|');
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig;
    const opts = '<option value="none">Nothing</option>' + allTargets().map((e) => `<option value="${e}">${effectLabel(e).replace(/</g, '&lt;')}</option>`).join('');
    box.innerHTML = GESTURE_NAMES.map((g) => `<div class="row"><span>${GESTURE_LABEL[g]}</span><select data-g="${g}">${opts}</select></div>`).join('');
    box.querySelectorAll('select[data-g]').forEach((el) => { el.onchange = () => save({ gestureMap: { [el.dataset.g]: el.value } }); });
  }
  box.querySelectorAll('select[data-g]').forEach((el) => { el.value = settings.gestureMap[el.dataset.g]; });
  const dup = allTargets().filter((e) => gestureOf(e).length > 1);
  const w = $('gwarn'); w.hidden = dup.length === 0;
  w.textContent = dup.map((e) => `${effectLabel(e)} has ${gestureOf(e).length} gestures: ${gestureOf(e).join(', ')}.`).join(' ');
  renderHints();
}

function renderHints() {
  const hint = (id) => {
    const gs = gestureOf(id), k = keyLabel(keyOf(id));
    return [gs.join(' or ') || 'No gesture', k].filter(Boolean).join(' · ');
  };
  document.querySelectorAll('[data-hint]').forEach((el) => { el.textContent = hint(el.dataset.hint); });
  const cb = $('customBtns'), sig = settings.customs.map((c) => c.id + ':' + c.name).join('|');
  if (cb.dataset.sig !== sig) {
    cb.dataset.sig = sig;
    cb.innerHTML = '';
    for (const c of settings.customs) {
      const b = document.createElement('button'); b.className = 'fx'; b.dataset.fx = c.id; b.type = 'button';
      b.innerHTML = '<span class="ico">&#9733;</span><span class="lbl"><b></b><small data-hint2></small></span>';
      b.querySelector('b').textContent = c.name; cb.appendChild(b);
    }
  }
  cb.querySelectorAll('.fx').forEach((b) => { b.querySelector('small').textContent = (media[b.dataset.fx] ? '' : 'Upload first · ') + hint(b.dataset.fx); });
}

// ---- shortcuts (Alt + key)
let capturing = null;
function stopCapture() { if (capturing) { window.removeEventListener('keydown', capturing.fn, true); capturing.btn.classList.remove('rec'); capturing = null; renderKeys(); } }
function captureKey(btn, owner) {
  stopCapture();
  btn.textContent = 'Hold Alt, press a key...'; btn.classList.add('rec');
  const fn = (e) => {
    if (['Alt', 'Shift', 'Control', 'Meta'].includes(e.key)) return;
    e.preventDefault(); e.stopPropagation();
    if (e.key === 'Escape') return stopCapture();
    if (!e.altKey) return toast('Hold Alt (Option on Mac) and press the key together.');
    if (!validKey(e.code)) return toast('That key is used by the browser or not supported. Pick another.');
    const taken = KEY_ACTIONS.find((a) => settings.keys[a] === e.code && a !== owner) || (settings.customs.find((c) => c.key === e.code && c.id !== owner) || {}).id;
    setKey(owner, e.code);
    if (taken) toast(`${keyLabel(e.code)} moved here from "${effectLabel(taken)}".`, true);
    stopCapture();
  };
  capturing = { fn, btn }; window.addEventListener('keydown', fn, true);
}
function setKey(owner, code) {
  const keys = { ...settings.keys };
  for (const a of KEY_ACTIONS) if (code && keys[a] === code) keys[a] = '';
  const customs = settings.customs.map((c) => ({ ...c, key: code && c.key === code ? '' : c.key }));
  if (owner in keys) keys[owner] = code; else { const c = customs.find((x) => x.id === owner); if (c) c.key = code; }
  save({ keys, customs });
}
function renderKeys() {
  const box = $('kmap');
  if (capturing) return;
  const sig = settings.customs.map((c) => c.id + ':' + c.name).join('|');
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig;
    box.innerHTML = '';
    for (const id of [...KEY_ACTIONS, ...settings.customs.map((c) => c.id)]) {
      const r = document.createElement('div'); r.className = 'row'; r.dataset.k = id;
      const sp = document.createElement('span'); sp.textContent = effectLabel(id);
      const wrap = document.createElement('span'); wrap.className = 'kbtns';
      const b = document.createElement('button'); b.className = 'btn small keybtn'; b.type = 'button';
      const x = document.createElement('button'); x.className = 'btn small ghost'; x.type = 'button'; x.textContent = 'Clear'; x.title = 'Remove this shortcut';
      b.onclick = () => captureKey(b, id); x.onclick = () => setKey(id, '');
      wrap.append(b, x); r.append(sp, wrap); box.appendChild(r);
    }
  }
  box.querySelectorAll('.row').forEach((r) => { const k = keyOf(r.dataset.k); const b = r.querySelector('.keybtn'); b.textContent = k ? keyLabel(k) : 'Set key'; r.querySelector('.ghost').disabled = !k; });
  renderHints();
}

// ---- my memes
const newId = () => { let id; do { id = 'c_' + Math.random().toString(36).slice(2, 7); } while (!CUSTOM_ID.test(id) || settings.customs.some((c) => c.id === id)); return id; };
function renderCustoms() {
  const box = $('customs'), sig = settings.customs.map((c) => c.id).join('|');
  const poseOpts = '<option value="none">No gesture</option>' + GESTURE_NAMES.map((g) => `<option value="${g}">${GESTURE_LABEL[g]}</option>`).join('');
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig; box.innerHTML = '';
    for (const c of settings.customs) {
      const r = document.createElement('div'); r.className = 'custom'; r.dataset.id = c.id;
      r.innerHTML = `<div class="crow"><input type="text" class="cname" maxlength="40" aria-label="Name"><button class="btn small ghost cdel" type="button" title="Delete this meme">Delete</button></div>
        <div class="media" data-slot="${c.id}"><span class="mname muted">none</span><button class="btn small up" type="button">Upload</button><button class="btn small ghost rm" type="button">Remove file</button><input type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></div>
        <div class="mmsg small" data-for="${c.id}" hidden></div>
        <div class="crow"><select class="cmode" aria-label="Show"><option value="full">Full screen</option><option value="behind">Behind me</option></select><select class="cpose" aria-label="Gesture">${poseOpts}</select><button class="btn small keybtn" type="button"></button></div>`;
      box.appendChild(r);
      bindMediaRow(r.querySelector('.media'));
      const upd = (patch) => save({ customs: settings.customs.map((x) => x.id === c.id ? { ...x, ...patch } : x) });
      r.querySelector('.cname').onchange = (e) => upd({ name: e.target.value.trim() || 'Meme' });
      r.querySelector('.cmode').onchange = (e) => upd({ mode: e.target.value });
      r.querySelector('.cpose').onchange = (e) => {
        const pose = e.target.value, gm = {};
        for (const g of GESTURE_NAMES) if (settings.gestureMap[g] === c.id) gm[g] = 'none';
        if (pose !== 'none') { const prev = settings.gestureMap[pose]; if (prev !== 'none' && prev !== c.id) toast(`"${GESTURE_LABEL[pose]}" was used by ${effectLabel(prev)}. It now starts this meme.`, true); gm[pose] = c.id; }
        save({ gestureMap: gm });
      };
      r.querySelector('.keybtn').onclick = (e) => captureKey(e.currentTarget, c.id);
      r.querySelector('.cdel').onclick = async () => {
        if (!confirm(`Delete "${c.name}"?`)) return;
        delete media[c.id]; await saveMedia();
        save({ customs: settings.customs.filter((x) => x.id !== c.id) });
      };
    }
  }
  for (const c of settings.customs) {
    const r = box.querySelector(`.custom[data-id="${c.id}"]`); if (!r) continue;
    const nm = r.querySelector('.cname'); if (document.activeElement !== nm) nm.value = c.name;
    r.querySelector('.cmode').value = c.mode;
    const gs = GESTURE_NAMES.find((g) => settings.gestureMap[g] === c.id);
    r.querySelector('.cpose').value = gs || 'none';
    const kb = r.querySelector('.keybtn'); if (!capturing) kb.textContent = c.key ? keyLabel(c.key) : 'Set key';
  }
}

function renderSettings() {
  renderGestures(); renderKeys(); renderCustoms();
  const g = settings.gestures;
  $('master').checked = settings.enabled;
  $('g_enabled').checked = g.enabled;
  document.querySelectorAll('#g_sensitivity button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.v === g.sensitivity)));
  $('autoHide').value = settings.autoHideSec; $('autoHideOut').textContent = settings.autoHideSec === 0 ? 'until off' : settings.autoHideSec + ' s';
  const setv = (id, v) => { const el = $(id); if (document.activeElement !== el) el.value = v; };
  setv('endText', settings.vanish.endText); setv('bannerName', settings.banner.name); setv('bannerRole', settings.banner.role);
  $('touchUp').checked = settings.touchUp; $('bgMode').value = settings.background.mode;
  $('muteOnFreeze').checked = settings.muteOnFreeze;
  $('quality').value = settings.quality; $('hints').checked = settings.hints; $('debug').checked = settings.debug;
}

function bindMediaRow(row) {
  const slot = row.dataset.slot, input = row.querySelector('input[type=file]');
  row.querySelector('.up').onclick = () => input.click();
  row.querySelector('.rm').onclick = async () => { delete media[slot]; await saveMedia(); slotMsg(slot, ''); renderMedia(); };
  input.onchange = async () => {
    const f = input.files && input.files[0]; input.value = '';
    if (!f) return;
    slotMsg(slot, 'Reading...', true);
    try {
      const item = await prepareUpload(f);
      const prev = media[slot]; media[slot] = item;
      if (await saveMedia()) slotMsg(slot, 'Saved. It is used on the call right away.', true);
      else { if (prev) media[slot] = prev; else delete media[slot]; slotMsg(slot, 'Could not save that file.'); }
    } catch (e) { slotMsg(slot, e.message || String(e)); }
    renderMedia(); renderStatus();
  };
}

// ------------------------------------------------------------ events
function wire() {
  $('addCustom').onclick = () => {
    if (settings.customs.length >= MAX_CUSTOMS) return toast(`Up to ${MAX_CUSTOMS} memes.`);
    save({ customs: [...settings.customs, { id: newId(), name: 'Meme ' + (settings.customs.length + 1), mode: 'full', key: '' }] });
  };
  $('kReset').onclick = () => { const d = defaults(); save({ keys: d.keys, customs: settings.customs.map((c) => ({ ...c, key: '' })) }); toast('Shortcuts reset to the defaults.', true); };
  $('master').onchange = (e) => save({ enabled: e.target.checked });
  const bind = (id, path) => { $(id).onchange = (e) => save(path(e.target.checked)); };
  bind('g_enabled', (v) => ({ gestures: { enabled: v } }));
  bind('hints', (v) => ({ hints: v }));
  bind('muteOnFreeze', (v) => ({ muteOnFreeze: v }));
  bind('debug', (v) => ({ debug: v }));
  document.querySelectorAll('#g_sensitivity button').forEach((b) => { b.onclick = () => save({ gestures: { sensitivity: b.dataset.v } }); });
  $('autoHide').oninput = (e) => { const v = +e.target.value; $('autoHideOut').textContent = v === 0 ? 'until off' : v + ' s'; };
  $('autoHide').onchange = (e) => save({ autoHideSec: +e.target.value });
  $('quality').onchange = (e) => save({ quality: e.target.value });
  $('resetSettings').onclick = async () => { settings = defaults(); await chrome.storage.local.set({ [KEY]: settings }); renderSettings(); toast('Settings reset to defaults.', true); };
  document.addEventListener('click', async (ev) => {
    const b = ev.target.closest && ev.target.closest('.fx[data-fx]'); if (!b || b.disabled) return;
    const r = await ask({ vibefx: 'command', name: b.dataset.fx });
    if (!r) return toast('Could not reach the page. Reload it and try again.');
    if (!r.ok) return toast(REFUSALS[r.reason] || 'Not possible right now.');
    const lc = r.last;
    if (lc && lc.ok === false) toast(REFUSALS[lc.reason] || ('Refused: ' + lc.reason));
    refresh();
  });
  $('endText').onchange = (e) => save({ vanish: { endText: e.target.value } });
  $('bannerName').onchange = (e) => save({ banner: { name: e.target.value } });
  $('bannerRole').onchange = (e) => save({ banner: { role: e.target.value } });
  $('touchUp').onchange = (e) => save({ touchUp: e.target.checked });
  $('bgMode').onchange = (e) => save({ background: { mode: e.target.value } });
  document.querySelectorAll('.media[data-slot]').forEach(bindMediaRow);
  $('gReset').onclick = () => { save({ gestureMap: { ...DEFAULT_GESTURE_MAP } }); toast('Gestures reset to the default pack.', true); };
  $('resetFx').onclick = async () => { await ask({ vibefx: 'command', name: 'reset' }); refresh(); };
  $('capBg').onclick = async () => {
    const r = await ask({ vibefx: 'command', name: 'capture-background', delayMs: 5000 });
    if (r && r.ok) toast('Capturing in 5 seconds. Step completely out of frame now.', true); else toast(REFUSALS[r && r.reason] || 'Could not start the capture.');
  };
}

async function refresh() {
  last = await ask({ vibefx: 'get-status' });
  renderStatus(); renderMedia();
}

(async function init() {
  await loadSettings(); await loadMedia();
  try { const [t] = await chrome.tabs.query({ active: true, currentWindow: true }); tabId = t ? t.id : null; } catch (_) {}
  wire(); renderSettings(); renderMedia(); await refresh();
  chrome.storage.onChanged.addListener((chg, area) => {
    if (area !== 'local') return;
    if (chg[KEY] && JSON.stringify(sanitize(chg[KEY].newValue || {})) !== JSON.stringify(settings)) { settings = sanitize(chg[KEY].newValue || {}); renderSettings(); }
  });
  setInterval(refresh, 1000);
})();
