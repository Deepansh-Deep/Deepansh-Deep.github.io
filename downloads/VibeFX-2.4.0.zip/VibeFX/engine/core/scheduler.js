// Decides which models run on which frame, adapting to measured cost so the video never
// stalls because inference is slow. Pure: feed it timings, ask it for a plan.
//
// Plan fields are booleans for "run this model on this frame". Skipped frames reuse the
// previous result (landmarks are held, masks are held), which is visually fine at 30 FPS.

const BASE = {
  high:     { hand: 1, pose: 1, face: 1 },
  balanced: { hand: 1, pose: 2, face: 2 },
  low:      { hand: 2, pose: 4, face: 4 },
};

export class InferenceScheduler {
  constructor({ targetFps = 30, quality = 'auto' } = {}) {
    this.targetMs = 1000 / targetFps;
    this.quality = quality;
    this.cost = { hand: 6, pose: 9, face: 8, render: 6 };   // optimistic until measured
    this.level = 1;                                          // 0 high .. 3 low (auto mode only)
    this.frameMs = 0;
    this._over = 0; this._under = 0;
    this.frame = 0;
  }

  setQuality(q) { this.quality = q; }

  report(model, ms) {
    if (!(ms >= 0) || !Number.isFinite(ms)) return;
    const c = this.cost[model] ?? ms;
    this.cost[model] = c * 0.85 + ms * 0.15;
  }

  // Total frame time (capture to output) measured by the caller; drives auto adaptation.
  reportFrame(ms) {
    this.frameMs = this.frameMs ? this.frameMs * 0.9 + ms * 0.1 : ms;
    if (this.quality !== 'auto') return;
    if (this.frameMs > this.targetMs * 1.15) { this._over++; this._under = 0; } else if (this.frameMs < this.targetMs * 0.6) { this._under++; this._over = 0; } else { this._over = 0; this._under = 0; }
    if (this._over >= 20 && this.level < 3) { this.level++; this._over = 0; }
    if (this._under >= 120 && this.level > 0) { this.level--; this._under = 0; }
  }

  intervals() {
    if (this.quality === 'high') return BASE.high;
    if (this.quality === 'balanced') return BASE.balanced;
    if (this.quality === 'low') return BASE.low;
    return [BASE.high, BASE.balanced, { hand: 2, pose: 3, face: 3 }, BASE.low][this.level];
  }

  // need: {hand, pose, face, poseUrgent} what the current effects/gestures require.
  plan(need, mlAvailable = { hand: true, pose: true, face: true }) {
    const iv = this.intervals();
    const n = this.frame++;
    const pick = (name, required) => !!(required && mlAvailable[name] && (n % iv[name] === 0));
    const p = {
      hand: pick('hand', need.hand),
      pose: !!(pick('pose', need.pose) || (need.poseUrgent && mlAvailable.pose && n % 2 === 0)),
      face: pick('face', need.face),
    };
    return p;
  }

  get level01() { return this.level; }
  snapshot() { return { level: this.level, quality: this.quality, frameMs: +this.frameMs.toFixed(1), cost: Object.fromEntries(Object.entries(this.cost).map(([k, v]) => [k, +v.toFixed(1)])) }; }
}
