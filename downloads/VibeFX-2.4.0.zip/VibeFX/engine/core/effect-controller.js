// Effect state machine. Pure: time is passed in, there are no timers and no DOM. The renderer reads
// levels() each frame; gestures and the popup buttons both go through trigger().
//
// Effects: vanish (phases) and four overlays: cinema, sad, punisher, money. The first three are "scenes":
// starting one ends the other scenes. Money is an overlay and can sit on top of a scene.

export const EFFECTS = ['vanish', 'cinema', 'sad', 'punisher', 'money', 'deal', 'banner', 'confetti', 'hearts', 'flames', 'freeze'];
const SCENES = ['cinema', 'sad', 'punisher'];        // the user's own memes (ids c_xxx) are scenes too
const CUSTOM = /^c_[a-z0-9]{2,10}$/;
const isScene = (k) => SCENES.includes(k) || CUSTOM.test(k);
const RAMP = {
  cinema: [0.28, 0.3], sad: [0.3, 0.3], punisher: [0.25, 0.3], money: [0.25, 0.5],
  deal: [0.05, 0.4], banner: [0.35, 0.35], confetti: [0.15, 0.6], hearts: [0.2, 0.6], flames: [0.3, 0.6],
  freeze: [0.04, 0.04],
};
const RAMP_CUSTOM = [0.25, 0.3];   // seconds in / out
const STAYS = ['freeze', 'banner'];   // these stay until switched off: they must not vanish by themselves
const MIN_TOGGLE_OFF_MS = 1200;     // repeating a gesture turns the effect off, but not within this time of it starting
const HOLD_KEEP_MS = 1200;          // while the gesture is still held the effect stays at least this much longer

export class EffectController {
  constructor(settings) {
    this.s = settings;
    this.reset(0);
  }

  setSettings(s) { this.s = s; }

  reset(t = 0) {
    this.t = t;
    this.vanish = { phase: 'visible', start: 0, progress: 0 };
    this.fx = {};
    for (const k of Object.keys(RAMP)) this.fx[k] = { target: 0, level: 0, since: 0, expire: null, stays: STAYS.includes(k) };
    this.events = [];
  }

  // source: 'gesture' (repeat within MIN_TOGGLE_OFF_MS only refreshes) or 'ui' (button: always toggles).
  // Returns {ok, reason?, ...}. The reason lets the UI say why nothing happened.
  trigger(name, t = this.t, { source = 'ui', personPresent } = {}) {
    if (name === 'reset') { this.reset(t); this.events.push({ type: 'reset' }); return { ok: true }; }
    if (name === 'vanish') return this._vanish(t, personPresent);
    if (!this.fx[name] && CUSTOM.test(name)) this.fx[name] = { target: 0, level: 0, since: 0, expire: null, stays: false };
    const f = this.fx[name];
    if (!f) return { ok: false, reason: 'unknown-effect' };
    if (f.target) {
      if (source === 'gesture' && t - f.since < MIN_TOGGLE_OFF_MS) { this._extend(f, t); return { ok: true, noop: true }; }
      f.target = 0; f.expire = null;
      this.events.push({ type: 'off', effect: name });
      return { ok: true, active: false };
    }
    if (isScene(name)) for (const o of Object.keys(this.fx)) if (isScene(o) && o !== name && this.fx[o].target) { this.fx[o].target = 0; this.fx[o].expire = null; this.events.push({ type: 'off', effect: o, replaced: true }); }
    f.target = 1; f.since = t; f.expire = null;
    this._extend(f, t);
    this.events.push({ type: 'on', effect: name });
    return { ok: true, active: true };
  }

  // The gesture that started this effect is still being held: keep it up.
  hold(name, t) {
    const f = this.fx[name];
    if (f && f.target && f.expire !== null) f.expire = Math.max(f.expire, t + HOLD_KEEP_MS);
  }

  _extend(f, t) {
    const sec = this.s.autoHideSec;
    if (f.stays) { f.expire = null; return; }
    f.expire = sec > 0 ? Math.max(f.expire ?? 0, t + sec * 1000) : null;
  }

  _vanish(t, personPresent) {
    const v = this.vanish;
    if (v.phase === 'visible') {
      if (personPresent === false) return { ok: false, reason: 'no-person' };
      v.phase = 'dissolving'; v.start = t; v.progress = 0;
      this.events.push({ type: 'vanish-start' });
      return { ok: true, phase: v.phase };
    }
    if (v.phase === 'gone') {
      v.phase = 'returning'; v.start = t; v.progress = 0;
      this.events.push({ type: 'return-start' });
      return { ok: true, phase: v.phase };
    }
    return { ok: false, reason: 'busy' };   // mid-animation: ignore, do not queue
  }

  update(t) {
    const dt = Math.max(0, Math.min(0.25, (t - this.t) / 1000));
    this.t = t;
    const v = this.vanish;
    if (v.phase === 'dissolving') {
      v.progress = Math.min(1, (t - v.start) / 1000 / this.s.vanish.durationSec);
      if (v.progress >= 1) { v.phase = 'gone'; v.progress = 1; this.events.push({ type: 'vanish-done' }); }
    } else if (v.phase === 'returning') {
      v.progress = Math.min(1, (t - v.start) / 1000 / this.s.vanish.returnSec);
      if (v.progress >= 1) { v.phase = 'visible'; v.progress = 0; this.events.push({ type: 'return-done' }); }
    }
    for (const [k, f] of Object.entries(this.fx)) {
      if (f.target && f.expire !== null && t >= f.expire) { f.target = 0; f.expire = null; this.events.push({ type: 'off', effect: k, auto: true }); }
      const [up, down] = RAMP[k] || RAMP_CUSTOM;
      const rate = dt / (f.target ? up : down);
      f.level += Math.sign(f.target - f.level) * Math.min(Math.abs(f.target - f.level), rate);
    }
  }

  levels() {
    const o = { vanish: { phase: this.vanish.phase, progress: this.vanish.progress } };
    for (const [k, f] of Object.entries(this.fx)) o[k] = { active: f.target === 1, level: f.level, since: f.since };
    return o;
  }

  isAnyActive() {
    if (this.vanish.phase !== 'visible') return true;
    return Object.values(this.fx).some((f) => f.target === 1 || f.level > 0.001);
  }

  drainEvents() { const e = this.events; this.events = []; return e; }
}
