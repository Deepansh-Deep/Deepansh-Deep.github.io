// VibeEngine: the whole effects pipeline behind one object. Runs in the extension's hidden iframe.
//
//   processFrame(bitmap, nowEpochMs)  ->  { frame, meta }
//
// meta.idle   nothing needs drawing: the caller keeps the camera frame as it is
// meta.active an effect is on (or fading), so the caller should send every frame through the engine
// Never throws: a failing frame is reported in meta.error and the caller decides what to do.

import { Vision } from './vision/vision.js';
import { InferenceScheduler } from './core/scheduler.js';
import { EffectController } from './core/effect-controller.js';
import { defaults, mergeSettings } from './core/settings.js';
import { GestureEngine, GESTURE_LABEL } from './gesture/gesture-engine.js';
import { makeCanvas, ctx2d, clamp, smoothstep as smooth } from './render/util.js';
import { MaskProcessor } from './render/mask.js';
import { BackgroundModel } from './render/background.js';
import { VanishRenderer } from './render/vanish.js';
import { PosterRenderer } from './render/poster.js';
import { OverlayRenderer } from './render/overlays.js';
import { FxRenderer } from './render/fx.js';
import { MediaStore } from './render/media.js';
import { Assets } from './render/assets.js';

const ML_W = 512;

export class VibeEngine {
  constructor({ baseUrl, settings, log = () => {}, onEvent = () => {}, vision = null } = {}) {
    this.baseUrl = baseUrl;
    this.settings = mergeSettings(defaults(), settings || {});
    this.log = log; this.onEvent = onEvent;
    this.vision = vision || new Vision({ baseUrl, log });
    this.assets = new Assets(baseUrl, log);
    this.sched = new InferenceScheduler({ quality: this.settings.quality });
    this.ctrl = new EffectController(this.settings);
    this.gest = new GestureEngine(this._gestureOpts());
    this.mask = new MaskProcessor();
    this.bg = new BackgroundModel();
    this.vanish = new VanishRenderer();
    this.poster = new PosterRenderer();
    this.overlays = new OverlayRenderer();
    this.fx = new FxRenderer();
    this.media = new MediaStore(log);
    this.touchGain = 1; this.freezeOn = false;
    this.W = 0; this.H = 0;
    this.state = 'loading';          // loading | ready | failed
    this.initError = null;
    this.lastT = 0; this.frameNo = 0; this.lastTs = 0;
    this.fps = 0; this.ms = { total: 0, ml: 0, render: 0 };
    this.hands = []; this.pose = null; this.faces = null; this.lastFaceAt = -1e9; this.lastPoseAt = -1e9; this.lastFaceTs = 0; this.fc = null;
    this.mlReady = false;
    this.lastCommand = null;
    this._personFrame = -1;
    this.bgHint = null;
    this.lastBitmapForCapture = null;
    this._deferred = []; this._inFrame = false;
  }

  _gestureOpts() { const g = this.settings.gestures; return { enabled: g.enabled, sensitivity: g.sensitivity }; }

  async init() {
    this.state = 'ready';            // renderers are usable now; models and pictures report separately
    const progress = () => this._emit({ type: 'models', models: this.modelStatus(), assets: { ...this.assets.status } });
    const a = this.assets.load(() => { if (this.W) this.poster.setup(this.W, this.H, this.assets); this.overlays.setup(this.W, this.H, this.assets); progress(); });
    try {
      await this.vision.init(progress);
      this.mlReady = true;
      const failed = Object.entries(this.modelStatus()).filter(([, v]) => v.state === 'failed');
      if (failed.length) this._emit({ type: 'warning', code: 'models-failed', detail: failed.map(([k, v]) => `${k}: ${v.error}`).join('; ') });
    } catch (e) {
      this.initError = String(e && e.message || e);
      this._emit({ type: 'error', code: 'init-failed', detail: this.initError });
    }
    await a;
    progress();
  }

  isReady() { return this.state === 'ready'; }
  failed() { return this.state === 'failed'; }
  modelStatus() { return JSON.parse(JSON.stringify(this.vision.status)); }
  _emit(e) { try { this.onEvent(e); } catch (_) {} }
  _now() { return performance.timeOrigin + performance.now(); }
  _qualityScale() { const l = this.sched.level; return this.settings.quality === 'auto' ? [1, 0.8, 0.55, 0.35][l] : { high: 1, balanced: 0.7, low: 0.4 }[this.settings.quality]; }

  setSettings(patch) {
    this.settings = mergeSettings(this.settings, patch);
    this.ctrl.setSettings(this.settings);
    this.sched.setQuality(this.settings.quality);
    this.gest.configure(this._gestureOpts());
  }

  // User uploads (vanish end screen, meme slots, background picture), forwarded by the bridge.
  async setMedia(media) {
    const st = await this.media.set(media || {});
    this._emit({ type: 'media', status: { ...st } });
  }

  // ---------------------------------------------------------------- commands (buttons and gestures)
  command(name, opts = {}, source = 'ui') {
    const t = opts.t ?? this._now();
    let res;
    // these two need the current picture; a button press arrives between frames, so run it on the next frame
    if (!this._inFrame && (name === 'vanish' || name === 'capture-background')) {
      this._deferred.push({ name, opts, source });
      return { ok: true, pending: true };
    }
    if (name === 'capture-background') {
      if (!this.lastBitmapForCapture) res = { ok: false, reason: 'no-frame' };
      else { this.bg.captureNow(this.lastBitmapForCapture); res = { ok: true }; }
    } else if (name === 'reset') {
      this.ctrl.trigger('reset', t); this.vanish.stop(); res = { ok: true };
    } else if (name === 'vanish') {
      const m = this.vision.status.pose;
      if (!m || m.state !== 'ready') res = { ok: false, reason: m && m.state === 'failed' ? 'pose-model-failed' : 'pose-model-loading' };
      else {
        res = this.ctrl.trigger('vanish', t, { source, personPresent: this.mask.has(t, 5000) });
        if (res.ok) { this._startVanish(res.phase); this.endSince = t; }
      }
    } else if (/^c_/.test(name) && !(this.settings.customs || []).some((c) => c.id === name)) {
      res = { ok: false, reason: 'unknown-effect' };
    } else if (/^c_/.test(name) && !this.media.has(name)) {
      res = { ok: false, reason: 'no-media' };
    } else if (/^c_/.test(name) && !this.media.ready(name)) {
      // the picture is decoded the first time it is used: start the effect when it is ready
      this.media.ensure(name).then((ok) => {
        const tt = this.lastT || this._now();          // same clock as the frames
        const r = ok ? this.ctrl.trigger(name, tt, { source }) : { ok: false, reason: 'media-failed' };
        this.lastCommand = { name, source, ...r, t: tt };
        this._emit({ type: 'command', name, source, ...r });
      });
      return { ok: true, pending: true };
    } else {
      if (name === 'sad') this.overlays.pickSide(this.mask);
      res = this.ctrl.trigger(name, t, { source });
    }
    this.lastCommand = { name, source, ...res, t };
    this._emit({ type: 'command', name, source, ...res });
    return res;
  }

  _startVanish(phase) {
    const frame = this.lastBitmapForCapture;
    if (!frame || !this.vanish.W) return;
    const info = this.bg.inpaintUnknown();
    this.vanish.start(phase === 'dissolving' ? 'dissolve' : 'return', frame, this.mask, 1, this._qualityScale());
    this.bgHint = { coverage: this.bg.coverage(), filled: info.filled };
  }

  _onGesture(ev, t) {
    const fx = (this.settings.gestureMap || {})[ev.type];
    if (!fx || fx === 'none') return;
    if (ev.kind === 'hold') { this.ctrl.hold(fx, t); return; }
    this._emit({ type: 'gesture', gesture: ev.type, label: GESTURE_LABEL[ev.type], effect: fx, confidence: +ev.confidence.toFixed(2) });
    this.command(fx, { t }, 'gesture:' + ev.type);
  }

  _setup(W, H) {
    this.W = W; this.H = H;
    this.mlW = Math.min(ML_W, W); this.mlH = Math.max(16, Math.round(this.mlW * H / W));
    this.out = makeCanvas(W, H); this.o = ctx2d(this.out);
    this.ml = makeCanvas(this.mlW, this.mlH); this.mlx = ctx2d(this.ml);
    this.pl = makeCanvas(W, H); this.plx = ctx2d(this.pl);
    this.bg.setup(W, H); this.vanish.setup(W, H);
    this.poster.setup(W, H, this.assets); this.overlays.setup(W, H, this.assets); this.fx.setup(W, H);
    this.mask = new MaskProcessor();
    this.freezeShot = makeCanvas(W, H); this.fzx = ctx2d(this.freezeShot);
    this.blurA = makeCanvas(Math.max(8, W >> 2), Math.max(8, H >> 2)); this.blurAx = ctx2d(this.blurA);
    this.blurB = makeCanvas(Math.max(8, W / 12), Math.max(8, H / 12)); this.blurBx = ctx2d(this.blurB);
    this.lumaC = makeCanvas(24, 14); this.lumaX = ctx2d(this.lumaC, { willReadFrequently: true });
    this.freezeOn = false;
  }

  _need() {
    const lv = this.ctrl.levels(), g = this.settings.gestures;
    const behind = (this.settings.customs || []).some((c) => c.mode === 'behind' && lv[c.id] && lv[c.id].level > 0.01);
    const needsMask = lv.vanish.phase !== 'visible' || lv.sad.level > 0.01 || this.settings.background.mode !== 'none' || behind;
    const learning = this.settings.enabled && lv.vanish.phase === 'visible' && !this.bg.captured;
    return { hand: g.enabled, pose: g.enabled || learning || needsMask, poseUrgent: needsMask, face: lv.cinema.level > 0.01 || lv.deal.level > 0.01 };
  }

  // ---------------------------------------------------------------- main entry
  // bmp: ImageBitmap (ownership passes to the engine; it is returned or closed).
  processFrame(bmp, nowEpoch = this._now()) {
    const t0 = performance.now();
    const meta = { processed: false, idle: false, active: false };
    try {
      if (!this.settings.enabled) { meta.idle = true; meta.disabled = true; return { frame: bmp, meta }; }
      if (bmp.width !== this.W || bmp.height !== this.H) this._setup(bmp.width, bmp.height);
      const dt = this.lastT ? clamp((nowEpoch - this.lastT) / 1000, 0.001, 0.2) : 1 / 30;
      this.lastT = nowEpoch; this.frameNo++;
      this.fps = this.fps ? this.fps * 0.92 + (1 / dt) * 0.08 : 30;
      this.lastBitmapForCapture = bmp; this._inFrame = true;
      while (this._deferred.length) { const d = this._deferred.shift(); this.command(d.name, d.opts, d.source); }

      // ---- vision
      const tm = {};
      const plan = this.sched.plan(this._need(), this.vision.available());
      const wantFace = plan.face; plan.face = false;                 // the face model runs on a head crop, below
      let ranHands = null, ranPose;
      if (plan.hand || plan.pose || plan.face) {
        this.mlx.drawImage(bmp, 0, 0, this.mlW, this.mlH);
        const ts = Math.max(this.lastTs + 1, Math.round(nowEpoch % 2147483000));
        this.lastTs = ts;
        const r = this.vision.detect(this.ml, ts, plan, tm);
        if (r.hands) { this.hands = r.hands; ranHands = r.hands; }
        if (r.poseRan) { this.pose = r.pose; this.lastPoseAt = nowEpoch; ranPose = r.pose; if (r.mask) this.mask.update(r.mask, nowEpoch); else this.mask.clear(); }
        for (const k of ['hand', 'pose']) if (tm[k] !== undefined) this.sched.report(k, tm[k]);
      }
      if (wantFace) this._detectFace(bmp, nowEpoch, tm);
      if (nowEpoch - this.lastFaceAt > 500) this.faces = null;
      this.ms.ml = (tm.hand || 0) + (tm.pose || 0) + (tm.face || 0);

      // ---- gestures
      const evs = this.gest.update(nowEpoch, { hands: ranHands, pose: ranPose, w: this.W, h: this.H });
      for (const ev of evs) this._onGesture(ev, nowEpoch);

      // ---- state
      this.ctrl.update(nowEpoch);
      for (const ev of this.ctrl.drainEvents()) this._emit({ type: 'effect-event', ...ev });
      const lv = this.ctrl.levels();
      if (lv.freeze.active !== this._fzSent) { this._fzSent = lv.freeze.active; this._emit({ type: 'freeze', on: lv.freeze.active }); }
      const ph = lv.vanish.phase;
      if (ph === 'visible' && ranPose !== undefined) this.bg.learn(bmp, this.mask, nowEpoch);
      if (ph === 'visible' && this.vanish.P) this.vanish.stop();

      const active = this.ctrl.isAnyActive() || this.settings.debug || this.settings.touchUp || this.settings.background.mode !== 'none';
      meta.active = active;
      if (!active) { meta.idle = true; this.lastBitmapForCapture = null; this._inFrame = false; this._finish(t0, meta); return { frame: bmp, meta }; }

      // ---- render
      const tr = performance.now();
      this._render(bmp, nowEpoch, lv);
      this.ms.render = performance.now() - tr;
      const res = this.out.transferToImageBitmap();
      bmp.close();
      this.lastBitmapForCapture = null;
      meta.processed = true; this._inFrame = false;
      this._finish(t0, meta);
      return { frame: res, meta };
    } catch (e) {
      this._inFrame = false; this.lastBitmapForCapture = null;
      this.log('error', 'frame failed', e && e.stack || String(e));
      this._emit({ type: 'frame-error', detail: String(e && e.message || e) });
      return { frame: bmp, meta: { ...meta, error: String(e && e.message || e) } };
    }
  }

  // The face model needs a face that fills a good part of its input. Cropping around the head (found by the
  // pose model) keeps it working when you sit far from the camera. Landmarks are mapped back to the whole frame.
  _detectFace(bmp, nowEpoch, tm) {
    const W = this.W, H = this.H, p = this.pose;
    let box = { x: 0, y: 0, w: W, h: H };
    const vis = (i) => p && p[i] && (p[i].visibility ?? 1) > 0.4;
    if (this.pose && nowEpoch - this.lastPoseAt < 1000 && vis(0) && vis(2) && vis(5)) {
      const eyeD = Math.hypot((p[2].x - p[5].x) * W, (p[2].y - p[5].y) * H);
      const earD = vis(7) && vis(8) ? Math.hypot((p[7].x - p[8].x) * W, (p[7].y - p[8].y) * H) : 0;
      const side = Math.min(Math.min(W, H), Math.max(eyeD * 2.4, earD * 1.15) * 2.6);
      const cx = ((p[2].x + p[5].x) / 2 * 0.5 + p[0].x * 0.5) * W, cy = ((p[2].y + p[5].y) / 2 * 0.5 + p[0].y * 0.5) * H;
      if (side > 24) box = { x: clamp(cx - side / 2, 0, W - side), y: clamp(cy - side / 2, 0, H - side), w: side, h: side };
    }
    if (!this.fc) { this.fc = makeCanvas(320, 320); this.fcx = ctx2d(this.fc); }
    const fw = box.w >= W ? this.mlW : 320, fh = box.w >= W ? this.mlH : 320;
    if (this.fc.width !== fw || this.fc.height !== fh) { this.fc.width = fw; this.fc.height = fh; }
    this.fcx.drawImage(bmp, box.x, box.y, box.w, box.h, 0, 0, fw, fh);
    const ts = Math.max(this.lastFaceTs + 1, Math.round(nowEpoch % 2147483000));
    this.lastFaceTs = ts;
    const r = this.vision.detect(this.fc, ts, { face: true }, tm);
    if (!r.faceRan) return;
    this.lastFaceAt = nowEpoch;
    this.faces = (r.faces || []).map((lm) => lm.map((q) => ({ x: (box.x + q.x * box.w) / W, y: (box.y + q.y * box.h) / H, z: q.z })));
    this.sched.report('face', tm.face);
  }

  _finish(t0, meta) {
    this.ms.total = performance.now() - t0;
    this.sched.reportFrame(this.ms.total);
    meta.ms = this.ms.total;
  }

  _personLayer(bmp) {
    if (this._personFrame === this.frameNo) return this.pl;
    const p = this.plx; p.globalCompositeOperation = 'source-over'; p.clearRect(0, 0, this.W, this.H);
    p.drawImage(bmp, 0, 0, this.W, this.H);
    p.globalCompositeOperation = 'destination-in'; p.drawImage(this.mask.canvas, 0, 0, this.W, this.H);
    p.globalCompositeOperation = 'source-over';
    this._personFrame = this.frameNo;
    return this.pl;
  }

  // Brightness correction: aims the picture's average brightness at a comfortable level, changing slowly.
  _updateTouchGain(bmp) {
    if (this.frameNo % 8 !== 0) return;
    this.lumaX.drawImage(bmp, 0, 0, 24, 14);
    const d = this.lumaX.getImageData(0, 0, 24, 14).data;
    let y = 0; for (let i = 0; i < d.length; i += 4) y += d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
    y /= d.length / 4;
    const want = clamp(118 / Math.max(20, y), 0.92, 1.7);
    this.touchGain += (want - this.touchGain) * 0.15;
  }

  _blurredFrame(bmp) {
    this.blurAx.drawImage(bmp, 0, 0, this.blurA.width, this.blurA.height);
    this.blurBx.drawImage(this.blurA, 0, 0, this.blurB.width, this.blurB.height);
    return this.blurB;
  }

  // Camera picture with the always-on options: brightness touch-up, blurred or replaced background.
  _drawBase(bmp, t) {
    const { o, W, H } = this, bgMode = this.settings.background.mode;
    const filt = this.settings.touchUp ? `brightness(${this.touchGain.toFixed(3)}) contrast(1.06) saturate(1.08)` : 'none';
    if (this.settings.touchUp) this._updateTouchGain(bmp);
    const haveMask = bgMode !== 'none' && this.mask.has(t, 900);
    o.filter = filt;
    if (haveMask) {
      if (bgMode === 'image' && this.media.ready('bg')) this.media.draw(o, 'bg', t, { x: 0, y: 0, w: W, h: H }, 'cover');
      else { o.imageSmoothingQuality = 'high'; o.drawImage(this._blurredFrame(bmp), 0, 0, W, H); }
      o.drawImage(this._personLayer(bmp), 0, 0);
    } else o.drawImage(bmp, 0, 0, W, H);
    o.filter = 'none';
  }

  _render(bmp, t, lv) {
    const { o, W, H } = this;
    o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = 1; o.globalCompositeOperation = 'source-over'; o.filter = 'none';
    this._drawBase(bmp, t);

    // freeze: the picture stops here (the camera keeps being analysed so a gesture or button can release it)
    if (lv.freeze.active) {
      if (!this.freezeOn) { this.fzx.drawImage(this.out, 0, 0); this.freezeOn = true; }
      o.drawImage(this.freezeShot, 0, 0, W, H);
      if (this.settings.debug) this._drawDebug(o);
      return;
    }
    this.freezeOn = false;

    // vanish: the person turns to dust, the screen fades to black, then the end screen (your text / picture)
    const ph = lv.vanish.phase, vp = lv.vanish.progress;
    let endAlpha = 0, blackAlpha = 0;
    if (ph !== 'visible') {
      blackAlpha = ph === 'dissolving' ? smooth(0.3, 1, vp) : ph === 'gone' ? 1 : 1 - smooth(0, 0.6, vp);
      endAlpha = ph === 'dissolving' ? smooth(0.7, 1, vp) : ph === 'gone' ? 1 : 1 - smooth(0, 0.35, vp);
      if (ph !== 'gone' && this.mask.valid && this.vanish.P) this.vanish.drawReplace(o, this.bg.plate, this.mask, ph, vp);
      if (blackAlpha > 0) { o.globalAlpha = blackAlpha; o.fillStyle = '#000'; o.fillRect(0, 0, W, H); o.globalAlpha = 1; }
      if (ph !== 'gone' && this.vanish.P) this.vanish.drawParticles(o, ph, vp, ph === 'dissolving' ? this.settings.vanish.durationSec : this.settings.vanish.returnSec);
    }

    // sad meme: behind the person, text in front of everything in the scene
    if (lv.sad.level > 0.001) {
      const drew = this.overlays.drawSadBack(o, lv.sad.level, lv.sad.since, t, this.media);
      if (drew && ph === 'visible' && this.mask.has(t)) o.drawImage(this._personLayer(bmp), 0, 0);
      this.overlays.drawSadText(o, lv.sad.level, lv.sad.since, t);
    }

    // custom memes: whole screen, or as the background behind you
    for (const c of this.settings.customs || []) {
      const L = lv[c.id];
      if (!L || L.level <= 0.001) continue;
      const drew = this.overlays.drawMeme(o, this.media, c.id, L.level, L.since, t);
      if (drew && c.mode === 'behind' && this.mask.has(t, 900)) o.drawImage(this._personLayer(bmp), 0, 0);
    }

    // cinema poster with your face
    if (lv.cinema.level > 0.001) this.poster.draw(o, lv.cinema.level, bmp, this.faces, this.pose, t);

    // full-screen clip, money rain
    if (!this.overlays.drawMeme(o, this.media, 'ovr_punisher', lv.punisher.level, lv.punisher.since, t)) this.overlays.drawPunisher(o, lv.punisher.level, lv.punisher.since, t);
    if (!this.overlays.drawMeme(o, this.media, 'ovr_money', lv.money.level, lv.money.since, t)) this.overlays.drawMoney(o, lv.money.level, lv.money.since, t);

    // sunglasses, confetti, hearts, flames, name banner
    if (lv.deal.level > 0.001) { this.fx.setEye(this._eyeFrame()); this.fx.drawGlasses(o, lv.deal.level, lv.deal.since, t); }
    this.fx.drawConfetti(o, lv.confetti.level, lv.confetti.since, t);
    this.fx.drawHearts(o, lv.hearts.level, lv.hearts.since, t);
    this.fx.drawFlames(o, lv.flames.level, lv.flames.since, t);
    this.fx.drawBanner(o, lv.banner.level, t, this.settings.banner.name, this.settings.banner.role);

    if (endAlpha > 0) this.overlays.drawEndScreen(o, this.media, this.settings.vanish.endText, endAlpha, this.endSince || t, t);

    if (this.settings.debug) this._drawDebug(o);
  }

  // Where the eyes are, in pixels: from the face model, else from the pose model.
  _eyeFrame() {
    const { W, H } = this;
    const f = this.faces && this.faces[0];
    if (f) {
      const c = (a, b) => [(f[a].x + f[b].x) / 2 * W, (f[a].y + f[b].y) / 2 * H];
      const l = c(33, 133), r = c(263, 362);
      return { cx: (l[0] + r[0]) / 2, cy: (l[1] + r[1]) / 2, dist: Math.hypot(r[0] - l[0], r[1] - l[1]), tilt: Math.atan2(r[1] - l[1], r[0] - l[0]) };
    }
    const p = this.pose;
    if (p && p[2] && p[5] && (p[2].visibility ?? 1) > 0.4 && (p[5].visibility ?? 1) > 0.4) {
      const l = [p[5].x * W, p[5].y * H], r = [p[2].x * W, p[2].y * H];    // pose 5 is the eye on the image's left
      return { cx: (l[0] + r[0]) / 2, cy: (l[1] + r[1]) / 2, dist: Math.hypot(r[0] - l[0], r[1] - l[1]) * 1.25, tilt: Math.atan2(r[1] - l[1], r[0] - l[0]) };
    }
    return null;
  }

  _drawDebug(o) {
    const g = this.gest.status();
    const lines = [
      `fps ${this.fps.toFixed(1)}  total ${this.ms.total.toFixed(1)}ms  ml ${this.ms.ml.toFixed(1)}ms  render ${this.ms.render.toFixed(1)}ms  L${this.sched.level}`,
      `hands ${g.hands.map((h) => Object.entries(h.fingers).map(([k, v]) => k[0].toUpperCase() + (v === 'ext' ? '+' : v === 'curl' ? '-' : '~')).join('')).join(' | ') || 'none'}`,
      `holding ${g.present.map((p) => p.g + ' ' + p.ms + 'ms').join(', ') || '-'}   last ${g.lastFired ? g.lastFired.gesture : '-'}`,
    ];
    o.save(); o.fillStyle = 'rgba(0,0,0,0.6)'; o.fillRect(8, 8, 640, 18 * lines.length + 10);
    o.fillStyle = '#9fe'; o.font = '13px monospace'; o.textBaseline = 'top';
    lines.forEach((l, i) => o.fillText(l, 14, 12 + i * 18));
    for (const h of this.hands) { o.fillStyle = '#f5a'; for (const p of h.landmarks) o.fillRect(p.x * this.W - 2, p.y * this.H - 2, 4, 4); }
    o.restore();
  }

  getStatus() {
    const lv = this.ctrl.levels();
    return {
      state: this.state, initError: this.initError, models: this.modelStatus(), assets: { ...this.assets.status }, mlReady: this.mlReady,
      fps: +this.fps.toFixed(1), ms: { total: +this.ms.total.toFixed(1), ml: +this.ms.ml.toFixed(1), render: +this.ms.render.toFixed(1) },
      scheduler: this.sched.snapshot(), effects: lv, person: { present: this.mask.has(this.lastT || this._now(), 1500), fraction: +this.mask.fraction.toFixed(3) },
      background: { coverage: +this.bg.coverage().toFixed(2), captured: this.bg.captured },
      gesture: this.gest.status(), lastCommand: this.lastCommand, size: { w: this.W, h: this.H },
      media: { ...this.media.status },
    };
  }

  destroy() { try { this.vision.close(); } catch (_) {} this.state = 'failed'; }
}
