// Background model for the vanish effect: learns what the scene looks like WITHOUT the person.
//
// How it works
//   * A full-resolution "plate" canvas starts EMPTY (transparent). Nothing is assumed.
//   * Every ~90 ms, pixels the segmentation mask says are background (with a safety margin) are
//     written to the plate. A low-resolution grid counts how long each area has been seen
//     without the person; an area becomes "known" after a few consecutive clean observations.
//   * When the person vanishes, areas that were never seen (they were always behind the
//     person) are filled by smooth diffusion from their known surroundings plus fine grain.
//   * If the person later moves and uncovers a guessed area, the real pixels replace the guess.
//
// Honest limits: the plate can only show what the camera has actually seen. For an area that was
// always behind the person, the result is a plausible smooth guess, not the real wall. Lighting
// changes after learning show as a slight tone difference. captureNow() (step out of frame and
// press the button) gives the best result.

import { makeCanvas, ctx2d, rng } from './util.js';

const GW = 192;

export class BackgroundModel {
  constructor() { this.W = 0; this.H = 0; this.lastLearn = -1e9; this.captured = false; this.frames = 0; }

  setup(W, H) {
    this.W = W; this.H = H; this.GH = Math.max(8, Math.round(GW * H / W));
    this.plate = makeCanvas(W, H); this.pctx = ctx2d(this.plate);
    this.layer = makeCanvas(W, H); this.lctx = ctx2d(this.layer);
    this.fresh = makeCanvas(W, H); this.fctx = ctx2d(this.fresh);
    const n = GW * this.GH;
    this.seen = new Uint8Array(n);       // consecutive clean observations
    this.known = new Uint8Array(n);      // 1 = real pixels in the plate
    this.guess = new Uint8Array(n);      // 1 = filled by inpainting (replace when real data arrives)
    this.occ = new Float32Array(n); this.occ2 = new Float32Array(n);
    this.gridC = makeCanvas(GW, this.GH); this.gx = ctx2d(this.gridC); this.gImg = this.gx.createImageData(GW, this.GH);
    this.knownC = makeCanvas(GW, this.GH); this.kx = ctx2d(this.knownC); this.kImg = this.kx.createImageData(GW, this.GH);
    this.small = makeCanvas(GW, this.GH); this.sx = ctx2d(this.small, { willReadFrequently: true });
    this.frames = 0; this.captured = false;
  }

  reset() { if (this.W) this.setup(this.W, this.H); }

  // Share of the scene that has been genuinely observed without the person (0..1).
  coverage() { if (!this.known) return 0; let k = 0; for (let i = 0; i < this.known.length; i++) k += this.known[i]; return k / this.known.length; }
  // Share of the current silhouette that sits on guessed (not observed) background.
  guessedShare() { let g = 0, k = 0; for (let i = 0; i < this.guess.length; i++) { g += this.guess[i]; k += this.known[i]; } return (g + k) ? g / (g + k) : 0; }

  _occupancy(mp, haveMask) {
    const n = GW * this.GH, occ = this.occ, o2 = this.occ2;
    if (!haveMask) { occ.fill(1); return; }
    const { w, h, sm } = mp;
    for (let gy = 0; gy < this.GH; gy++) {
      const y0 = Math.floor(gy * h / this.GH), y1 = Math.max(y0 + 1, Math.floor((gy + 1) * h / this.GH));
      for (let gx = 0; gx < GW; gx++) {
        const x0 = Math.floor(gx * w / GW), x1 = Math.max(x0 + 1, Math.floor((gx + 1) * w / GW));
        let m = 0;
        for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const v = sm[y * w + x]; if (v > m) m = v; }
        occ[gy * GW + gx] = m;
      }
    }
    // dilate by 3 cells (separable max): person edges, hair and motion blur must not leak in
    const R = 3;
    for (let y = 0; y < this.GH; y++) for (let x = 0; x < GW; x++) { let m = 0; for (let k = -R; k <= R; k++) { const xx = x + k; if (xx >= 0 && xx < GW) { const v = occ[y * GW + xx]; if (v > m) m = v; } } o2[y * GW + x] = m; }
    for (let y = 0; y < this.GH; y++) for (let x = 0; x < GW; x++) { let m = 0; for (let k = -R; k <= R; k++) { const yy = y + k; if (yy >= 0 && yy < this.GH) { const v = o2[yy * GW + x]; if (v > m) m = v; } } occ[y * GW + x] = m; }
  }

  // frame: ImageBitmap; mp: MaskProcessor; t: ms
  learn(frame, mp, t, everyMs = 90) {
    if (!this.W || t - this.lastLearn < everyMs) return;
    this.lastLearn = t;
    const haveMask = !!(mp && mp.valid && t - mp.lastUpdate < 800);
    this._occupancy(mp, haveMask);
    const n = GW * this.GH; let newly = 0;
    const g = this.gImg.data, kd = this.kImg.data;
    for (let i = 0; i < n; i++) {
      const clean = haveMask && this.occ[i] < 0.06;
      if (clean) { if (this.seen[i] < 255) this.seen[i]++; } else this.seen[i] = 0;
      let fresh = 0;
      if (clean && this.seen[i] >= 3 && (!this.known[i] || this.guess[i])) { this.known[i] = 1; this.guess[i] = 0; fresh = 255; newly++; }
      g[i * 4] = g[i * 4 + 1] = g[i * 4 + 2] = 255; g[i * 4 + 3] = fresh;
      kd[i * 4] = kd[i * 4 + 1] = kd[i * 4 + 2] = 255; kd[i * 4 + 3] = (this.known[i] && clean) ? 255 : 0;
    }
    if (!haveMask) return;                       // without a mask we cannot tell person from wall
    // layer = current frame minus the grown person mask
    const l = this.lctx;
    l.globalCompositeOperation = 'source-over'; l.clearRect(0, 0, this.W, this.H);
    l.drawImage(frame, 0, 0, this.W, this.H);
    l.globalCompositeOperation = 'destination-out'; l.drawImage(mp.grown, 0, 0, this.W, this.H); l.globalCompositeOperation = 'source-over';
    if (newly) {
      // freshly known cells: write at full strength
      this.gx.putImageData(this.gImg, 0, 0);
      const f = this.fctx; f.globalCompositeOperation = 'source-over'; f.clearRect(0, 0, this.W, this.H);
      f.drawImage(this.layer, 0, 0);
      f.globalCompositeOperation = 'destination-in'; f.imageSmoothingEnabled = false; f.drawImage(this.gridC, 0, 0, this.W, this.H); f.imageSmoothingEnabled = true;
      f.globalCompositeOperation = 'source-over';
      this.pctx.drawImage(this.fresh, 0, 0);
    }
    // slow adaptation, only where real pixels already exist and are currently clean
    this.kx.putImageData(this.kImg, 0, 0);
    const f2 = this.fctx; f2.globalCompositeOperation = 'source-over'; f2.clearRect(0, 0, this.W, this.H);
    f2.drawImage(this.layer, 0, 0);
    f2.globalCompositeOperation = 'destination-in'; f2.imageSmoothingEnabled = false; f2.drawImage(this.knownC, 0, 0, this.W, this.H); f2.imageSmoothingEnabled = true;
    f2.globalCompositeOperation = 'source-over';
    this.pctx.globalAlpha = this.captured ? 0.025 : 0.05; this.pctx.drawImage(this.fresh, 0, 0); this.pctx.globalAlpha = 1;
    this.frames++;
  }

  // Snapshot the current frame as the whole background (the user stepped out of frame).
  captureNow(frame) {
    if (!this.W) return;
    this.pctx.globalCompositeOperation = 'source-over'; this.pctx.globalAlpha = 1;
    this.pctx.drawImage(frame, 0, 0, this.W, this.H);
    this.known.fill(1); this.guess.fill(0); this.seen.fill(10); this.captured = true;
  }

  // Fill never-observed areas with a smooth guess. Call right before vanishing.
  inpaintUnknown() {
    if (!this.W) return { filled: 0 };
    const n = GW * this.GH; let holes = 0;
    for (let i = 0; i < n; i++) if (!this.known[i]) holes++;
    if (!holes) return { filled: 0, guessed: this.guessedShare() };
    this.sx.clearRect(0, 0, GW, this.GH);
    this.sx.drawImage(this.plate, 0, 0, GW, this.GH);
    const px = this.sx.getImageData(0, 0, GW, this.GH).data;
    // erode "known" by one cell so border pixels contaminated by the person do not seed the fill
    const wgt = new Float32Array(n), rgb = new Float32Array(n * 3);
    for (let y = 0; y < this.GH; y++) for (let x = 0; x < GW; x++) {
      const i = y * GW + x; let ok = this.known[i] && !this.guess[i] ? 1 : 0;
      if (ok) for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) { const xx = x + dx, yy = y + dy; if (xx >= 0 && yy >= 0 && xx < GW && yy < this.GH && !this.known[yy * GW + xx]) { ok = 0; break; } }
      wgt[i] = ok && px[i * 4 + 3] > 240 ? 1 : 0;
      rgb[i * 3] = px[i * 4]; rgb[i * 3 + 1] = px[i * 4 + 1]; rgb[i * 3 + 2] = px[i * 4 + 2];
    }
    const filled = pushPull(rgb, wgt, GW, this.GH);
    const fImg = this.sx.createImageData(GW, this.GH), hImg = this.sx.createImageData(GW, this.GH);
    for (let i = 0; i < n; i++) {
      fImg.data[i * 4] = filled[i * 3]; fImg.data[i * 4 + 1] = filled[i * 3 + 1]; fImg.data[i * 4 + 2] = filled[i * 3 + 2]; fImg.data[i * 4 + 3] = 255;
      hImg.data[i * 4] = hImg.data[i * 4 + 1] = hImg.data[i * 4 + 2] = 255; hImg.data[i * 4 + 3] = wgt[i] ? 0 : 255;
    }
    const fc = makeCanvas(GW, this.GH), hc = makeCanvas(GW, this.GH);
    ctx2d(fc).putImageData(fImg, 0, 0); ctx2d(hc).putImageData(hImg, 0, 0);
    // smooth upscale of the fill, with fine grain so it does not look like flat plastic
    const up = makeCanvas(this.W, this.H), ux = ctx2d(up);
    ux.filter = `blur(${Math.max(1.5, this.W / 260)}px)`; ux.drawImage(fc, 0, 0, this.W, this.H); ux.filter = 'none';
    const R = rng(99), img = ux.getImageData(0, 0, Math.min(this.W, 64), 1); // noise tile
    const tile = makeCanvas(128, 128), tx = ctx2d(tile), ti = tx.createImageData(128, 128);
    for (let i = 0; i < ti.data.length; i += 4) { const v = 128 + (R() - 0.5) * 24; ti.data[i] = ti.data[i + 1] = ti.data[i + 2] = v; ti.data[i + 3] = 255; }
    tx.putImageData(ti, 0, 0);
    ux.globalCompositeOperation = 'overlay'; ux.globalAlpha = 0.35; ux.fillStyle = ux.createPattern(tile, 'repeat'); ux.fillRect(0, 0, this.W, this.H);
    ux.globalAlpha = 1; ux.globalCompositeOperation = 'source-over';
    // cut the hole (slightly feathered) out of the plate and put the fill underneath
    const hole = makeCanvas(this.W, this.H), hx = ctx2d(hole);
    hx.filter = `blur(${Math.max(1, this.W / 400)}px)`; hx.drawImage(hc, 0, 0, this.W, this.H); hx.filter = 'none';
    this.pctx.globalCompositeOperation = 'destination-out'; this.pctx.drawImage(hole, 0, 0); 
    this.pctx.globalCompositeOperation = 'destination-over'; this.pctx.drawImage(up, 0, 0);
    this.pctx.globalCompositeOperation = 'source-over';
    for (let i = 0; i < n; i++) if (!this.known[i]) { this.known[i] = 1; this.guess[i] = 1; }
    return { filled: holes, guessed: this.guessedShare() };
  }
}

// Push-pull diffusion fill with bilinear upsampling. rgb: Float32 [w*h*3], wgt: Float32 [w*h].
export function pushPull(rgb, wgt, w, h) {
  const levels = [{ w, h, rgb: Float32Array.from(rgb), wgt: Float32Array.from(wgt) }];
  while (levels[levels.length - 1].w > 2 && levels[levels.length - 1].h > 2) {
    const s = levels[levels.length - 1];
    const nw = Math.ceil(s.w / 2), nh = Math.ceil(s.h / 2);
    const rgbN = new Float32Array(nw * nh * 3), wN = new Float32Array(nw * nh);
    for (let y = 0; y < s.h; y++) for (let x = 0; x < s.w; x++) {
      const si = y * s.w + x, di = (y >> 1) * nw + (x >> 1), wv = s.wgt[si];
      if (wv > 0) { rgbN[di * 3] += s.rgb[si * 3] * wv; rgbN[di * 3 + 1] += s.rgb[si * 3 + 1] * wv; rgbN[di * 3 + 2] += s.rgb[si * 3 + 2] * wv; wN[di] += wv; }
    }
    for (let i = 0; i < nw * nh; i++) if (wN[i] > 0) { rgbN[i * 3] /= wN[i]; rgbN[i * 3 + 1] /= wN[i]; rgbN[i * 3 + 2] /= wN[i]; wN[i] = Math.min(1, wN[i]); }
    levels.push({ w: nw, h: nh, rgb: rgbN, wgt: wN });
  }
  const top = levels[levels.length - 1];
  let any = 0; for (let i = 0; i < top.wgt.length; i++) any += top.wgt[i];
  if (any === 0) return new Float32Array(rgb.length).fill(128);   // nothing known anywhere: neutral grey, never NaN
  for (let l = levels.length - 2; l >= 0; l--) {
    const f = levels[l], c = levels[l + 1];
    for (let y = 0; y < f.h; y++) for (let x = 0; x < f.w; x++) {
      const i = y * f.w + x, wv = f.wgt[i];
      if (wv >= 1) continue;
      // bilinear sample of the coarser level at the cell centre
      const fx = (x + 0.5) / 2 - 0.5, fy = (y + 0.5) / 2 - 0.5;
      const x0 = Math.max(0, Math.min(c.w - 1, Math.floor(fx))), y0 = Math.max(0, Math.min(c.h - 1, Math.floor(fy)));
      const x1 = Math.min(c.w - 1, x0 + 1), y1 = Math.min(c.h - 1, y0 + 1), ax = Math.max(0, Math.min(1, fx - x0)), ay = Math.max(0, Math.min(1, fy - y0));
      for (let k = 0; k < 3; k++) {
        const v = (c.rgb[(y0 * c.w + x0) * 3 + k] * (1 - ax) + c.rgb[(y0 * c.w + x1) * 3 + k] * ax) * (1 - ay) + (c.rgb[(y1 * c.w + x0) * 3 + k] * (1 - ax) + c.rgb[(y1 * c.w + x1) * 3 + k] * ax) * ay;
        f.rgb[i * 3 + k] = f.rgb[i * 3 + k] * wv + v * (1 - wv);
      }
      f.wgt[i] = 1;
    }
  }
  return levels[0].rgb;
}
