// Finger-state analysis of one MediaPipe hand (21 landmarks). Pure functions, pixel-space maths
// (landmarks are normalised, so x is scaled by the frame width and y by the frame height first).
//
// Every finger is classed 'ext' (clearly straight), 'curl' (clearly folded) or 'mid' (neither).
// Gestures only fire on clear states, so half-bent fingers during ordinary hand movement do nothing.

const WRIST = 0;
const FINGERS = {
  index:  { mcp: 5,  pip: 6,  dip: 7,  tip: 8 },
  middle: { mcp: 9,  pip: 10, dip: 11, tip: 12 },
  ring:   { mcp: 13, pip: 14, dip: 15, tip: 16 },
  pinky:  { mcp: 17, pip: 18, dip: 19, tip: 20 },
};

export const T = {
  extReach: 1.2,        // tip-to-wrist / pip-to-wrist: above this a finger is straight
  curlReach: 0.98,      // below this it is folded
  extStraight: 0.7,     // cosine between the two end segments of an extended finger
  thumbExtOut: 0.85,    // thumb tip distance from index knuckle / palm size
  thumbTucked: 0.62,
  thumbStraight: 0.6,
};

const pt = (lm, i, w, h) => ({ x: lm[i].x * w, y: lm[i].y * h });
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const cosAngle = (a, b, c, d) => {            // between vectors a->b and c->d
  const ux = b.x - a.x, uy = b.y - a.y, vx = d.x - c.x, vy = d.y - c.y;
  const n = Math.hypot(ux, uy) * Math.hypot(vx, vy);
  return n < 1e-6 ? 0 : (ux * vx + uy * vy) / n;
};

export function analyzeHand(lm, w, h) {
  if (!lm || lm.length < 21) return null;
  const P = (i) => pt(lm, i, w, h);
  const wr = P(WRIST);
  const scale = (dist(wr, P(9)) + dist(P(5), P(17))) / 2;      // palm size in pixels
  if (!(scale > 6)) return null;

  const fingers = {};
  const detail = {};
  for (const [name, f] of Object.entries(FINGERS)) {
    const reach = dist(P(f.tip), wr) / Math.max(1e-6, dist(P(f.pip), wr));
    const straight = cosAngle(P(f.mcp), P(f.pip), P(f.dip), P(f.tip));
    let st = 'mid';
    if (reach > T.extReach && straight > T.extStraight) st = 'ext';
    else if (reach < T.curlReach) st = 'curl';
    fingers[name] = st;
    detail[name] = { reach: +reach.toFixed(2), straight: +straight.toFixed(2) };
  }
  const tipOut = dist(P(4), P(5)) / scale;
  const thumbStraight = cosAngle(P(2), P(3), P(3), P(4));
  fingers.thumb = tipOut > T.thumbExtOut && thumbStraight > T.thumbStraight ? 'ext' : tipOut < T.thumbTucked ? 'curl' : 'mid';
  detail.thumb = { out: +tipOut.toFixed(2), straight: +thumbStraight.toFixed(2) };

  const palm = { x: 0, y: 0 };
  for (const i of [0, 5, 9, 13, 17]) { const p = P(i); palm.x += p.x / 5; palm.y += p.y / 5; }
  // direction helpers (y grows downwards, so "up" is negative y)
  const up = (a, b) => (a.y - b.y) / Math.max(1e-6, dist(a, b));      // 1 = b is straight above a
  return {
    scale, fingers, detail, palm, wrist: wr, tipMid: P(12), tipIndex: P(8),
    pointsUp: up(wr, P(9)),                       // hand orientation
    indexUp: up(P(5), P(8)),                      // index finger direction
    thumbUp: up(P(2), P(4)),                      // thumb direction
    pinch: dist(P(4), P(8)) / scale,              // thumb tip to index tip, in palm sizes
  };
}

// Single-hand static poses. Returns the pose names that hold for this hand (usually zero or one).
export function staticPoses(a) {
  if (!a) return [];
  const f = a.fingers, out = [];
  const strictCurl = (...names) => names.every((n) => f[n] === 'curl');
  const four = f.index === 'ext' && f.middle === 'ext' && f.ring === 'ext' && f.pinky === 'ext';

  const upright = a.pointsUp > -0.25;       // a hand hanging down (arms resting on knees or desk) is not a gesture
  if (four && f.thumb === 'ext' && upright) out.push('openPalm');
  if (f.index === 'ext' && strictCurl('middle', 'ring', 'pinky') && a.indexUp > 0.55) out.push('indexUp');
  if (f.index === 'ext' && f.middle === 'ext' && strictCurl('ring', 'pinky') && upright) out.push('victory');
  if (f.pinky === 'ext' && strictCurl('index', 'middle', 'ring') && f.thumb !== 'ext' && upright) out.push('pinkyUp');
  if (f.thumb === 'ext' && strictCurl('index', 'middle', 'ring', 'pinky') && a.thumbUp > 0.6) out.push('thumbUp');
  if (f.index === 'ext' && f.middle === 'ext' && f.ring === 'ext' && strictCurl('pinky') && upright) out.push('threeFingers');
  if (four && f.thumb !== 'ext' && upright) out.push('fourFingers');
  if (a.pinch < 0.38 && f.middle === 'ext' && f.ring === 'ext' && f.pinky === 'ext' && upright) out.push('okSign');
  if (f.index === 'ext' && f.pinky === 'ext' && strictCurl('middle', 'ring') && upright) out.push('rockOn');
  if (f.thumb === 'ext' && f.pinky === 'ext' && strictCurl('index', 'middle', 'ring')) out.push('shaka');
  return out;
}

export const isFourFingersOpen = (a) => !!a && ['index', 'middle', 'ring', 'pinky'].every((n) => a.fingers[n] === 'ext');
