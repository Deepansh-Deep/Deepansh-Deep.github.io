// MediaPipe Tasks wrapper. Each model loads independently, so a failure in one (for example
// the face model on a very old GPU) disables only the effects that need it, and the failure
// is reported, never swallowed. GPU delegate first, CPU fallback.

import { FilesetResolver, HandLandmarker, PoseLandmarker, FaceLandmarker } from '../../lib/vision_bundle.mjs';

const MODELS = {
  hand: { cls: HandLandmarker, file: 'models/hand_landmarker.task',
    opts: { numHands: 2, minHandDetectionConfidence: 0.5, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.4 } },
  pose: { cls: PoseLandmarker, file: 'models/pose_landmarker_lite.task',
    opts: { numPoses: 1, outputSegmentationMasks: true, minPoseDetectionConfidence: 0.5, minPosePresenceConfidence: 0.5, minTrackingConfidence: 0.5 } },
  face: { cls: FaceLandmarker, file: 'models/face_landmarker.task',
    opts: { numFaces: 1, minFaceDetectionConfidence: 0.5, minFacePresenceConfidence: 0.5, minTrackingConfidence: 0.5 } },
};

export class Vision {
  // baseUrl: absolute URL of the directory containing models/ and lib/ (ends with '/').
  constructor({ baseUrl, log = () => {}, order = ['hand', 'pose', 'face'], delegates = ['GPU', 'CPU'] } = {}) {
    this.baseUrl = baseUrl;
    this.log = log;
    this.order = order;
    this.delegates = delegates;
    this.tasks = {};
    this.status = {};
    for (const k of order) this.status[k] = { state: 'pending', delegate: null, error: null, ms: 0 };
    this.fileset = null;
  }

  available() {
    const o = {};
    for (const k of this.order) o[k] = this.status[k].state === 'ready';
    return o;
  }

  async init(onProgress = () => {}) {
    try {
      this.fileset = await FilesetResolver.forVisionTasks(this.baseUrl + 'lib/wasm');
    } catch (e) {
      for (const k of this.order) this.status[k] = { state: 'failed', delegate: null, error: 'wasm runtime: ' + msg(e), ms: 0 };
      this.log('error', 'MediaPipe runtime failed to load', msg(e));
      onProgress(this.status);
      return this.status;
    }
    for (const k of this.order) {
      this.status[k].state = 'loading'; onProgress(this.status);
      const t0 = performance.now();
      let lastErr = null;
      for (const delegate of this.delegates) {
        try {
          const m = MODELS[k];
          this.tasks[k] = await m.cls.createFromOptions(this.fileset, Object.assign({
            baseOptions: { modelAssetPath: this.baseUrl + m.file, delegate }, runningMode: 'VIDEO',
          }, m.opts));
          this.status[k] = { state: 'ready', delegate, error: null, ms: Math.round(performance.now() - t0) };
          lastErr = null;
          break;
        } catch (e) { lastErr = e; this.log('warn', `${k} model failed on ${delegate}`, msg(e)); }
      }
      if (lastErr) this.status[k] = { state: 'failed', delegate: null, error: msg(lastErr), ms: Math.round(performance.now() - t0) };
      onProgress(this.status);
    }
    return this.status;
  }

  // Runs the models selected by `plan` on `source` (canvas/ImageBitmap). Returns only what ran.
  // A throwing model is marked failed (and reported) instead of crashing the frame.
  detect(source, ts, plan, timings = {}) {
    const out = {};
    if (plan.hand && this.tasks.hand) {
      const t0 = performance.now();
      try {
        const r = this.tasks.hand.detectForVideo(source, ts);
        out.hands = (r.landmarks || []).map((lm, i) => ({
          label: (r.handedness && r.handedness[i] && r.handedness[i][0] && r.handedness[i][0].categoryName) || ('Hand' + i),
          landmarks: lm,
        }));
      } catch (e) { this._fail('hand', e); }
      timings.hand = performance.now() - t0;
      this._observe('hand', timings.hand);
    }
    if (plan.pose && this.tasks.pose) {
      const t0 = performance.now();
      try {
        const r = this.tasks.pose.detectForVideo(source, ts);
        out.pose = (r.landmarks && r.landmarks[0]) || null;
        const m = r.segmentationMasks && r.segmentationMasks[0];
        if (m) {
          out.mask = { width: m.width, height: m.height, data: m.getAsFloat32Array() };
          for (const mm of r.segmentationMasks) if (mm.close) mm.close();
        } else out.mask = null;
        out.poseRan = true;
      } catch (e) { this._fail('pose', e); }
      timings.pose = performance.now() - t0;
      this._observe('pose', timings.pose);
    }
    if (plan.face && this.tasks.face) {
      const t0 = performance.now();
      try {
        const r = this.tasks.face.detectForVideo(source, ts);
        out.faces = r.faceLandmarks || [];
        out.faceRan = true;
      } catch (e) { this._fail('face', e); }
      timings.face = performance.now() - t0;
      this._observe('face', timings.face);
    }
    return out;
  }

  // Speed check. A GPU delegate that is really software-emulated (virtual machines, remote desktop, old drivers)
  // is many times slower than the CPU delegate. After a few calls each model is timed; if it is slow on the GPU
  // it is reloaded on the CPU in the background (the old one keeps serving until the new one is ready), and the
  // faster of the two is kept.
  _observe(k, ms) {
    const st = this.status[k], b = (this.bench || (this.bench = {}))[k] || (this.bench[k] = { n: 0, ms: [], tried: {}, done: false });
    if (b.done || st.state !== 'ready' || !this.delegates.includes('CPU') || !this.delegates.includes('GPU') || b.swapping) return;
    b.n++;
    if (b.n <= 3) return;                                   // warm-up calls are slow on every delegate
    b.ms.push(ms);
    if (b.ms.length < 8) return;
    const med = [...b.ms].sort((x, y) => x - y)[b.ms.length >> 1];
    b.ms = []; b.n = 0;
    b.tried[st.delegate] = med;
    const other = st.delegate === 'GPU' ? 'CPU' : 'GPU';
    if (b.tried[other] !== undefined) {                       // both measured: keep the faster
      b.done = true;
      if (b.tried[other] < med * 0.85) this._swap(k, other, true);
      else this.log('info', `${k}: ${st.delegate} kept (${Math.round(med)} ms vs ${Math.round(b.tried[other])} ms)`);
      return;
    }
    if (st.delegate === 'GPU' && med > 40) this._swap(k, 'CPU');   // slow GPU path: try the CPU
    else b.done = true;                                           // fast enough
  }

  async _swap(k, delegate, final = false) {
    const b = this.bench[k]; b.swapping = true;
    try {
      const m = MODELS[k];
      const task = await m.cls.createFromOptions(this.fileset, Object.assign({ baseOptions: { modelAssetPath: this.baseUrl + m.file, delegate }, runningMode: 'VIDEO' }, m.opts));
      const old = this.tasks[k];
      this.tasks[k] = task;
      this.status[k] = { ...this.status[k], delegate };
      try { old && old.close(); } catch (_) {}
      this.log('info', `${k} model switched to ${delegate}`);
      if (final) b.done = true;
    } catch (e) { b.done = true; this.log('warn', `${k}: switching to ${delegate} failed`, msg(e)); }
    b.swapping = false;
  }

  _fail(k, e) {
    this.log('error', `${k} model crashed; disabling it`, msg(e));
    this.status[k] = { ...this.status[k], state: 'failed', error: 'runtime: ' + msg(e) };
    try { this.tasks[k] && this.tasks[k].close(); } catch (_) {}
    delete this.tasks[k];
  }

  close() {
    for (const [k, t] of Object.entries(this.tasks)) { try { t.close(); } catch (_) {} delete this.tasks[k]; }
  }
}

function msg(e) { return (e && e.message) ? e.message : String(e); }
