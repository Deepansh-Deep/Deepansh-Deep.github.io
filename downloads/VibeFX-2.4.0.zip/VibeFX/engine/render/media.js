// Pictures and GIFs the user uploads in the popup (vanish end screen, meme slots, background picture).
// They arrive from the bridge as {slot: {mime, b64, name}} and are decoded here. Nothing is fetched:
// base64 is decoded by hand (the extension CSP does not allow fetch() of data: URLs).
//
// GIFs are decoded frame by frame with WebCodecs ImageDecoder into ImageBitmaps (bounded pixel budget);
// everything else becomes one ImageBitmap.

const MAX_PIXELS = 24e6;        // total decoded pixels per animated item (about 96 MB), frames are skipped above this
const MAX_FRAME_W = 540;

function b64bytes(b64) {
  const bin = atob(b64), n = bin.length, out = new Uint8Array(n);
  for (let i = 0; i < n; i++) out[i] = bin.charCodeAt(i);
  return out;
}
const fingerprint = (m) => `${m.mime}:${m.b64.length}:${m.b64.slice(0, 48)}:${m.b64.slice(-48)}`;

const LAZY = /^c_/;          // the user's own memes are decoded when first used (there can be many), the rest right away
const KEEP_DECODED = 4;       // at most this many lazily decoded memes stay in memory

export class MediaStore {
  constructor(log = () => {}) { this.log = log; this.raw = {}; this.items = {}; this.status = {}; this.keys = {}; this.used = {}; this.inflight = {}; }

  has(slot) { return !!this.raw[slot]; }                 // something was uploaded for this slot
  ready(slot) { return !!this.items[slot]; }             // and it is decoded, so it can be drawn
  info(slot) { const it = this.items[slot]; return it ? { w: it.w, h: it.h, frames: it.frames.length, animated: it.frames.length > 1 } : null; }

  // media: the whole {slot: item} object. Slots that disappeared are dropped, changed ones re-decoded.
  async set(media = {}) {
    for (const slot of Object.keys(this.raw)) if (!media[slot]) this._drop(slot);
    const work = [];
    for (const [slot, m] of Object.entries(media)) {
      if (!m || !m.b64 || !m.mime) { this._drop(slot); continue; }
      const key = fingerprint(m);
      if (this.keys[slot] === key) continue;
      if (this.items[slot]) this._release(slot);          // changed file: the old decode is stale
      this.raw[slot] = m; this.keys[slot] = key; this.status[slot] = LAZY.test(slot) ? 'idle' : 'loading';
      if (!LAZY.test(slot)) work.push(this.ensure(slot));
    }
    await Promise.all(work);
    this._prewarm();
    return this.status;
  }

  // Decode the user's memes quietly in the background (one at a time, up to the memory cap) so the first press is instant.
  _prewarm() {
    if (this._warming) return;
    this._warming = (async () => {
      for (const slot of Object.keys(this.raw)) {
        if (!LAZY.test(slot) || this.items[slot] || this.status[slot] !== 'idle') continue;
        if (Object.keys(this.items).filter((k) => LAZY.test(k)).length >= KEEP_DECODED) break;
        await this.ensure(slot);
      }
    })().finally(() => { this._warming = null; });
  }

  // Decodes a slot if needed. Resolves true when it can be drawn.
  ensure(slot) {
    if (this.items[slot]) { this.used[slot] = performance.now(); return Promise.resolve(true); }
    const m = this.raw[slot]; if (!m) return Promise.resolve(false);
    if (this.inflight[slot]) return this.inflight[slot];
    const key = this.keys[slot];
    this.status[slot] = 'loading';
    const p = this._decode(m).then((it) => {
      if (this.keys[slot] !== key) { for (const f of it.frames) { try { f.bmp.close(); } catch (_) {} } return false; }     // replaced meanwhile
      this._put(slot, it); this.status[slot] = 'ready'; this.used[slot] = performance.now(); this._evict(slot); return true;
    }).catch((e) => {
      this.status[slot] = 'failed: ' + (e && e.message || e); this.log('warn', `media ${slot} failed`, String(e && e.message || e)); return false;
    }).finally(() => { delete this.inflight[slot]; });
    this.inflight[slot] = p;
    return p;
  }

  _evict(keep) {
    const lazy = Object.keys(this.items).filter((k) => LAZY.test(k) && k !== keep).sort((a, b) => (this.used[a] || 0) - (this.used[b] || 0));
    while (lazy.length >= KEEP_DECODED) { const k = lazy.shift(); this._release(k); this.status[k] = 'idle'; }
  }
  _release(slot) {
    const it = this.items[slot];
    if (it) for (const f of it.frames) { try { f.bmp.close(); } catch (_) {} }
    delete this.items[slot];
  }
  _drop(slot) { this._release(slot); delete this.raw[slot]; delete this.keys[slot]; delete this.status[slot]; delete this.used[slot]; }
  _put(slot, it) { this._release(slot); this.items[slot] = it; }

  async _decode({ mime, b64 }) {
    const bytes = b64bytes(b64);
    if (mime === 'image/gif' && typeof ImageDecoder === 'function') {
      const dec = new ImageDecoder({ data: bytes, type: mime });
      await dec.tracks.ready;
      await dec.completed;
      const track = dec.tracks.selectedTrack;
      if (!track) throw new Error('GIF has no image track');
      const n = track.frameCount;
      const frames = []; let w = 0, h = 0, total = 0;
      let step = 1;
      for (let i = 0; i < n; i += step) {
        const { image } = await dec.decode({ frameIndex: i });
        if (!w) {
          const s = Math.min(1, MAX_FRAME_W / image.displayWidth);
          w = Math.round(image.displayWidth * s); h = Math.round(image.displayHeight * s);
          step = Math.max(1, Math.ceil((n * w * h) / MAX_PIXELS));
        }
        const bmp = await createImageBitmap(image, { resizeWidth: w, resizeHeight: h, resizeQuality: 'medium' });
        let dur = (image.duration || 0) / 1000;
        if (!(dur > 10)) dur = 100;                          // browsers treat 0 and 10 ms GIF delays as 100 ms
        image.close();
        dur *= step; total += dur;
        frames.push({ bmp, end: total });
      }
      dec.close();
      if (!frames.length) throw new Error('GIF has no frames');
      return { frames, total, w, h };
    }
    const bmp = await createImageBitmap(new Blob([bytes], { type: mime }));
    return { frames: [{ bmp, end: 1 }], total: 1, w: bmp.width, h: bmp.height };
  }

  frameAt(slot, ms) {
    const it = this.items[slot]; if (!it) return null;
    this.used[slot] = performance.now();
    if (it.frames.length === 1) return it.frames[0].bmp;
    const t = ((ms % it.total) + it.total) % it.total;
    for (const f of it.frames) if (t < f.end) return f.bmp;
    return it.frames[it.frames.length - 1].bmp;
  }

  // fit: 'cover' fills the box and crops, 'contain' shows everything. box = {x, y, w, h}.
  draw(ctx, slot, ms, box, fit = 'cover') {
    const it = this.items[slot], bmp = this.frameAt(slot, ms);
    if (!it || !bmp) return false;
    const k = fit === 'cover' ? Math.max(box.w / it.w, box.h / it.h) : Math.min(box.w / it.w, box.h / it.h);
    const w = it.w * k, h = it.h * k;
    ctx.drawImage(bmp, box.x + (box.w - w) / 2, box.y + (box.h - h) / 2, w, h);
    return true;
  }
}
