// Loads the bundled picture assets (poster, meme cutout, GIF atlases). Everything comes from the extension
// itself; nothing is fetched from the network. Each asset reports its own state so one failure only disables
// the effect that needs it.

async function bitmap(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`);
  return createImageBitmap(await r.blob());
}

export const ATLAS = {
  money: { file: 'assets/money_atlas.webp', frames: 120, cols: 10, w: 480, h: 270, frameMs: 40 },
  punisher: { file: 'assets/punisher_atlas.webp', frames: 155, cols: 10, w: 360, h: 203, frameMs: 50 },
};

export class Assets {
  constructor(baseUrl, log = () => {}) {
    this.baseUrl = baseUrl; this.log = log;
    this.poster = null; this.posterGeo = null; this.sad = null; this.money = null; this.punisher = null;
    this.status = { poster: 'pending', sad: 'pending', money: 'pending', punisher: 'pending' };
  }

  async load(onProgress = () => {}) {
    const job = async (key, fn) => {
      this.status[key] = 'loading'; onProgress(this.status);
      try { await fn(); this.status[key] = 'ready'; }
      catch (e) { this.status[key] = 'failed: ' + (e && e.message || e); this.log('error', 'asset ' + key + ' failed', String(e && e.message || e)); }
      onProgress(this.status);
    };
    await Promise.all([
      job('poster', async () => {
        this.posterGeo = await (await fetch(this.baseUrl + 'assets/poster.json')).json();
        this.poster = await bitmap(this.baseUrl + 'assets/poster.jpg');
      }),
      job('sad', async () => { this.sad = await bitmap(this.baseUrl + 'assets/sad_cutout.png'); }),
      job('money', async () => { this.money = await bitmap(this.baseUrl + ATLAS.money.file); }),
      job('punisher', async () => { this.punisher = await bitmap(this.baseUrl + ATLAS.punisher.file); }),
    ]);
    return this.status;
  }

  ready(k) { return this.status[k] === 'ready'; }
}

// Draws frame `i` of an atlas into the destination rectangle.
export function drawAtlasFrame(ctx, bmp, spec, i, dx, dy, dw, dh) {
  const n = ((i % spec.frames) + spec.frames) % spec.frames;
  const col = n % spec.cols, row = (n / spec.cols) | 0;
  ctx.drawImage(bmp, col * spec.w, row * spec.h, spec.w, spec.h, dx, dy, dw, dh);
}
