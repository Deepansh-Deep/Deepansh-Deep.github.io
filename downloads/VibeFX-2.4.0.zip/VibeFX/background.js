// Service worker. Only job: show the truth on the toolbar badge. It never sees frames.
const COLORS = { ok: '#22c55e', warn: '#f59e0b', bad: '#ef4444', off: '#64748b' };

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.vibefx !== 'badge' || !sender.tab) return;
  const tabId = sender.tab.id;
  const c = COLORS[msg.level] || COLORS.off;
  chrome.action.setBadgeBackgroundColor({ tabId, color: c });
  chrome.action.setBadgeText({ tabId, text: msg.text || '' });
  chrome.action.setTitle({ tabId, title: msg.title || 'VibeFX' });
});

// Keyboard shortcuts are handled in the page (content/bridge.js). A key pressed in one frame of a call tab is
// passed on here so the frame that owns the camera engine can act on it.
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || msg.vibefx !== 'keyrelay' || !sender.tab || typeof msg.action !== 'string') return;
  chrome.tabs.sendMessage(sender.tab.id, { vibefx: 'keyaction', action: msg.action }).catch(() => {});
});
