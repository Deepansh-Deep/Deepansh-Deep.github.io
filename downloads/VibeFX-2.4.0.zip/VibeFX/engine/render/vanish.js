// Particle vanish and reassembly.
//
// The person is REMOVED from the output frame (replaced by the learned background plate through
// a feathered mask), and the silhouette is converted into thousands of colour-sampled particles
// that drift away. Reassembly runs the same closed-form particle motion in reverse towards the
// person's current silhouette, revealing the real pixels where particles land.
//
// Particle motion is a closed-form function of time-since-release, so it is exactly reversible
// and needs no integration state.

import { makeCanvas, ctx2d, clamp, smoothstep, rng, vnoise } from './util.js';

const LW = 160; // dissolve-threshold grid width

export class VanishRenderer {
  constructor() { this.W = 0; this.H = 0; this.P = null; this.phase = 'visible'; this.seed = 1; this.maxParticles = 9000; }

  setup(W, H) {
    this.W = W; this.H = H;
    this.LH = Math.max(8, Math.round(LW * H / W));
    this.layer = makeCanvas(W, H); this.lc = ctx2d(this.layer);
    this.partImg = new ImageData(W, H); this.part32 = new Uint32Array(this.partImg.data.buffer);
    this.partCanvas = makeCanvas(W, H); this.pcx = ctx2d(this.partCanvas);
    this.alphaC = makeCanvas(LW, this.LH); this.ax = ctx2d(this.alphaC);
    this.alphaImg = this.ax.createImageData(LW, this.LH);
    this.colorC = makeCanvas(256, Math.round(256 * H / W)); this.colx = ctx2d(this.colorC, { willReadFrequently: true });
    this.T = new Float32Array(LW * this.LH);
    this.P = null; this.phase = 'visible';
  }

  // Called when the controller enters dissolving/returning. frame: ImageBitmap, mp: MaskProcessor.
  start(kind, frame, mp, intensity = 1, quality = 1) {
    this.kind = kind;
    this.seed = (Math.random() * 1e9) | 0;
    const R = rng(this.seed);
    const W = this.W, H = this.H;
    // dissolve thresholds: sweep along a wind direction + noise
    const dir = kind === 'dissolve' ? 1 : -1;
    const bb = mp.bbox || { x0: 0, x1: 1, y0: 0, y1: 1 };
    for (let y = 0; y < this.LH; y++) for (let x = 0; x < LW; x++) {
      const nx = x / LW, ny = y / this.LH;
      const sweep = clamp(((nx - bb.x0) / Math.max(0.05, bb.x1 - bb.x0)) * (dir > 0 ? 1 : 1) + 0.12 * (1 - ny));
      const noise = vnoise(nx * 9 + this.seed % 97, ny * 9, this.seed % 31) * 0.6 + vnoise(nx * 26, ny * 26, 5) * 0.4;
      this.T[y * LW + x] = clamp(0.62 * sweep + 0.38 * noise);
    }
    // sample colours at low-res
    const cw = this.colorC.width, ch = this.colorC.height;
    this.colx.drawImage(frame, 0, 0, cw, ch);
    const px = this.colx.getImageData(0, 0, cw, ch).data;
    // gather candidate cells from the mask
    const mw = mp.w, mh = mp.h, ma = mp.alpha;
    const cand = [];
    for (let y = 0; y < mh; y++) for (let x = 0; x < mw; x++) if (ma[y * mw + x] > 140) cand.push(y * mw + x);
    const want = Math.min(cand.length, Math.round(this.maxParticles * intensity * quality));
    const n = want;
    const P = {
      n, x: new Float32Array(n), y: new Float32Array(n), r: new Uint8Array(n), g: new Uint8Array(n), b: new Uint8Array(n),
      delay: new Float32Array(n), dx: new Float32Array(n), dy: new Float32Array(n), sp: new Float32Array(n), ac: new Float32Array(n),
      sw: new Float32Array(n), ph: new Float32Array(n), life: new Float32Array(n), size: new Uint8Array(n),
    };
    // pick `n` random candidates without replacement (partial Fisher-Yates)
    for (let i = 0; i < n; i++) {
      const j = i + Math.floor(R() * (cand.length - i)); const tmp = cand[i]; cand[i] = cand[j]; cand[j] = tmp;
      const c = cand[i], cx = c % mw, cy = (c / mw) | 0;
      const fx = (cx + R()) / mw, fy = (cy + R()) / mh;
      P.x[i] = fx * W; P.y[i] = fy * H;
      const ci = (Math.min(ch - 1, (fy * ch) | 0) * cw + Math.min(cw - 1, (fx * cw) | 0)) * 4;
      P.r[i] = px[ci]; P.g[i] = px[ci + 1]; P.b[i] = px[ci + 2];
      const tx = Math.min(LW - 1, (fx * LW) | 0), ty = Math.min(this.LH - 1, (fy * this.LH) | 0);
      P.delay[i] = this.T[ty * LW + tx];
      // flight parameters (px/s, px/s^2): ash drifting right/up with turbulence
      const ang = -0.55 + (R() - 0.5) * 1.5;
      P.dx[i] = Math.cos(ang); P.dy[i] = Math.sin(ang);
      P.sp[i] = (90 + R() * 260) * (W / 1280);
      P.ac[i] = (60 + R() * 220) * (W / 1280);
      P.sw[i] = (10 + R() * 55) * (W / 1280);
      P.ph[i] = R() * 6.283;
      P.life[i] = 1.1 + R() * 1.4;
      P.size[i] = R() < 0.12 ? 4 : R() < 0.5 ? 3 : 2;
    }
    this.P = P; this.phase = kind;
    this.totalFlight = 2.6;
  }

  stop() { this.P = null; this.phase = 'visible'; }

  // Offset of a particle after `tau` seconds of flight (closed form).
  _off(P, i, tau, out) {
    const t2 = tau * tau;
    out.x = P.dx[i] * (P.sp[i] * tau + 0.5 * P.ac[i] * t2) + P.sw[i] * Math.sin(P.ph[i] + tau * 3.1) * Math.min(1, tau * 1.3);
    out.y = P.dy[i] * (P.sp[i] * tau + 0.5 * P.ac[i] * t2) - 24 * tau + P.sw[i] * Math.cos(P.ph[i] * 1.3 + tau * 2.4) * Math.min(1, tau * 1.3);
  }

  // Alpha mask (low-res) of where the person has been replaced by background at `progress`.
  // dissolve: replaced grows with progress. return: replaced shrinks as particles arrive.
  _buildReplaceAlpha(mp, progress, phase) {
    const img = this.alphaImg.data, T = this.T;
    for (let i = 0; i < T.length; i++) {
      let rep;
      if (phase === 'dissolving') rep = clamp((progress * 1.3 - T[i]) / 0.16);
      else if (phase === 'returning') rep = 1 - clamp((progress * 1.3 - (1 - T[i])) / 0.16);
      else rep = 1; // gone
      img[i * 4] = img[i * 4 + 1] = img[i * 4 + 2] = 255; img[i * 4 + 3] = rep * 255;
    }
    this.ax.putImageData(this.alphaImg, 0, 0);
  }

  // Draw the vanished picture into o (already containing the live frame). phase: controller phase.
  drawReplace(o, plate, mp, phase, progress) {
    if (phase === 'visible') return;
    this._buildReplaceAlpha(mp, progress, phase);
    const l = this.lc;
    l.globalCompositeOperation = 'source-over';
    l.clearRect(0, 0, this.W, this.H);
    l.drawImage(plate, 0, 0);
    // region = grown person mask * replace alpha
    l.globalCompositeOperation = 'destination-in';
    // multiply: first mask, then the per-cell replace alpha
    const tmp = this._tmp || (this._tmp = makeCanvas(this.W, this.H)); const tx = this._tx || (this._tx = ctx2d(this._tmp));
    tx.globalCompositeOperation = 'source-over'; tx.clearRect(0, 0, this.W, this.H);
    tx.drawImage(mp.grown, 0, 0, this.W, this.H);
    tx.globalCompositeOperation = 'destination-in';
    tx.filter = `blur(${Math.max(1, this.W / 300)}px)`;
    tx.drawImage(this.alphaC, 0, 0, this.W, this.H);
    tx.filter = 'none'; tx.globalCompositeOperation = 'source-over';
    l.drawImage(this._tmp, 0, 0);
    l.globalCompositeOperation = 'source-over';
    o.drawImage(this.layer, 0, 0);
  }

  // Draw particles for the current phase/progress.
  drawParticles(o, phase, progress, durationSec) {
    const P = this.P; if (!P || phase === 'visible' || phase === 'gone') return;
    const buf = this.part32; buf.fill(0);
    const W = this.W, H = this.H, off = { x: 0, y: 0 };
    const total = durationSec;
    const flight = this.totalFlight;
    let drawn = 0;
    for (let i = 0; i < P.n; i++) {
      let tau, alphaF;
      if (phase === 'dissolving') {
        // particle releases when the dissolve front reaches it
        const startP = P.delay[i] / 1.3;
        const el = (progress - startP) * total;
        if (el < 0) { continue; }
        tau = el; alphaF = clamp(1 - (tau / (P.life[i] * 1.0)) , 0, 1);
        alphaF = alphaF * alphaF * (3 - 2 * alphaF);
        // before leaving, ramp in over 80 ms so the particle replaces the vanished pixel
        alphaF *= clamp(tau / 0.08);
        if (alphaF <= 0.01) continue;
        this._off(P, i, tau, off);
      } else {
        // returning: reverse flight towards the target; arrives when the front reaches it
        const arriveP = (1 - P.delay[i]) / 1.3 + 0.16 / 1.3;
        const remaining = (arriveP - progress) * total;      // seconds until it lands
        if (remaining <= 0) continue;                        // landed: the real pixel is back
        tau = Math.min(remaining, P.life[i]);
        const fadeIn = clamp((P.life[i] - remaining) / 0.5 + 0.2);
        alphaF = clamp(remaining / 0.12) * clamp(1 - (remaining - P.life[i] * 0.0) / (P.life[i] * 1.4)) + 0.0;
        alphaF = clamp(alphaF * 1.4 + 0.15) * fadeIn;
        this._off(P, i, tau, off);
      }
      const x = (P.x[i] + off.x) | 0, y = (P.y[i] + off.y) | 0;
      if (x < 1 || y < 1 || x >= W - 4 || y >= H - 4) continue;
      const a = (alphaF * 255) | 0;
      const col = (a << 24) | (P.b[i] << 16) | (P.g[i] << 8) | P.r[i];
      const s = P.size[i];
      for (let yy = 0; yy < s; yy++) { const row = (y + yy) * W + x; for (let xx = 0; xx < s; xx++) buf[row + xx] = col; }
      drawn++;
    }
    this.pcx.putImageData(this.partImg, 0, 0);
    o.drawImage(this.partCanvas, 0, 0);
    this.lastDrawn = drawn;
  }
}
