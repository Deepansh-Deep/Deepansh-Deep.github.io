// The picture effects drawn from bundled assets and from the user's uploads:
//   sad       the facepalm cut-out appears BEHIND you, large, with the text "OHH GOD"
//   punisher  the "no no no" GIF fills the whole screen
//   money     the falling-money GIF (white background keyed out) over everything
//   memes     the user's own pictures/GIFs: whole screen, or as the background behind you
//   end       the black screen after the vanish dust, with the user's text and/or picture

import { clamp, easeOutCubic } from './util.js';
import { ATLAS, drawAtlasFrame } from './assets.js';

const easeOutBack = (x) => { x = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };

export class OverlayRenderer {
  constructor() { this.W = 0; this.H = 0; this.side = 1; }
  setup(W, H, assets) { this.W = W; this.H = H; this.assets = assets; }

  // Called when an effect starts: pick the side of the picture where the person is NOT.
  pickSide(mask) {
    const c = mask && mask.valid && mask.centroid ? mask.centroid.x : 0.5;
    this.side = c < 0.5 ? 1 : -1;          // 1 = put things on the right
  }

  // Behind the person. The caller draws the person on top afterwards.
  drawSadBack(o, level, since, now, media) {
    const a = this.assets;
    const own = media && media.ready('ovr_sad');                      // the user's own cutout replaces the bundled one
    if (level <= 0.001 || !(own || (a && a.ready('sad')))) return false;
    const { W, H } = this, img = own ? media.frameAt('ovr_sad', now - since) : a.sad;
    const age = Math.max(0, (now - since) / 1000);
    const pop = easeOutBack(age / 0.38);
    const h = H * 1.02, w = h * img.width / img.height;
    const cx = W * (this.side > 0 ? 0.68 : 0.32), by = H * 1.03;
    o.save();
    o.globalAlpha = clamp(level);
    o.translate(cx, by + (1 - clamp(pop, 0, 1.2)) * h * 0.35);
    o.drawImage(img, -w / 2, -h, w, h);
    o.restore();
    return true;
  }

  drawSadText(o, level, since, now) {
    if (level <= 0.001) return;
    const { W, H } = this;
    const age = Math.max(0, (now - since) / 1000 - 0.14);
    if (age <= 0) return;
    const pop = easeOutBack(age / 0.32);
    const size = H * 0.15, cx = W * (this.side > 0 ? 0.68 : 0.32), cy = H * 0.16;
    o.save();
    o.globalAlpha = clamp(level);
    o.translate(cx, cy); o.rotate(-0.06 + Math.sin(now / 90) * 0.012); o.scale(pop, pop);
    o.font = `900 ${size}px Impact, "Arial Black", "Helvetica Neue", Arial, sans-serif`;
    o.textAlign = 'center'; o.textBaseline = 'middle'; o.lineJoin = 'round';
    o.lineWidth = size * 0.16; o.strokeStyle = '#000'; o.strokeText('OHH GOD', 0, 0);
    o.shadowColor = 'rgba(0,0,0,0.5)'; o.shadowBlur = size * 0.1; o.shadowOffsetY = size * 0.05;
    o.fillStyle = '#fff'; o.fillText('OHH GOD', 0, 0);
    o.restore();
  }

  // The whole screen is the clip (cropped to fill). You may disappear behind it, that is intended.
  drawPunisher(o, level, since, now) {
    const a = this.assets;
    if (level <= 0.001 || !a || !a.ready('punisher')) return;
    const { W, H } = this, spec = ATLAS.punisher;
    const age = Math.max(0, (now - since) / 1000);
    const k = Math.max(W / spec.w, H / spec.h), s = 1 + 0.06 * (1 - clamp(easeOutCubic(age / 0.3)));
    const w = spec.w * k * s, h = spec.h * k * s;
    o.save();
    o.globalAlpha = clamp(level * 1.4);
    o.imageSmoothingQuality = 'high';
    drawAtlasFrame(o, a.punisher, spec, Math.floor((now - since) / spec.frameMs), (W - w) / 2, (H - h) / 2, w, h);
    o.restore();
  }

  drawMoney(o, level, since, now) {
    const a = this.assets;
    if (level <= 0.001 || !a || !a.ready('money')) return;
    const spec = ATLAS.money;
    o.save();
    o.globalAlpha = clamp(level);
    drawAtlasFrame(o, a.money, spec, Math.floor((now - since) / spec.frameMs), 0, 0, this.W, this.H);
    o.restore();
  }
}

// ------------------------------------------------------------------ user media
// Custom meme slot. fit 'cover' fills the screen. `mode` behind: the caller draws the person on top afterwards.
OverlayRenderer.prototype.drawMeme = function (o, media, slot, level, since, now) {
  if (level <= 0.001 || !media || !media.ready(slot)) return false;
  const { W, H } = this, age = Math.max(0, (now - since) / 1000);
  const s = 1 + 0.05 * (1 - clamp(easeOutCubic(age / 0.3)));
  o.save(); o.globalAlpha = clamp(level * 1.4);
  o.translate(W / 2, H / 2); o.scale(s, s); o.translate(-W / 2, -H / 2);
  media.draw(o, slot, now - since, { x: 0, y: 0, w: W, h: H }, 'cover');
  o.restore();
  return true;
};

// Black screen with the user's text and/or picture. alpha 0..1 (the black itself and the contents fade together).
OverlayRenderer.prototype.drawEndScreen = function (o, media, text, alpha, since, now) {
  if (alpha <= 0.001) return;
  const { W, H } = this;
  o.save();
  o.globalAlpha = clamp(alpha); o.fillStyle = '#000'; o.fillRect(0, 0, W, H);
  const a2 = clamp((alpha - 0.35) / 0.65);
  const t = Math.max(0, (now - since) / 1000);
  const hasMedia = media && media.ready('end');
  if (hasMedia) {
    o.globalAlpha = a2;
    media.draw(o, 'end', now - since, { x: W * 0.1, y: H * 0.06, w: W * 0.8, h: text ? H * 0.68 : H * 0.88 }, 'contain');
  }
  if (text) {
    let size = H * (hasMedia ? 0.09 : 0.15);
    o.font = `800 ${size}px system-ui, "Segoe UI", Arial, sans-serif`;
    const maxW = W * 0.86, tw = o.measureText(text).width;
    if (tw > maxW) { size *= maxW / tw; o.font = `800 ${size}px system-ui, "Segoe UI", Arial, sans-serif`; }
    o.textAlign = 'center'; o.textBaseline = 'middle';
    const y = (hasMedia ? H * 0.86 : H * 0.5) + Math.sin(t * 1.6) * H * 0.006;
    o.globalAlpha = a2; o.shadowColor = 'rgba(255,255,255,0.35)'; o.shadowBlur = size * 0.35;
    o.fillStyle = '#fff'; o.fillText(text, W / 2, y);
  }
  o.restore();
};
export { easeOutCubic };
