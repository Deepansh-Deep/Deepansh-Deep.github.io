// Bounded, backpressured frame pipeline with a watchdog. Used by the Chrome extension
// (page side) and the Electron app. Environment specifics (VideoFrame, ImageBitmap,
// postMessage) are injected, so the control logic is testable in Node.
//
// Guarantees
//   * PASSIVE mode (no effect on screen): every camera frame is written out immediately, so the
//     video has zero added latency. A copy of the newest frame goes to the engine for gesture
//     analysis, one at a time (never more than one analysis in flight).
//   * ACTIVE mode (an effect is on or fading): each frame makes a round trip through the engine and
//     the processed frame is written. At most ONE frame is in flight, so the queue cannot grow.
//   * the engine says which mode it wants (meta.active); the pipeline returns to passive after a few
//     idle answers.
//   * a slow engine cannot freeze the video: after `stallMs` the pipeline switches to an
//     explicit DEGRADED state, passes the raw camera through, keeps probing the engine, and
//     recovers by itself when the engine answers again.
//   * state changes are reported with a reason; nothing is ever silently swapped.
//
// States: starting | running | degraded | stopped

export class FramePipeline {
  constructor({ reader, writer, engine, convertIn, convertOut, onState, now = () => performance.now(),
    stallMs = 2500, probeEveryMs = 600, maxConsecutiveErrors = 5, enabled = () => true,
    analyzeEveryMs = 30, idleFramesToPassive = 6, abandonMs = 12000 }) {
    Object.assign(this, { reader, writer, engine, convertIn, convertOut, onState, now, stallMs, probeEveryMs, maxConsecutiveErrors, enabled, analyzeEveryMs, idleFramesToPassive, abandonMs });
    this.state = 'starting'; this.reason = 'engine-loading';
    this.stopped = false;
    this.consecutiveErrors = 0;
    this.probing = false; this.lastProbe = 0;
    this.mode = 'passive';                 // passive | active
    this.idleCount = 0;
    this.analysis = null;                  // {token, startedAt} while an analysis is in flight
    this.lastAnalysisAt = -1e9; this.token = 0;
    this.stats = { in: 0, out: 0, processed: 0, passthrough: 0, analyzed: 0, errors: 0, stalls: 0, lateDropped: 0, avgMs: 0 };
    this.done = null;
  }

  _set(state, reason) {
    if (state === this.state && reason === this.reason) return;
    this.state = state; this.reason = reason;
    try { this.onState && this.onState({ state, reason, mode: this.mode, stats: { ...this.stats } }); } catch (_) { /* listener errors must not kill video */ }
  }

  start() {
    try { this.onState && this.onState({ state: this.state, reason: this.reason, mode: this.mode, stats: { ...this.stats } }); } catch (_) {}
    this.done = this._loop();
    return this.done;
  }

  async stop() {
    this.stopped = true;
    this._set('stopped', 'stopped');
    try { await this.reader.cancel(); } catch (_) {}
    if (this.done) { try { await this.done; } catch (_) {} }
  }

  async _loop() {
    try {
      while (!this.stopped) {
        let r;
        try { r = await this.reader.read(); } catch (_) { break; }
        if (r.done) break;
        const frame = r.value;
        this.stats.in++;
        const out = await this._handle(frame);
        try { await this.writer.write(out); this.stats.out++; } catch (e) { try { out.close(); } catch (_) {} break; }
      }
    } finally {
      try { await this.writer.close(); } catch (_) {}
      this._set('stopped', 'stopped');
    }
  }

  _closeResult(res) { try { if (res && res.frame && res.frame.close) res.frame.close(); } catch (_) {} }

  async _handle(frame) {
    const t0 = this.now();
    if (!this.enabled()) { this.stats.passthrough++; return frame; }      // user turned the effect engine off
    if (!this.engine.isReady()) {
      this._set(this.engine.failed() ? 'degraded' : 'starting', this.engine.failed() ? 'engine-failed' : 'engine-loading');
      this.stats.passthrough++;
      return frame;
    }
    if (this.state === 'degraded' && this.reason === 'engine-failed') this._set('running', 'recovered');

    if (this.mode === 'passive') {
      this._maybeAnalyze(frame);
      this.stats.passthrough++;
      return frame;                                                        // zero added latency
    }
    return this._handleActive(frame, t0);
  }

  // Passive: send a copy of this frame for analysis if none is in flight and the rate allows it.
  // A slow answer is still a valid answer: it is used when it arrives. While it is overdue the status says
  // degraded (so the user is told), and only after abandonMs is the analysis given up and a new one started.
  _maybeAnalyze(frame) {
    const t = this.now();
    if (this.analysis) {
      const age = t - this.analysis.startedAt;
      if (age > this.stallMs && !this.analysis.flagged) { this.analysis.flagged = true; this.stats.stalls++; this._set('degraded', 'engine-stalled'); }
      if (age > this.abandonMs) { this.analysis = null; }
    }
    if (this.analysis || t - this.lastAnalysisAt < this.analyzeEveryMs) return;
    const token = ++this.token;
    this.analysis = { token, startedAt: t, flagged: false }; this.lastAnalysisAt = t;
    let copy;
    try { copy = frame.clone(); } catch (_) { this.analysis = null; return; }
    Promise.resolve(this.convertIn(copy)).then((input) => this.engine.process(input)).then((res) => {
      try { copy.close(); } catch (_) {}
      const mine = this.analysis && this.analysis.token === token;
      if (mine) this.analysis = null;
      if (this.mode !== 'passive' && !mine) { this.stats.lateDropped++; this._closeResult(res); return; }
      this.stats.analyzed++;
      if (!res || res.error) {
        this.stats.errors++; this.consecutiveErrors++;
        if (this.consecutiveErrors >= this.maxConsecutiveErrors) this._set('degraded', 'engine-errors');
        return;
      }
      this.consecutiveErrors = 0;
      this._closeResult(res);                                              // analysis only: never shown
      if (res.meta && res.meta.active) { this.mode = 'active'; this.idleCount = 0; }
      this._set('running', this.mode === 'active' ? 'processing' : 'watching');
    }).catch(() => { try { copy.close(); } catch (_) {} if (this.analysis && this.analysis.token === token) this.analysis = null; this.stats.errors++; });
  }

  async _handleActive(frame, t0) {
    if (this.analysis) this.analysis = null;                               // an old analysis answer is no longer needed
    let timer;
    const input = await this.convertIn(frame);
    const job = this.engine.process(input);
    const timeout = new Promise((res) => { timer = setTimeout(() => res({ timeout: true }), this.stallMs); });
    let res;
    try { res = await Promise.race([job, timeout]); }
    catch (e) { res = { error: e }; }
    clearTimeout(timer);

    if (res && res.timeout) {
      this.stats.stalls++;
      job.then((late) => { this.stats.lateDropped++; this._closeResult(late); }).catch(() => {});
      this.mode = 'passive';                                               // fall back to passthrough + analysis; status says degraded
      this._set('degraded', 'engine-stalled');
      this.stats.passthrough++;
      return frame;
    }
    if (!res || res.error || !res.frame) {
      this.stats.errors++; this.consecutiveErrors++;
      if (this.consecutiveErrors >= this.maxConsecutiveErrors) { this.mode = 'passive'; this._set('degraded', 'engine-errors'); }
      this.stats.passthrough++;
      return frame;
    }
    this.consecutiveErrors = 0;
    const idle = !!(res.meta && res.meta.idle);
    if (idle) { if (++this.idleCount >= this.idleFramesToPassive) this.mode = 'passive'; } else this.idleCount = 0;
    this._set('running', this.mode === 'active' ? (idle ? 'idle' : 'processing') : 'watching');
    const out = await this.convertOut(res.frame, frame);
    if (out !== frame) { try { frame.close(); } catch (_) {} }
    this.stats.processed++;
    const ms = this.now() - t0;
    this.stats.avgMs = this.stats.avgMs ? this.stats.avgMs * 0.9 + ms * 0.1 : ms;
    return out;
  }
}
