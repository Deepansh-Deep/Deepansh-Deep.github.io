// Isolated-world content script. Owns everything that needs chrome.* APIs: settings storage,
// the hidden engine iframe, popup requests and the toolbar badge. It never touches frames.
(() => {
  const NS = '__vibefx';
  const KEY = 'vibefx.settings';
  const MKEY = 'vibefx.media';
  const ID = '__vibefx_engine__';
  if (window.__vibefxBridge) return;
  window.__vibefxBridge = true;

  const extOrigin = new URL(chrome.runtime.getURL('/')).origin;
  const state = { iframe: null, hello: false, settings: null, media: {}, main: null, engine: null, models: null, lastEvents: [], lastGesture: null, lastCommand: null, logs: [], loadFailed: false };

  const toMain = (msg) => window.postMessage({ [NS]: 1, from: 'bridge', ...msg }, window.location.origin);
  const toEngine = (msg) => { try { state.iframe && state.iframe.contentWindow && state.iframe.contentWindow.postMessage({ [NS]: 1, ...msg }, extOrigin); } catch (_) {} };

  async function loadSettings() {
    try { const r = await chrome.storage.local.get(KEY); state.settings = r[KEY] || {}; }
    catch (_) { state.settings = {}; }
    return state.settings;
  }

  // The engine is the source of truth for freeze; MAIN is told on every change (and corrected by the 1 s status heartbeat).
  function sendFreeze(on) { if (state.fzSent === on) return; state.fzSent = on; toMain({ type: 'freeze', on }); }

  async function loadMedia() {
    try { const r = await chrome.storage.local.get(MKEY); state.media = r[MKEY] || {}; }
    catch (_) { state.media = {}; }
    return state.media;
  }
  const sendMedia = () => toEngine({ t: 'media', media: state.media || {} });

  function badge() {
    const m = state.main;
    let level = 'off', text = '', title = 'VibeFX: waiting for the page to open the camera';
    const s = state.settings || {};
    if (s.enabled === false) { level = 'off'; text = 'OFF'; title = 'VibeFX is switched off. Your camera goes through untouched.'; }
    else if (state.loadFailed) { level = 'bad'; text = '!'; title = 'VibeFX engine is blocked on this site. Effects are NOT applied.'; }
    else if (m && m.streams > 0) {
      if (m.pipeline.state === 'running') { level = 'ok'; text = 'ON'; title = 'VibeFX is processing your camera'; }
      else if (m.pipeline.state === 'starting') { level = 'warn'; text = '...'; title = 'VibeFX engine is starting. Raw camera is being sent for now.'; }
      else if (m.pipeline.state === 'degraded') { level = 'bad'; text = '!'; title = 'VibeFX is degraded (' + m.pipeline.reason + '). Raw camera is being sent.'; }
    }
    try { chrome.runtime.sendMessage({ vibefx: 'badge', level, text, title }); } catch (_) {}
  }

  // Small on-page confirmation of what the camera just recognised. Only you see it (it is on the page, not in the video).
  const EFFECT_NAME = {
    vanish: 'Particle vanish', cinema: 'Absolute Cinema', sad: 'Sad meme', punisher: 'No no no', money: 'Money rain',
    deal: 'Deal with it', banner: 'Name banner', confetti: 'Confetti', hearts: 'Hearts', flames: 'Flames', freeze: 'Freeze',
  };
  const effectName = (id) => EFFECT_NAME[id] || (((state.settings || {}).customs || []).find((c) => c.id === id) || {}).name || id;
  const REASON = { 'no-person': 'No person found, vanish needs you in view', 'pose-model-loading': 'Still loading the body model, try again in a moment', 'pose-model-failed': 'Body model failed to load, vanish is unavailable', busy: 'Vanish is still running', 'no-media': 'Nothing uploaded for this slot yet. Open the VibeFX popup and add a picture or GIF' };
  let toastEl = null, toastTimer = 0;
  function toast(text) {
    if ((state.settings || {}).hints === false || !text) return;
    try {
      if (!toastEl) {
        const host = document.createElement('div');
        host.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;pointer-events:none;';
        const root = host.attachShadow({ mode: 'closed' });
        const el = document.createElement('div');
        el.style.cssText = 'font:600 14px system-ui,sans-serif;color:#fff;background:rgba(15,15,20,.88);padding:8px 14px;border-radius:999px;box-shadow:0 4px 18px rgba(0,0,0,.4);opacity:0;transition:opacity .15s;white-space:nowrap;';
        root.appendChild(el);
        (document.documentElement || document.body).appendChild(host);
        toastEl = el;
      }
      toastEl.textContent = 'VibeFX: ' + text; toastEl.style.opacity = '1';
      clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.style.opacity = '0'; }, 1800);
    } catch (_) {}
  }

  function ensureIframe() {
    if (state.iframe) return;
    const f = document.createElement('iframe');
    f.id = ID;
    f.src = chrome.runtime.getURL('engine-host/engine.html');
    f.setAttribute('aria-hidden', 'true');
    f.tabIndex = -1;
    f.allow = '';
    // Not display:none: some browsers throttle hidden frames. Zero-size and off screen instead.
    f.style.cssText = 'position:fixed;left:-10px;top:-10px;width:2px;height:2px;border:0;opacity:0;pointer-events:none;';
    (document.documentElement || document).appendChild(f);
    state.iframe = f;
    state.loadFailed = false;
    setTimeout(() => {
      if (!state.hello) { state.loadFailed = true; toMain({ type: 'engine-failed', reason: 'iframe-blocked' }); badge(); }
    }, 8000);
  }

  window.addEventListener('message', (ev) => {
    const m = ev.data;
    if (!m || m[NS] !== 1) return;
    // from the page's MAIN-world script
    if (ev.source === window && m.from === 'main') {
      if (m.type === 'need-engine') {
        state.wanted = true;
        Promise.all([loadSettings(), loadMedia()]).then(() => {
          toMain({ type: 'engine-origin', origin: extOrigin });
          toMain({ type: 'settings', settings: state.settings });
          if ((state.settings || {}).enabled !== false) ensureIframe();     // switched off: do not load the heavy models at all
          badge();
        });
      }
      else if (m.type === 'main-status') { state.main = m; badge(); }
      return;
    }
    // from the engine iframe
    if (state.iframe && ev.source === state.iframe.contentWindow && ev.origin === extOrigin) {
      switch (m.t) {
        case 'hello': state.hello = true; state.loadFailed = false; toEngine({ t: 'init', settings: state.settings || {} }); sendMedia(); toMain({ type: 'engine-hello' }); break;
        case 'engine-ready': toMain({ type: 'engine-ready' }); break;
        case 'status': state.engine = m.s; sendFreeze(!!(m.s && m.s.effects && m.s.effects.freeze && m.s.effects.freeze.active)); break;
        case 'models-done': state.models = m.models; break;
        case 'event': {
          const e = m.e;
          if (e.type === 'freeze') { sendFreeze(!!e.on); toast(e.on ? ((state.settings || {}).muteOnFreeze === false ? 'Frozen' : 'Frozen: picture and mic') : 'Unfrozen'); }
          if (e.type === 'gesture') state.lastGesture = { ...e, at: Date.now() };
          if (['gesture', 'command', 'warning', 'error', 'frame-error', 'effect-event'].includes(e.type)) { state.lastEvents.push({ ...e, at: Date.now() }); if (state.lastEvents.length > 30) state.lastEvents.shift(); }
          if (e.type === 'gesture') toast(e.label + ' → ' + effectName(e.effect));
          else if (e.type === 'command' && e.source === 'hotkey') toast(e.ok === false ? (REASON[e.reason] || ('Not possible: ' + e.reason)) : effectName(e.name));
          else if (e.type === 'command' && e.source === 'ui' && e.ok === false) toast(REASON[e.reason] || ('Not possible: ' + e.reason));
          else if (e.type === 'command' && e.source && e.source.startsWith('gesture') && e.ok === false) toast(REASON[e.reason] || ('Ignored: ' + e.reason));
          break;
        }
        case 'command-result': state.lastCommand = { name: m.name, ...m.r, at: Date.now() }; break;
        case 'log': state.logs.push(m.text); if (state.logs.length > 20) state.logs.shift(); break;
      }
    }
  }, true);

  // settings changes from the popup go to the iframe and to MAIN (master switch, gestures, sensitivity)
  chrome.storage.onChanged.addListener((chg, area) => {
    if (area !== 'local') return;
    if (chg[MKEY]) { state.media = chg[MKEY].newValue || {}; sendMedia(); }
    if (!chg[KEY]) return;
    state.settings = chg[KEY].newValue || {};
    if (state.wanted && !state.iframe && state.settings.enabled !== false) ensureIframe();
    toEngine({ t: 'settings', patch: state.settings });
    toMain({ type: 'settings', settings: state.settings });
    badge();
  });

  // popup requests
  chrome.runtime.onMessage.addListener((req, _sender, reply) => {
    if (!req || !req.vibefx) return;
    if (req.vibefx === 'get-status') {
      reply({
        ok: true, url: location.host, loadFailed: state.loadFailed, helloSeen: state.hello,
        main: state.main, engine: state.engine, models: state.models, lastGesture: state.lastGesture,
        lastCommand: state.lastCommand, events: state.lastEvents.slice(-12), logs: state.logs.slice(-6),
        iframeCreated: !!state.iframe, ts: Date.now(),
      });
    } else if (req.vibefx === 'keyaction') {
      fire(req.action, true);                      // a key pressed in another frame of this tab (relayed by the background)
    } else if (req.vibefx === 'command') {
      if (!state.iframe || !state.hello) { reply({ ok: false, reason: 'camera-not-active' }); return; }
      const rid = Math.random().toString(36).slice(2);
      const delay = Math.min(15000, Math.max(0, +req.delayMs || 0));
      state.lastCommand = null;
      if (delay) { setTimeout(() => toEngine({ t: 'command', name: req.name, opts: req.opts || {}, source: 'ui', rid }), delay); reply({ ok: true, scheduled: delay }); return; }
      toEngine({ t: 'command', name: req.name, opts: req.opts || {}, source: 'ui', rid });
      // answer after the engine has had a moment to respond
      setTimeout(() => reply({ ok: true, last: state.lastCommand }), 120);
      return true;
    }
  });

  // ------------------------------------------------------------ keyboard shortcuts: Alt (Option) + one key
  // Defaults must match core/settings.js DEFAULTS.keys (a unit test checks it); content scripts cannot import modules.
  const DEFAULT_KEYS = { vanish: 'KeyV', freeze: 'KeyZ', pauseGestures: 'KeyG' };
  const MAC = /Mac/i.test(navigator.platform || '');
  function keyMap() {
    const s = state.settings || {}, map = {};
    for (const [action, code] of Object.entries({ ...DEFAULT_KEYS, ...(s.keys || {}) })) if (code && !map[code]) map[code] = action;
    for (const c of s.customs || []) if (c && c.key && !map[c.key]) map[c.key] = c.id;
    return map;
  }
  async function togglePause() {
    try {
      const r = await chrome.storage.local.get(KEY); const s = r[KEY] || {};
      const g = { ...(s.gestures || {}) }; g.enabled = g.enabled === false;
      await chrome.storage.local.set({ [KEY]: { ...s, gestures: g } });
      toast(g.enabled ? 'Gestures ON' : 'Gestures PAUSED (shortcuts still work)');
    } catch (_) {}
  }
  // Runs the action in the frame that owns the camera engine; other frames pass it on through the background.
  function fire(action, relayed) {
    if (state.iframe && state.hello) {
      if (action === 'pauseGestures') togglePause();
      else toEngine({ t: 'command', name: action, opts: {}, source: 'hotkey', rid: Math.random().toString(36).slice(2) });
    } else if (!relayed) {
      try { chrome.runtime.sendMessage({ vibefx: 'keyrelay', action }); } catch (_) {}
    }
  }
  window.addEventListener('keydown', (ev) => {
    if (!ev.altKey || ev.ctrlKey || ev.metaKey || ev.shiftKey || ev.repeat) return;
    const action = keyMap()[ev.code];
    if (!action) return;
    const t = ev.target;
    if (MAC && t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;   // Option+key types symbols there
    ev.preventDefault(); ev.stopPropagation();
    fire(action, false);
  }, true);

  loadSettings();
  loadMedia();
})();
