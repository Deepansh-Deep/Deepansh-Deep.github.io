VibeFX 2.4.0  (Chrome / Edge extension)
=========================================

INSTALL (one time)
1. Extract this zip. You get a folder named VibeFX with manifest.json inside.
2. Open chrome://extensions (Edge: edge://extensions) and switch on "Developer mode".
3. Click "Load unpacked" and pick the VibeFX folder. (Updating from an older version: remove the old one first, or press reload on it.)
4. Open your call site (Meet, Zoom web, Teams web, Discord web, Whereby, Webex, Jitsi, Slack huddles).
   If the tab was already open, reload it once, then let the site use your camera.
   Keep the VibeFX folder where it is: Chrome reads it from there.

GESTURES: DEFAULT PACK (one pose per effect; palm toward the camera, hand clearly in view, good light)
  Bye wave                 Particle vanish. You turn to dust, the screen goes BLACK and shows your goodbye
                           text / picture / GIF. Do it again (or press Alt+V) to come back.
  Both hands up            Absolute Cinema
  Hand on face (facepalm)  Sad meme
  Hands joined             No no no (full screen clip)
  Index + middle finger    Money rain
  3 fingers                Deal with it (pixel sunglasses)
  4 fingers, thumb tucked  Name banner (stays until switched off)
  OK sign                  Confetti
  Shaka (thumb + pinky)    Hearts
  Rock on (index + pinky)  Flames
  Open palm (5 fingers)    Freeze me: your picture AND your microphone freeze (see below)
  Not assigned by default: index finger, little finger, thumb up (free for your own memes).
Do the same gesture again to switch an effect off. Most effects also switch off by themselves
(popup: "Effect stays for").

CHOOSE YOUR OWN GESTURES AND SHORTCUTS
  * Gestures: popup > "Gestures: what each one does". Every pose has a dropdown: any effect, any of your memes, or Nothing.
    There are 14 poses in total, so that is the limit for gestures. Reset button restores the default pack.
  * Shortcuts: popup > "Shortcuts: Alt + key". Click a button, then hold Alt (Option on Mac) and press a key.
    Any effect and any meme can have one. Defaults: Alt+V vanish, Alt+Z freeze, Alt+G pause/resume gestures.
    They work while the call tab is in front. Alt+D, Alt+E, Alt+F and Alt+F4 are taken by the browser and refused.
    If Meet or your browser already uses a key combination, pick another. Linux Chrome uses Alt+1 to Alt+8 for tabs.

FREEZE ME (someone walks in, you step away)
  Show 5 fingers (or Alt+Z, or the popup button). The picture freezes and, by default, the microphone is silenced too,
  so nobody sees or hears what happens next. Do it again to unfreeze both.
  * The call site's own mic button will still show "unmuted" while you are frozen. A small notice appears on the page.
  * If you switch your mic on in the site while frozen, that choice wins until the next freeze.
  * A mic you had already muted yourself stays muted after unfreeze.
  * Turn the mic part off: popup > Settings > "Freeze also mutes my microphone".
  * Only the on/off flag of your microphone is touched. VibeFX never listens to or records audio.
  * Open palm is easy to show by accident while talking with your hands, and now a false trigger also mutes you.
    If that happens, move it to another gesture (popup > Gestures) or set it to Nothing.

MY MEMES (as many as you want, up to 40)
  Popup > "My memes" > Add a meme. Upload a picture or GIF, name it, choose Full screen or Behind me,
  and give it a gesture, a shortcut, or both. The first few are prepared in the background so they start instantly.

REPLACE THE BUILT-IN MEMES
  Popup > "Replace the built-in memes": No no no and Money rain take a picture or GIF, Sad meme takes a PNG with a
  transparent background (a cut-out person). "Use built-in" restores the original. Absolute Cinema cannot be replaced yet.

POPUP (toolbar icon)
  * Goodbye screen: type your text (for example "I am Iron Man") and/or upload a picture or GIF (up to 8 MB).
  * Your look: fix dark lighting, blur the background or replace it with your picture, name banner text.
  * Settings you saved stay after restarting the browser.

NOTES
 * Everything runs on your computer. No upload, no accounts. The microphone is never listened to, only switched off during a freeze.
 * With no effect on, your camera goes straight through untouched, so there is no added delay.
 * Text on screen is NOT flipped. Meet only mirrors your own preview, everyone else reads it correctly.
 * "Fix dark lighting" and "Background blur / picture" redraw every frame, so they use clearly more CPU. Off by default.
 * The page shows a small notice (only you see it) when a gesture is recognised. Popup: "Show gesture notices".
 * Works for browser calls only. Desktop apps (Zoom/Teams desktop) are not covered by this extension.
 * Particle vanish looks best if you press "Capture clean background" once while out of frame.
 * Sensitivity: Fast reacts sooner but triggers more by accident, Careful the opposite.
 * Picture credits and licences of the bundled MediaPipe models: THIRD_PARTY_LICENSES.txt

KNOWN LIMITS
 * Peace sign, 3 fingers and 4 fingers can happen by accident while talking with your hands. Thumb, index finger and
   open palm are even easier, which is why they are unassigned by default. Alt+G pauses gestures during a serious call.
 * The No no no clip is small (360 px wide) and gets stretched to full screen, so it looks soft.
 * Background blur edges follow a coarse body mask and can look blocky around hands and objects.
 * Shortcuts only fire while the call tab has focus. A key the call site already uses may be taken by the site first.
 * Pictures are stored in the browser (extension storage). Very large GIFs use a lot of memory while playing, so keep them short.
